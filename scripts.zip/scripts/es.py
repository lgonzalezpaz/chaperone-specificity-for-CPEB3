import sys,json,urllib.request,urllib.parse,os,ssl,time
ctx=ssl.create_default_context(cafile=os.path.expanduser('~/.ccr/ca-bundle.crt'))
for t in sys.argv[1:]:
    u="https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retmode=json&term="+urllib.parse.quote(t)
    try:
        r=json.load(urllib.request.urlopen(u,context=ctx,timeout=30))['esearchresult']['idlist']
        print(t,r)
        if r:
            s=json.load(urllib.request.urlopen("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&retmode=json&id="+r[0],context=ctx,timeout=30))['result'][r[0]]
            print('   ',s['title'],'|',s['fulljournalname'],s['pubdate'],s['volume'],s['issue'],s['pages'],[a['name'] for a in s['authors']][:6],len(s['authors']))
    except Exception as e: print(t,'ERR',e)
    time.sleep(0.5)
