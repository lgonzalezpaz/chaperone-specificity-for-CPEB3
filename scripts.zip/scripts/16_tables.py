#!/usr/bin/env python3
"""
16_tables.py  --  manuscript tables, as tab-separated files and as Markdown
                  blocks ready for insertion into the manuscript
"""
import json
import pathlib
import numpy as np
import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[1]
RES, TAB = ROOT / "results", ROOT / "tables"
TAB.mkdir(exist_ok=True, parents=True)


def md(df, floatfmt="%.3g"):
    d = df.copy()
    for c in d.columns:
        if pd.api.types.is_float_dtype(d[c]):
            d[c] = d[c].map(lambda v: "" if pd.isna(v) else floatfmt % v)
    head = "| " + " | ".join(str(c) for c in d.columns) + " |"
    rule = "|" + "|".join(["---"] * len(d.columns)) + "|"
    rows = ["| " + " | ".join(str(v) for v in r) + " |"
            for r in d.astype(str).to_numpy()]
    return "\n".join([head, rule] + rows)


out = {}

# ---------------------------------------------------- Table 1
gram = pd.read_csv(RES / "grammar_vectors.tsv", sep="\t")
core = pd.read_csv(RES / "core_sequences.tsv", sep="\t")
t1 = core.merge(gram.drop(columns=["client", "core_len"]), on="pdb")
t1 = t1.assign(span=lambda d: d.first.astype(str) + "-" + d.last.astype(str))
T1 = pd.DataFrame({
    "PDB": t1.pdb,
    "Client": t1.client,
    "Resolved core": t1.span,
    "Length (aa)": t1.core_len,
    "Gln (%)": t1.f_Q * 100,
    "His (%)": t1.f_H * 100,
    "Aromatic (%)": t1.f_aromatic * 100,
    "Apolar (%)": t1.f_hydrophobic * 100,
    "Charged (%)": t1.f_charged * 100,
    "Mean hydropathy": t1.mean_KD,
    "Exposed fraction": t1.frac_exposed,
    "Surface amide (%)": t1.surf_f_QN * 100,
    "Surface aromatic (%)": t1.surf_f_aromatic * 100,
})
T1.to_csv(TAB / "table1_amyloid_core_grammar.tsv", sep="\t", index=False)
out["table1"] = md(T1, "%.1f")

# ---------------------------------------------------- Table 2
L1 = pd.read_csv(RES / "layer1_scores.tsv", sep="\t")
NONHUMAN = ["Funes", "Mrj_Dmel", "JJJ2_Scer", "Sis1_Scer", "Ydj1_Scer",
            "DnaJ_Ecoli"]
h = L1[~L1.gene.isin(NONHUMAN)].nlargest(10, "sw_jdomain_norm")
T2 = pd.DataFrame({
    "Gene": h.gene, "UniProt": h.acc, "Length (aa)": h.len_full,
    "J-domain identity to Funes (%)": h.jd_identity * 100,
    "J-domain similarity (%)": h.jd_similarity * 100,
    "Normalised SW, J domain": h.sw_jdomain_norm,
    "Normalised SW, full length": h.sw_fulllength_norm,
    "HPD motif": np.where(h.HPD, "yes", "no"),
})
T2.to_csv(TAB / "table2_funes_likeness.tsv", sep="\t", index=False)
out["table2"] = md(T2, "%.3f")

# ---------------------------------------------------- Table 3
if (RES / "cg_summary.tsv").exists():
    cg = pd.read_csv(RES / "cg_summary.tsv", sep="\t")
    LAB = {"Orb2_core": "Orb2 core (6VPS)",
           "hCPEB3_core": "hCPEB3 core (8SPA)",
           "hCPEB3_core_shuffled": "hCPEB3 core, scrambled",
           "Orb2_LVLVF": "Orb2 LVLVF (9PX8)",
           "Orb2_FVLVF": "Orb2 FVLVF (9YWA)",
           "Orb2_FIMMF": "Orb2 FIMMF (9Y1V)"}
    T3 = pd.DataFrame({
        "Chaperone": cg.chaperone,
        "Client": cg.client.map(lambda c: LAB.get(c, c)),
        "CBR residues": cg.cbr_start.astype(str) + "-" + cg.cbr_end.astype(str),
        "Beads": cg.n_beads,
        "dG (kJ/mol)": cg.dG_kJmol,
        "Bootstrap SD": cg.dG_sd_kJmol,
        "Replica spread": cg.dG_replica_spread,
        "Kd (mM)": cg.Kd_mM,
        "Role": cg.note,
    })
    T3.to_csv(TAB / "table3_binding_free_energies.tsv", sep="\t", index=False)
    out["table3"] = md(T3, "%.2f")

# ---------------------------------------------------- Table 4
F = pd.read_csv(RES / "prismj_ranking.tsv", sep="\t")
integ = json.load(open(RES / "integration.json"))
short = F.head(6).copy()
if "DNAJC8" not in set(short.gene):
    short = pd.concat([short, F[F.gene == "DNAJC8"]])
T4 = pd.DataFrame({
    "Gene": short.gene,
    "PRISM-J rank": short.rank_prismj,
    "Layer 1 rank": short.rank_L1,
    "J-domain similarity to Funes": short.sw_jdomain_norm,
    "CBR mean stickiness": short.lam_mean,
    "CBR aromatic (%)": short.f_aromatic * 100,
    "Brain TPM (median)": short.brain_tpm_median,
    "Brain enrichment (log2)": short.brain_enrichment_log2,
    "CPEB3 co-expression": short.cpeb3_coexpr_rho,
    "Main localisation": short.hpa_main_location,
})
T4.to_csv(TAB / "table4_shortlist.tsv", sep="\t", index=False)
out["table4"] = md(T4, "%.3f")

# ---------------------------------------------------- Supplementary
F.to_csv(TAB / "tableS1_full_ranking.tsv", sep="\t", index=False)
pd.read_csv(RES / "rozales_scores_wide.tsv", sep="\t").to_csv(
    TAB / "tableS2_external_screen.tsv", sep="\t", index=False)
pd.read_csv(RES / "descriptors_clients.tsv", sep="\t").to_csv(
    TAB / "tableS3_client_descriptors.tsv", sep="\t", index=False)
pd.read_csv(RES / "core_sasa.tsv", sep="\t").to_csv(
    TAB / "tableS4_core_sasa.tsv", sep="\t", index=False)
if (RES / "alanine_scan.tsv").exists():
    pd.read_csv(RES / "alanine_scan.tsv", sep="\t").to_csv(
        TAB / "tableS5_alanine_scan.tsv", sep="\t", index=False)

(TAB / "tables.md").write_text(
    "\n\n".join(f"### {k}\n\n{v}" for k, v in out.items()))
for k in out:
    print(f"[ok] {k}")
print(f"[ok] {len(list(TAB.glob('*.tsv')))} tab-separated files in tables/")
