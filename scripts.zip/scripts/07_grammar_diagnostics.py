#!/usr/bin/env python3
"""
07_grammar_diagnostics.py

Controls for the statistical models of 06_grammar_model.py and quantification
of how closely the two clients of the Rozales et al. (2022) screens match the
Orb2 and hCPEB3 amyloid cores in client-grammar space.

Questions answered.
  (1) Does composition-level chaperone-client complementarity explain anything
      out of sample beyond the client main effect? (nested models under
      leave-one-chaperone-out cross-validation, with a label-permutation test
      of the increment)
  (2) Where do the four clients sit relative to one another in grammar space?
  (3) Are the experimental chaperone-response profiles of the two
      grammar-distinct clients correlated, and do their responder sets overlap?

Note on the control series. Sheet 2B of the Source Data file contains, after
the per-chaperone block, a second DsRed block whose entries cluster at ~1.0;
these are untransformed AGG+ ratios, not log2 ratios, and are excluded. The
control band is therefore computed from the log2 DsRed-vs-DsRed replicates,
which are centred on zero by construction.

Outputs (results/):
  diagnostics.json, client_grammar_distances.tsv, responder_sets.tsv
"""
import json
import pathlib
import numpy as np
import pandas as pd
import openpyxl
from scipy import stats
from scipy.spatial.distance import pdist, squareform
from sklearn.linear_model import Ridge
from sklearn.model_selection import LeaveOneGroupOut, cross_val_predict
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

ROOT = pathlib.Path(__file__).resolve().parents[1]
RES = ROOT / "results"
XLSX = ROOT / "ext" / "rozales" / "41467_2022_27982_MOESM8_ESM.xlsx"
RNG = np.random.default_rng(7)

dp = pd.read_csv(RES / "descriptors_panel.tsv", sep="\t")
dc = pd.read_csv(RES / "descriptors_clients.tsv", sep="\t")
sc = pd.read_csv(RES / "rozales_scores_wide.tsv", sep="\t")
sc = sc[sc.chaperone != "dsred"].reset_index(drop=True)
full = pd.read_csv(RES / "rozales_scores.tsv", sep="\t")

CLASSES = ["aromatic", "aliphatic", "gly", "pro", "amide", "hydroxyl",
           "cation", "anion", "his", "cys"]
CH = [f"f_{k}" for k in CLASSES] + ["lam_mean", "ncpr"]
CL = [f"c_f_{k}" for k in CLASSES] + ["c_lam_mean", "c_ncpr"]

long = sc.melt(id_vars="chaperone", var_name="client", value_name="ams")
dc2 = dc.assign(client=dc.client.str.replace("_APR", "", regex=False))
long = long.merge(dp, on="chaperone").merge(dc2, on="client", how="inner")
y = long.ams.to_numpy(float)
groups = long.chaperone.to_numpy()
logo = LeaveOneGroupOut()


def logo_q2(X, y, groups, alpha=100.0):
    pipe = make_pipeline(StandardScaler(), Ridge(alpha=alpha))
    yh = cross_val_predict(pipe, X, y, cv=logo, groups=groups)
    r, p = stats.pearsonr(y, yh)
    q2 = 1 - np.sum((y - yh) ** 2) / np.sum((y - y.mean()) ** 2)
    return float(r), float(p), float(q2), yh


Xcl = pd.get_dummies(long.client, drop_first=False).to_numpy(float)
Xch = long[CH].to_numpy(float)
pairs = [(a, b) for a in CH for b in CL]
XI = np.column_stack([long[a].to_numpy(float) * long[b].to_numpy(float)
                      for a, b in pairs])

models = {
    "M0 client main effect": Xcl,
    "M1 + chaperone composition": np.column_stack([Xcl, Xch]),
    "M2 + bilinear interactions": np.column_stack([Xcl, Xch, XI]),
    "M2' bilinear interactions only": XI,
}
out = {}
print("nested models, leave-one-chaperone-out cross-validation (n = "
      f"{len(y)} chaperone-client pairs)")
preds = {}
for name, X in models.items():
    r, p, q2, yh = logo_q2(X, y, groups)
    out[name] = dict(r=r, p=p, q2=q2, n_features=int(X.shape[1]))
    preds[name] = yh
    print(f"  {name:32s} r = {r: .3f}  Q2 = {q2: .3f}  "
          f"({X.shape[1]} features)")

# increment of the bilinear terms, with a permutation test that breaks the
# chaperone-composition link while preserving the client structure
e1 = (y - preds["M1 + chaperone composition"]) ** 2
e2 = (y - preds["M2 + bilinear interactions"]) ** 2
dq2 = out["M2 + bilinear interactions"]["q2"] - out["M1 + chaperone composition"]["q2"]
w_stat, w_p = stats.wilcoxon(e1, e2)
nperm, null = 500, np.empty(500)
chaps = sc.chaperone.to_numpy()
for i in range(nperm):
    perm = RNG.permutation(len(chaps))
    dpp = dp.set_index("chaperone").loc[chaps].reset_index(drop=True)
    dpp = dpp.iloc[perm].reset_index(drop=True)
    dpp["chaperone"] = chaps
    lp = sc.melt(id_vars="chaperone", var_name="client", value_name="ams")
    lp = lp.merge(dpp, on="chaperone").merge(dc2, on="client", how="inner")
    Xch_p = lp[CH].to_numpy(float)
    XI_p = np.column_stack([lp[a].to_numpy(float) * lp[b].to_numpy(float)
                            for a, b in pairs])
    Xcl_p = pd.get_dummies(lp.client, drop_first=False).to_numpy(float)
    yp = lp.ams.to_numpy(float)
    gp = lp.chaperone.to_numpy()
    _, _, q2a, _ = logo_q2(np.column_stack([Xcl_p, Xch_p]), yp, gp)
    _, _, q2b, _ = logo_q2(np.column_stack([Xcl_p, Xch_p, XI_p]), yp, gp)
    null[i] = q2b - q2a
p_inc = (1 + np.sum(null >= dq2)) / (nperm + 1)
print(f"\n  increment of bilinear terms: dQ2 = {dq2:+.4f}; "
      f"Wilcoxon on squared errors P = {w_p:.3g}; "
      f"composition-permutation P = {p_inc:.3f}")
verdict = ("composition-level complementarity carries little transferable "
           "predictive signal") if (dq2 < 0.05 or p_inc > 0.05) else \
          ("composition-level complementarity carries transferable signal")
print(f"  => {verdict}")

# ------------------------------------------- client grammar-space geometry
G = dc.set_index("client")[CL].copy()
G = G.loc[:, G.std(ddof=0) > 0]
G.columns = [c[2:] for c in G.columns]
Z = (G - G.mean()) / G.std(ddof=0)
Dm = pd.DataFrame(squareform(pdist(Z.to_numpy(), metric="euclidean")),
                  index=G.index, columns=G.index)
Dm.to_csv(RES / "client_grammar_distances.tsv", sep="\t")
print(f"\nclient grammar-space distances ({Z.shape[1]} standardised features)")
print(Dm.round(2).to_string())
pq, pa = ("Orb2_core", "HTT_polyQ_APR"), ("hCPEB3_core", "mutFUS_APR")
cross = [("Orb2_core", "mutFUS_APR"), ("Orb2_core", "hCPEB3_core"),
         ("HTT_polyQ_APR", "hCPEB3_core"), ("HTT_polyQ_APR", "mutFUS_APR")]
d_match = np.array([Dm.loc[pq], Dm.loc[pa]])
d_cross = np.array([Dm.loc[a, b] for a, b in cross])
print(f"  grammar-matched pairs   mean d = {d_match.mean():.2f} "
      f"(Orb2/polyQ {Dm.loc[pq]:.2f}; hCPEB3/FUS {Dm.loc[pa]:.2f})")
print(f"  grammar-mismatched pairs mean d = {d_cross.mean():.2f} "
      f"(range {d_cross.min():.2f}-{d_cross.max():.2f})")

# --------------------------------------------------- control band and sets
wb = openpyxl.load_workbook(XLSX, read_only=True, data_only=True)
band = {}
for sh, cl in [("2B", "HTT_polyQ"), ("3A", "mutFUS")]:
    vals = []
    for r in wb[sh].iter_rows(values_only=True):
        if not r[0] or len(r) < 9:
            continue
        try:
            v = float(r[8])
        except (TypeError, ValueError):
            continue
        if "dsred" in str(r[0]).lower() and abs(v) < 0.5:
            vals.append(v)
    vals = np.array(vals)
    band[cl] = dict(n=int(len(vals)), mean=float(vals.mean()),
                    sd=float(vals.std(ddof=1)), thr=float(2 * vals.std(ddof=1)))
    print(f"\ncontrol band {cl}: n = {len(vals)} DsRed log2 replicates, "
          f"mean = {vals.mean():+.4f}, SD = {vals.std(ddof=1):.4f}, "
          f"2SD = {2*vals.std(ddof=1):.4f}")

res = sc.copy()
res["polyQ_responder"] = res.HTT_polyQ.abs() > band["HTT_polyQ"]["thr"]
res["FUS_responder"] = res.mutFUS.abs() > band["mutFUS"]["thr"]
res.to_csv(RES / "responder_sets.tsv", sep="\t", index=False)
A = set(res.loc[res.polyQ_responder, "chaperone"])
B = set(res.loc[res.FUS_responder, "chaperone"])
tab = np.array([[len(A & B), len(A - B)],
                [len(B - A), len(res) - len(A | B)]])
odds, p_fish = stats.fisher_exact(tab)
jac = len(A & B) / max(1, len(A | B))
print(f"\nresponder sets: polyQ n = {len(A)}, mutFUS n = {len(B)}, "
      f"shared n = {len(A & B)}")
print(f"  Jaccard = {jac:.3f}; Fisher exact P = {p_fish:.3g}; "
      f"odds ratio = {odds:.2f}")

rho, p_rho = stats.spearmanr(sc.HTT_polyQ, sc.mutFUS)
r_p, p_p = stats.pearsonr(sc.HTT_polyQ, sc.mutFUS)
print(f"  profile correlation (n = {len(sc)}): rho = {rho:.3f} (P = {p_rho:.3g}); "
      f"r = {r_p:.3f} (P = {p_p:.3g})")
# threshold-free rank overlap
k = 10
topA = set(sc.nsmallest(k, "HTT_polyQ").chaperone)
topB = set(sc.nsmallest(k, "mutFUS").chaperone)
M, nA, nB = len(sc), k, k
ov = len(topA & topB)
p_hyp = stats.hypergeom.sf(ov - 1, M, nA, nB)
print(f"  top-{k} alleviator overlap = {ov}/{k}; hypergeometric P = {p_hyp:.3f}")

json.dump(dict(nested=out,
               increment=dict(dq2=float(dq2), wilcoxon_p=float(w_p),
                              permutation_p=float(p_inc), verdict=verdict),
               grammar_distance=dict(
                   matched_mean=float(d_match.mean()),
                   orb2_vs_polyQ=float(Dm.loc[pq]),
                   cpeb3_vs_FUS=float(Dm.loc[pa]),
                   mismatched_mean=float(d_cross.mean()),
                   cross={f"{a}|{b}": float(Dm.loc[a, b]) for a, b in cross}),
               control_band=band,
               responders=dict(n_polyQ=len(A), n_FUS=len(B), shared=len(A & B),
                               jaccard=float(jac), fisher_p=float(p_fish),
                               odds=float(odds),
                               spearman_rho=float(rho), spearman_p=float(p_rho),
                               pearson_r=float(r_p), pearson_p=float(p_p),
                               topk=k, topk_overlap=int(ov),
                               topk_p=float(p_hyp))),
          open(RES / "diagnostics.json", "w"), indent=1)
print("\n[ok] diagnostics.json written")
