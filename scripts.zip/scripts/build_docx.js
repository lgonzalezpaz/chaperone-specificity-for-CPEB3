/*
 * build_docx.js -- assemble the manuscript DOCX from the Markdown sources.
 *
 * Style, applied exactly as specified:
 *   A4, single column, 2.54 cm margins on all sides
 *   body Times New Roman 12 pt, black, left aligned, double spaced,
 *     no first-line indent, one blank line between paragraphs
 *   title 16 pt bold, sentence case
 *   authors 12 pt centred; affiliations 9.5 pt; correspondence 10 pt
 *   abstract 10.5 pt; keywords 9.5 pt
 *   level-1 headings 13 pt bold; level-2 headings 11.5 pt bold
 *   equations centred, numbered at the right margin, as editable text
 *   references 9.5 pt, 1.15 spacing
 *   page numbers top right; continuous line numbers in the left margin
 */
const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, AlignmentType, HeadingLevel,
  PageNumber, Header, SectionType, LineNumberRestartFormat, ImageRun,
  Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle,
  PositionalTab, PositionalTabAlignment, PositionalTabLeader,
} = require("docx");

const ROOT = path.resolve(__dirname, "..");
const MS = path.join(ROOT, "manuscript", "manuscript.md");
const LEG = path.join(ROOT, "manuscript", "figure_legends.md");
const FIGDIR = path.join(ROOT, "figures");
const OUT = path.join(ROOT, "manuscript", "manuscript.docx");

const FONT = "Times New Roman";
const PT = (n) => n * 2;              // half-points
const DOUBLE = { line: 480, lineRule: "auto" };
const SINGLE = { line: 276, lineRule: "auto" };

// ------------------------------------------------------------ inline runs
function runs(text, { size = PT(12), bold = false, italics = false } = {}) {
  const out = [];
  // tokens: **bold**, *italic*, <sup>..</sup>, <sub>..</sub>, `code`
  const re = /(\*\*[^*]+\*\*|\*[^*]+\*|<sup>.*?<\/sup>|<sub>.*?<\/sub>|`[^`]+`)/g;
  let last = 0, m;
  const push = (s, extra = {}) => {
    if (s === "") return;
    out.push(new TextRun({
      text: s, font: FONT, size, bold, italics, color: "000000", ...extra,
    }));
  };
  while ((m = re.exec(text)) !== null) {
    push(text.slice(last, m.index));
    const tok = m[0];
    if (tok.startsWith("**")) push(tok.slice(2, -2), { bold: true });
    else if (tok.startsWith("<sup>")) push(tok.slice(5, -6), { superScript: true });
    else if (tok.startsWith("<sub>")) push(tok.slice(5, -6), { subScript: true });
    else if (tok.startsWith("`")) push(tok.slice(1, -1), { font: "Consolas" });
    else push(tok.slice(1, -1), { italics: true });
    last = m.index + tok.length;
  }
  push(text.slice(last));
  return out;
}

const body = (text, opts = {}) => new Paragraph({
  children: runs(text, { size: opts.size || PT(12) }),
  spacing: { ...(opts.spacing || DOUBLE), after: opts.after === undefined ? 200 : opts.after },
  alignment: opts.alignment || AlignmentType.LEFT,
  indent: { firstLine: 0 },
});

function h1(text) {
  return new Paragraph({
    children: runs(text, { size: PT(13), bold: true }),
    spacing: { before: 360, after: 180, line: 276, lineRule: "auto" },
    heading: HeadingLevel.HEADING_1,
    alignment: AlignmentType.LEFT,
  });
}
function h2(text) {
  return new Paragraph({
    children: runs(text, { size: PT(11.5), bold: true }),
    spacing: { before: 280, after: 140, line: 276, lineRule: "auto" },
    heading: HeadingLevel.HEADING_2,
    alignment: AlignmentType.LEFT,
  });
}

// equation line: body text, centred, with the number pushed to the right margin
function equation(expr, number) {
  const kids = runs(expr.trim(), { size: PT(12) });
  if (number) {
    kids.push(new TextRun({
      children: [new PositionalTab({
        alignment: PositionalTabAlignment.RIGHT,
        relativeTo: "margin",
        leader: PositionalTabLeader.NONE,
      })],
    }));
    kids.push(new TextRun({ text: `(${number})`, font: FONT, size: PT(12) }));
  }
  return new Paragraph({
    children: kids,
    spacing: { before: 160, after: 160, line: 276, lineRule: "auto" },
    alignment: AlignmentType.LEFT,
  });
}

function mdTable(lines) {
  const rows = lines.filter((l) => !/^\|[\s:|-]+\|$/.test(l))
    .map((l) => l.replace(/^\||\|$/g, "").split("|").map((c) => c.trim()));
  const ncol = Math.max(...rows.map((r) => r.length));
  const TOTAL = 9360;                       // A4 minus 2.54 cm margins, DXA
  const w = Math.floor(TOTAL / ncol);
  const colWidths = Array(ncol).fill(w);
  colWidths[ncol - 1] = TOTAL - w * (ncol - 1);
  return new Table({
    columnWidths: colWidths,
    width: { size: TOTAL, type: WidthType.DXA },
    rows: rows.map((cells, i) => new TableRow({
      tableHeader: i === 0,
      children: Array.from({ length: ncol }, (_, j) => new TableCell({
        width: { size: colWidths[j], type: WidthType.DXA },
        shading: i === 0
          ? { type: ShadingType.CLEAR, fill: "EEEEEE" }
          : { type: ShadingType.CLEAR, fill: "FFFFFF" },
        children: [new Paragraph({
          children: runs(cells[j] || "", { size: PT(9), bold: i === 0 }),
          spacing: { line: 240, lineRule: "auto", after: 40 },
        })],
      })),
    })),
  });
}

// ------------------------------------------------------------ parse
const text = fs.readFileSync(MS, "utf8").replace(/<!--[\s\S]*?-->/g, "");
const lines = text.split("\n");
const children = [];
let i = 0;
let eqCounter = 0;
let inRefs = false;
let inAbstract = false;

// title block
while (i < lines.length && !lines[i].startsWith("# ")) i++;
children.push(new Paragraph({
  children: runs(lines[i].slice(2).trim(), { size: PT(16), bold: true }),
  spacing: { after: 320, line: 276, lineRule: "auto" },
  alignment: AlignmentType.LEFT,
}));
i++;

while (i < lines.length && !lines[i].startsWith("## ")) {
  const l = lines[i].trim();
  if (l && l !== "---") {
    const isAff = l.startsWith("<sup>1</sup>");
    const isCorr = l.startsWith("\\*Correspondence") || l.startsWith("*Correspondence");
    children.push(new Paragraph({
      children: runs(l.replace(/^\\\*/, "*"), {
        size: isAff ? PT(9.5) : isCorr ? PT(10) : PT(12),
        italics: isAff,
      }),
      spacing: { after: 120, line: 276, lineRule: "auto" },
      alignment: AlignmentType.CENTER,
    }));
  }
  i++;
}

for (; i < lines.length; i++) {
  const raw = lines[i];
  const l = raw.trim();
  if (l === "" || l === "---") continue;

  if (l.startsWith("## ")) {
    const t = l.slice(3).trim();
    inRefs = /^References$/i.test(t);
    inAbstract = /^Abstract$/i.test(t);
    children.push(h1(t));
    continue;
  }
  if (l.startsWith("### ")) { children.push(h2(l.slice(4).trim())); continue; }

  if (l.startsWith("|")) {
    const block = [];
    while (i < lines.length && lines[i].trim().startsWith("|")) block.push(lines[i].trim()), i++;
    i--;
    children.push(mdTable(block));
    children.push(new Paragraph({ text: "", spacing: { after: 160 } }));
    continue;
  }

  // equation lines are written with leading non-breaking spaces
  if (raw.startsWith("&nbsp;")) {
    const stripped = l.replace(/(&nbsp;)+/g, "").trim();
    const m = stripped.match(/^(.*)\s\((\d+[ab]?)\)$/);
    if (m) { eqCounter++; children.push(equation(m[1], m[2])); }
    else children.push(equation(stripped, null));
    continue;
  }

  if (inAbstract) {
    inAbstract = false;
    children.push(new Paragraph({
      children: runs(l, { size: PT(10.5) }),
      spacing: { after: 240, line: 276, lineRule: "auto" },
      alignment: AlignmentType.LEFT,
    }));
    continue;
  }

  if (/^\*\*Keywords:\*\*/.test(l)) {
    children.push(new Paragraph({
      children: runs(l, { size: PT(9.5) }),
      spacing: { after: 240, line: 276, lineRule: "auto" },
    }));
    continue;
  }

  if (/^\[Figure \d+ near here\]$/.test(l)) {
    children.push(new Paragraph({
      children: runs(l, { size: PT(12), italics: true }),
      spacing: { before: 120, after: 160, line: 276, lineRule: "auto" },
      alignment: AlignmentType.CENTER,
    }));
    continue;
  }

  if (inRefs) {
    children.push(new Paragraph({
      children: runs(l, { size: PT(9.5) }),
      spacing: { after: 100, ...SINGLE },
      indent: { left: 360, hanging: 360 },
    }));
    continue;
  }

  // the abstract paragraph is set smaller than the body
  const prevH = [...children].reverse().find((c) => c instanceof Paragraph && c.options
    && c.options.heading);
  const smallAbstract = false;
  children.push(body(l, { size: PT(12) }));
}

// ------------------------------------------------------- figure legends
const legend = fs.readFileSync(LEG, "utf8");
const FIGFILES = {
  1: "figure1_client_grammar.png",
  2: "figure2_layer_dissociation.png",
  3: "figure3_client_specificity.png",
  4: "figure4_neuronal_context.png",
  5: "figure5_binding_free_energies.png",
  6: "figure6_grammar_titration.png",
  7: "figure7_interface_map.png",
};
children.push(new Paragraph({ children: [new TextRun({ text: "", break: 1 })] }));
for (const raw of legend.split("\n")) {
  const l = raw.trim();
  if (l === "") continue;
  if (l.startsWith("## ")) { children.push(h1(l.slice(3).trim())); continue; }
  const m = l.match(/^\*\*Figure (\d+)\./);
  if (m && FIGFILES[m[1]]) {
    const f = path.join(FIGDIR, FIGFILES[m[1]]);
    if (fs.existsSync(f)) {
      const dim = pngSize(f);
      const maxW = 600;                       // points at 72 dpi across the text block
      const scale = Math.min(1, maxW / dim.w);
      children.push(new Paragraph({
        children: [new ImageRun({
          type: "png", data: fs.readFileSync(f),
          transformation: { width: Math.round(dim.w * scale), height: Math.round(dim.h * scale) },
        })],
        alignment: AlignmentType.CENTER,
        spacing: { before: 240, after: 120 },
      }));
    }
  }
  children.push(new Paragraph({
    children: runs(l, { size: PT(10) }),
    spacing: { after: 160, ...SINGLE },
  }));
}

function pngSize(file) {
  const b = fs.readFileSync(file);
  return { w: b.readUInt32BE(16), h: b.readUInt32BE(20) };
}

// --------------------------------------------------------------- document
const doc = new Document({
  creator: "PRISM-J",
  title: "Client-grammar divergence uncouples sequence orthology from functional orthology",
  styles: {
    default: {
      document: { run: { font: FONT, size: PT(12), color: "000000" } },
    },
  },
  sections: [{
    properties: {
      type: SectionType.CONTINUOUS,
      page: {
        size: { width: 11906, height: 16838 },        // A4 in DXA
        margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 },
      },
      lineNumbers: { countBy: 1, restart: LineNumberRestartFormat.CONTINUOUS, distance: 360 },
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: PT(10) })],
        })],
      }),
    },
    children,
  }],
});

Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync(OUT, buf);
  console.log(`[ok] ${OUT} (${(buf.length / 1024).toFixed(0)} kB, ${children.length} blocks, ${eqCounter} numbered equations)`);
});
