import sys,json,urllib.request,urllib.parse,os,ssl
ctx=ssl.create_default_context(cafile=os.path.expanduser('~/.ccr/ca-bundle.crt'))
q=sys.argv[1]
u="https://api.crossref.org/works?rows=4&select=DOI,title,container-title,volume,issue,page,article-number,issued,author&query.bibliographic="+urllib.parse.quote(q)
for m in json.load(urllib.request.urlopen(u,context=ctx,timeout=30))['message']['items']:
    au=[(a.get('family') or a.get('name','?'))+' '+''.join(x[0] for x in a.get('given','').replace('-',' ').split()) for a in m.get('author',[])]
    print(m['DOI'],'|',m['title'][:1],'|',m.get('container-title'),m.get('volume'),m.get('issue'),m.get('page'),m.get('article-number'),m['issued']['date-parts'][0][0],'|',len(au),', '.join(au))
