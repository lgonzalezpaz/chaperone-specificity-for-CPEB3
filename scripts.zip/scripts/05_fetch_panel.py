#!/usr/bin/env python3
"""
05_fetch_panel.py

Retrieves sequences for (i) the 66-chaperone panel of the Rozales et al.
(2022) screens, used as the independent training/validation set, and
(ii) the aggregation-prone regions (APRs) of the two screen clients
(HTT-polyQ and mutant FUS), defined from the constructs described in that
study and from UniProt feature annotation.

Outputs (data/):
  panel_sequences.fasta / panel_meta.tsv
  clients.fasta
"""
import io
import json
import pathlib
import re
import time
import sys
import requests
import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[1]
DATA, RES = ROOT / "data", ROOT / "results"
BASE = "https://rest.uniprot.org/uniprotkb"
S = requests.Session()
S.headers.update({"User-Agent": "PRISM-J/1.0"})


def get(url, params=None, tries=4):
    for k in range(tries):
        try:
            r = S.get(url, params=params, timeout=90)
            if r.status_code == 200:
                return r
        except Exception as exc:
            sys.stderr.write(f"retry {k}: {exc}\n")
        time.sleep(2 * (k + 1))
    raise RuntimeError(url)


def canonical(gene):
    """Canonical reviewed human sequence for a gene symbol."""
    gene = re.sub(r"[^A-Za-z0-9-]", "", str(gene))
    if not gene:
        return None
    for q in (f"(gene_exact:{gene}) AND (organism_id:9606) AND (reviewed:true)",
              f"(gene:{gene}) AND (organism_id:9606) AND (reviewed:true)"):
        try:
            r = get(f"{BASE}/search", params={
                "query": q,
                "fields": "accession,gene_primary,sequence,protein_name,length",
                "format": "tsv", "size": 5})
        except RuntimeError:
            continue
        d = pd.read_csv(io.StringIO(r.text), sep="\t")
        if len(d):
            return d.iloc[0].to_dict()
    return None


panel = pd.read_csv(RES / "rozales_scores_wide.tsv", sep="\t")
names = panel["chaperone"].tolist()

# map screen labels to gene symbols; isoform suffixes handled explicitly
ISO = {"DNAJB12-FL": "DNAJB12", "DNAJB12-short": "DNAJB12",
       "DNAJB6-FL": "DNAJB6", "DNAJB6-short": "DNAJB6",
       "DNAJB2b": "DNAJB2", "HSPB2/3": "HSPB2", "dsred": None}

rows, fasta = [], []
for nm in names:
    gene = ISO.get(nm, nm)
    if gene is None:
        continue
    rec = canonical(gene)
    if rec is None:
        print(f"[warn] no reviewed entry for {nm} -> {gene}")
        continue
    rows.append(dict(label=nm, gene=gene, acc=rec["Entry"],
                     length=rec["Length"], name=rec["Protein names"]))
    fasta.append(f">{nm}|{rec['Entry']}|{gene}\n{rec['Sequence']}\n")
    time.sleep(0.15)

meta = pd.DataFrame(rows)
meta.to_csv(DATA / "panel_meta.tsv", sep="\t", index=False)
(DATA / "panel_sequences.fasta").write_text("".join(fasta))
print(f"[ok] panel: {len(meta)}/{len(names)} chaperones resolved")
miss = set(names) - set(meta.label) - {"dsred"}
print("[info] unresolved:", sorted(miss))

# --------------------------------------------------------------- clients
# explicit accessions: the symbol "HTT" is an obsolete alias of SLC6A4 in
# UniProt's gene index, so huntingtin is requested by accession.
def by_acc(acc):
    return get(f"{BASE}/{acc}.fasta").text.split("\n", 1)[1].replace("\n", "")


htt = by_acc("P42858")   # huntingtin, Homo sapiens
fus = by_acc("P35637")   # FUS/TLS, Homo sapiens
print(f"[ok] HTT P42858 {len(htt)} aa; FUS P35637 {len(fus)} aa")

# HTT exon-1 construct used in the screen: N17 + expanded polyQ + the
# polyproline-rich region. We rebuild HTT-134Q from the reference exon 1.
m = re.search(r"(Q{5,})", htt[:120])
q_start, q_end = m.start(1), m.end(1)
n17 = htt[:q_start]                      # N-terminal 17 residues
prd = htt[q_end:q_end + 51]              # proline-rich region of exon 1
htt_134q = n17 + "Q" * 134 + prd
print(f"[ok] HTT exon1: N17='{n17}' reference polyQ length={q_end-q_start}; "
      f"construct length={len(htt_134q)}")

# FUS-R521H: full length with the ALS mutation in the PY-NLS. The
# aggregation-driving region is the N-terminal prion-like/QGSY-rich domain.
assert fus[520] == "R", f"FUS position 521 is {fus[520]}, expected R"
fus_r521h = fus[:520] + "H" + fus[521:]
fus_pld = fus_r521h[:214]

clients = {
    "HTT_polyQ_APR": htt_134q,
    "mutFUS_APR": fus_pld,
    "Orb2_core": None,     # filled from structural definition
    "hCPEB3_core": None,
}
core = json.load(open(RES / "core_definitions.json"))
clients["Orb2_core"] = core["orb2_core"]
clients["hCPEB3_core"] = core["cpeb3_core"]

with open(DATA / "clients.fasta", "w") as fh:
    for k, v in clients.items():
        fh.write(f">{k}\n{v}\n")
for k, v in clients.items():
    print(f"[ok] {k}: {len(v)} aa")
json.dump({"HTT_N17": n17, "HTT_PRD": prd, "FUS_R521H_full": fus_r521h},
          open(DATA / "client_construct_details.json", "w"), indent=1)
