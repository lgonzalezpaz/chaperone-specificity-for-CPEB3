#!/usr/bin/env python3
"""
cg_engine.py

Fast just-in-time-compiled Langevin engine for the CALVADOS 2
residue-resolution coarse-grained model, used for umbrella sampling of
chaperone-client association free energies.

The potential is identical to the reference OpenMM implementation
(see calvados_cg.py for the functional form and citations); forces are
the analytic derivatives. Agreement with OpenMM is verified in
tests/test_engine_vs_openmm.py and reported in the manuscript.

Unit system: nm, ps, amu, kJ/mol (acceleration = force/mass).
Integrator: BAOAB / LangevinMiddle, matching openmm.LangevinMiddleIntegrator.
"""
from __future__ import annotations

import numpy as np
from numba import njit, prange

EPS_LJ = 0.2 * 4.184     # kJ/mol
RC_AH = 2.0              # nm
RC_YU = 4.0              # nm
KB_BOND = 8033.0         # kJ/mol/nm^2
R0_BOND = 0.38           # nm
TWO_1_6 = 2.0 ** (1.0 / 6.0)
R_GAS = 0.0083145        # kJ/mol/K


@njit(cache=True, fastmath=True)
def _forces(x, sig, lam, q, bond_i, bond_j, excl, eps_yu, k_yu,
            shift_yu, f):
    n = x.shape[0]
    f[:, :] = 0.0
    u = 0.0
    # ---- bonded
    for b in range(bond_i.shape[0]):
        i, j = bond_i[b], bond_j[b]
        dx = x[j, 0] - x[i, 0]
        dy = x[j, 1] - x[i, 1]
        dz = x[j, 2] - x[i, 2]
        r = np.sqrt(dx * dx + dy * dy + dz * dz)
        dr = r - R0_BOND
        u += 0.5 * KB_BOND * dr * dr
        g = KB_BOND * dr / r
        f[i, 0] += g * dx; f[i, 1] += g * dy; f[i, 2] += g * dz
        f[j, 0] -= g * dx; f[j, 1] -= g * dy; f[j, 2] -= g * dz
    # ---- nonbonded
    for i in range(n - 1):
        for j in range(i + 1, n):
            if excl[i, j]:
                continue
            dx = x[j, 0] - x[i, 0]
            dy = x[j, 1] - x[i, 1]
            dz = x[j, 2] - x[i, 2]
            r2 = dx * dx + dy * dy + dz * dz
            if r2 > RC_YU * RC_YU:
                continue
            r = np.sqrt(r2)
            dudr = 0.0
            # Ashbaugh-Hatch
            if r < RC_AH:
                s = 0.5 * (sig[i] + sig[j])
                l = 0.5 * (lam[i] + lam[j])
                sr = s / r
                sr6 = sr ** 6
                sr12 = sr6 * sr6
                src = s / RC_AH
                src6 = src ** 6
                shift = src6 * src6 - src6
                if r > TWO_1_6 * s:
                    u += 4.0 * EPS_LJ * l * (sr12 - sr6 - shift)
                    dudr += 4.0 * EPS_LJ * l * (-12.0 * sr12 + 6.0 * sr6) / r
                else:
                    u += 4.0 * EPS_LJ * (sr12 - sr6 - l * shift) + (1.0 - l) * EPS_LJ
                    dudr += 4.0 * EPS_LJ * (-12.0 * sr12 + 6.0 * sr6) / r
            # Debye-Huckel (Yukawa), shifted
            qq = q[i] * q[j]
            if qq != 0.0:
                a = qq * eps_yu
                e = np.exp(-k_yu * r)
                u += a * (e / r - shift_yu)
                dudr += -a * e * (k_yu * r + 1.0) / r2
            g = -dudr / r
            f[i, 0] -= g * dx; f[i, 1] -= g * dy; f[i, 2] -= g * dz
            f[j, 0] += g * dx; f[j, 1] += g * dy; f[j, 2] += g * dz
    return u


@njit(cache=True, fastmath=True)
def _com(x, w, lo, hi):
    cx = cy = cz = 0.0
    tw = 0.0
    for i in range(lo, hi):
        cx += w[i] * x[i, 0]; cy += w[i] * x[i, 1]; cz += w[i] * x[i, 2]
        tw += w[i]
    return cx / tw, cy / tw, cz / tw


@njit(cache=True, fastmath=True)
def _apply_com_bias(x, w, n1, n, kum, r0, rwall, kwall, f):
    """
    Biases acting on the chain-centroid separation r:
      umbrella       U = 0.5 kum (r - r0)^2          (kum > 0)
      flat-bottom    U = 0.5 kwall (r - rwall)^2     for r > rwall
    The flat-bottom wall defines the sampling volume V = (4/3) pi rwall^3
    used in the standard-state correction. Returns (U, r).
    """
    ax, ay, az = _com(x, w, 0, n1)
    bx, by, bz = _com(x, w, n1, n)
    dx, dy, dz = bx - ax, by - ay, bz - az
    r = np.sqrt(dx * dx + dy * dy + dz * dz)

    dudr = 0.0
    u = 0.0
    if kum > 0.0:
        dr = r - r0
        u += 0.5 * kum * dr * dr
        dudr += kum * dr
    if r > rwall:
        dr = r - rwall
        u += 0.5 * kwall * dr * dr
        dudr += kwall * dr
    if dudr == 0.0:
        return 0.0, r

    g = dudr / r
    wa = 0.0
    for i in range(0, n1):
        wa += w[i]
    wb = 0.0
    for i in range(n1, n):
        wb += w[i]
    for i in range(0, n1):
        c = g * w[i] / wa
        f[i, 0] += c * dx; f[i, 1] += c * dy; f[i, 2] += c * dz
    for i in range(n1, n):
        c = g * w[i] / wb
        f[i, 0] -= c * dx; f[i, 1] -= c * dy; f[i, 2] -= c * dz
    return u, r


@njit(cache=True, fastmath=True)
def minimize(x, sig, lam, q, bond_i, bond_j, excl, eps_yu, k_yu, shift_yu,
             n_iter=4000, max_disp=0.02):
    """
    Displacement-capped steepest descent, used to relieve steric overlaps in
    randomly generated start configurations before dynamics.
    """
    n = x.shape[0]
    f = np.zeros_like(x)
    u = _forces(x, sig, lam, q, bond_i, bond_j, excl, eps_yu, k_yu, shift_yu, f)
    step = 1e-5
    for _ in range(n_iter):
        fmax = 0.0
        for i in range(n):
            for d in range(3):
                a = abs(f[i, d])
                if a > fmax:
                    fmax = a
        if fmax < 1e-8:
            break
        sc = step
        if sc * fmax > max_disp:
            sc = max_disp / fmax
        xo = x.copy()
        for i in range(n):
            for d in range(3):
                x[i, d] += sc * f[i, d]
        un = _forces(x, sig, lam, q, bond_i, bond_j, excl,
                     eps_yu, k_yu, shift_yu, f)
        if un < u:
            u = un
            step *= 1.2
        else:
            x[:, :] = xo
            _forces(x, sig, lam, q, bond_i, bond_j, excl,
                    eps_yu, k_yu, shift_yu, f)
            step *= 0.5
            if step < 1e-12:
                break
    return u


@njit(cache=True, fastmath=True)
def run_baoab(x, v, mass, sig, lam, q, bond_i, bond_j, excl,
              eps_yu, k_yu, shift_yu, temp, gamma, dt,
              n_steps, stride, kum, r0, n1, rwall, kwall, seed):
    """BAOAB Langevin dynamics; returns (r_COM samples, potential samples)."""
    np.random.seed(seed)
    n = x.shape[0]
    f = np.zeros_like(x)
    kT = R_GAS * temp
    a = np.exp(-gamma * dt)
    b = np.sqrt(1.0 - a * a)
    sd = np.empty(n)
    for i in range(n):
        sd[i] = np.sqrt(kT / mass[i])
    n_out = n_steps // stride
    rs = np.empty(n_out)
    us = np.empty(n_out)
    _forces(x, sig, lam, q, bond_i, bond_j, excl, eps_yu, k_yu, shift_yu, f)
    _apply_com_bias(x, mass, n1, n, kum, r0, rwall, kwall, f)
    k = 0
    for step in range(n_steps):
        for i in range(n):
            im = 0.5 * dt / mass[i]
            v[i, 0] += im * f[i, 0]; v[i, 1] += im * f[i, 1]; v[i, 2] += im * f[i, 2]
        for i in range(n):
            x[i, 0] += 0.5 * dt * v[i, 0]
            x[i, 1] += 0.5 * dt * v[i, 1]
            x[i, 2] += 0.5 * dt * v[i, 2]
        for i in range(n):
            v[i, 0] = a * v[i, 0] + b * sd[i] * np.random.normal()
            v[i, 1] = a * v[i, 1] + b * sd[i] * np.random.normal()
            v[i, 2] = a * v[i, 2] + b * sd[i] * np.random.normal()
        for i in range(n):
            x[i, 0] += 0.5 * dt * v[i, 0]
            x[i, 1] += 0.5 * dt * v[i, 1]
            x[i, 2] += 0.5 * dt * v[i, 2]
        u = _forces(x, sig, lam, q, bond_i, bond_j, excl,
                    eps_yu, k_yu, shift_yu, f)
        uu, r = _apply_com_bias(x, mass, n1, n, kum, r0, rwall, kwall, f)
        u += uu
        for i in range(n):
            im = 0.5 * dt / mass[i]
            v[i, 0] += im * f[i, 0]; v[i, 1] += im * f[i, 1]; v[i, 2] += im * f[i, 2]
        if (step + 1) % stride == 0 and k < n_out:
            rs[k] = r
            us[k] = u
            k += 1
    return rs[:k], us[:k]


@njit(cache=True, fastmath=True)
def run_bound_ensemble(x, v, mass, sig, lam, q, bond_i, bond_j, excl,
                       eps_yu, k_yu, shift_yu, temp, gamma, dt,
                       n_steps, stride, n1, rwall, kwall, cutoff, seed):
    """
    Dynamics under a flat-bottom restraint only, accumulating intermolecular
    contact counts and per-residue intermolecular interaction energies over
    frames in which the two chains are in contact.

    Returns (contacts_A, contacts_B, energy_A, energy_B, n_bound, n_frames).
    """
    np.random.seed(seed)
    n = x.shape[0]
    f = np.zeros_like(x)
    kT = R_GAS * temp
    a = np.exp(-gamma * dt)
    b = np.sqrt(1.0 - a * a)
    sd = np.empty(n)
    for i in range(n):
        sd[i] = np.sqrt(kT / mass[i])
    cA = np.zeros(n1)
    cB = np.zeros(n - n1)
    eA = np.zeros(n1)
    eB = np.zeros(n - n1)
    c2 = cutoff * cutoff
    n_bound = 0
    n_frames = 0
    _forces(x, sig, lam, q, bond_i, bond_j, excl, eps_yu, k_yu, shift_yu, f)
    _apply_com_bias(x, mass, n1, n, 0.0, 0.0, rwall, kwall, f)
    for step in range(n_steps):
        for i in range(n):
            im = 0.5 * dt / mass[i]
            v[i, 0] += im * f[i, 0]; v[i, 1] += im * f[i, 1]; v[i, 2] += im * f[i, 2]
        for i in range(n):
            x[i, 0] += 0.5 * dt * v[i, 0]
            x[i, 1] += 0.5 * dt * v[i, 1]
            x[i, 2] += 0.5 * dt * v[i, 2]
        for i in range(n):
            v[i, 0] = a * v[i, 0] + b * sd[i] * np.random.normal()
            v[i, 1] = a * v[i, 1] + b * sd[i] * np.random.normal()
            v[i, 2] = a * v[i, 2] + b * sd[i] * np.random.normal()
        for i in range(n):
            x[i, 0] += 0.5 * dt * v[i, 0]
            x[i, 1] += 0.5 * dt * v[i, 1]
            x[i, 2] += 0.5 * dt * v[i, 2]
        _forces(x, sig, lam, q, bond_i, bond_j, excl, eps_yu, k_yu, shift_yu, f)
        _apply_com_bias(x, mass, n1, n, 0.0, 0.0, rwall, kwall, f)
        for i in range(n):
            im = 0.5 * dt / mass[i]
            v[i, 0] += im * f[i, 0]; v[i, 1] += im * f[i, 1]; v[i, 2] += im * f[i, 2]

        if (step + 1) % stride == 0:
            n_frames += 1
            touched = False
            for i in range(n1):
                for j in range(n1, n):
                    dx = x[j, 0] - x[i, 0]
                    dy = x[j, 1] - x[i, 1]
                    dz = x[j, 2] - x[i, 2]
                    r2 = dx * dx + dy * dy + dz * dz
                    if r2 < c2:
                        cA[i] += 1.0
                        cB[j - n1] += 1.0
                        touched = True
                    if r2 < RC_YU * RC_YU:
                        r = np.sqrt(r2)
                        u = 0.0
                        if r < RC_AH:
                            s = 0.5 * (sig[i] + sig[j])
                            l = 0.5 * (lam[i] + lam[j])
                            sr6 = (s / r) ** 6
                            sr12 = sr6 * sr6
                            src6 = (s / RC_AH) ** 6
                            shift = src6 * src6 - src6
                            if r > TWO_1_6 * s:
                                u += 4.0 * EPS_LJ * l * (sr12 - sr6 - shift)
                            else:
                                u += (4.0 * EPS_LJ * (sr12 - sr6 - l * shift)
                                      + (1.0 - l) * EPS_LJ)
                        qq = q[i] * q[j]
                        if qq != 0.0:
                            u += qq * eps_yu * (np.exp(-k_yu * r) / r - shift_yu)
                        eA[i] += 0.5 * u
                        eB[j - n1] += 0.5 * u
            if touched:
                n_bound += 1
    return cA, cB, eA, eB, n_bound, n_frames


@njit(cache=True, fastmath=True)
def contact_counts(x, n1, n, cutoff):
    """Per-residue intermolecular contact counts within a distance cutoff."""
    ca = np.zeros(n1)
    cb = np.zeros(n - n1)
    c2 = cutoff * cutoff
    for i in range(n1):
        for j in range(n1, n):
            dx = x[j, 0] - x[i, 0]
            dy = x[j, 1] - x[i, 1]
            dz = x[j, 2] - x[i, 2]
            if dx * dx + dy * dy + dz * dz < c2:
                ca[i] += 1.0
                cb[j - n1] += 1.0
    return ca, cb
