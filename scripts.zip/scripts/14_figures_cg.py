#!/usr/bin/env python3
"""
14_figures_cg.py  --  figures for the coarse-grained association analysis

Figure 5  potentials of mean force and standard-state binding free energies
Figure 6  interface maps and the in-silico alanine scan
Figure 7  controlled grammar titration on an invariant Orb2 scaffold
"""
import json
import pathlib
import warnings
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy import stats

warnings.filterwarnings("ignore")
ROOT = pathlib.Path(__file__).resolve().parents[1]
RES, FIG = ROOT / "results", ROOT / "figures"
CG = RES / "cg"
FIG.mkdir(exist_ok=True, parents=True)

C = ["#0072B2", "#D55E00", "#009E73", "#E69F00", "#CC79A7", "#56B4E9"]
MARKERS = ["o", "s", "^", "D", "v", "P"]
INK, INK2, MUTED, GRID = "#1a1a1a", "#4d4d4d", "#8c8c8c", "#d9d9d9"
mpl.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["DejaVu Sans", "Arial"],
    "font.size": 7.5, "axes.labelsize": 8, "axes.titlesize": 8.5,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 6.8,
    "axes.edgecolor": INK2, "axes.linewidth": 0.6,
    "xtick.color": INK2, "ytick.color": INK2,
    "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "xtick.major.size": 2.5, "ytick.major.size": 2.5,
    "text.color": INK, "axes.labelcolor": INK,
    "grid.color": GRID, "grid.linewidth": 0.5,
    "lines.linewidth": 1.4, "legend.frameon": False,
    "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
    "pdf.fonttype": 42, "ps.fonttype": 42})
CM = 1 / 2.54


def save(fig, name):
    fig.savefig(FIG / f"{name}.pdf"); fig.savefig(FIG / f"{name}.png", dpi=600)
    plt.close(fig); print(f"[ok] {name}")


def panel(ax, s, dx=-0.17, dy=1.07):
    ax.text(dx, dy, s, transform=ax.transAxes, fontsize=10, fontweight="bold",
            va="top", ha="left", color=INK)


def tidy(ax, grid="y"):
    for sp in ("top", "right"):
        ax.spines[sp].set_visible(False)
    if grid:
        ax.grid(axis=grid, alpha=0.8, zorder=0); ax.set_axisbelow(True)


LAB = {"Orb2_core": "Orb2 core", "hCPEB3_core": "hCPEB3 core",
       "hCPEB3_core_shuffled": "hCPEB3 core, scrambled",
       "Orb2_LVLVF": "Orb2 LVLVF", "Orb2_FVLVF": "Orb2 FVLVF",
       "Orb2_FIMMF": "Orb2 FIMMF"}

cg = pd.read_csv(RES / "cg_summary.tsv", sep="\t")
cg["label"] = cg.chaperone + " + " + cg.client.map(lambda c: LAB.get(c, c))

# ====================================================== FIGURE 5
show = [("Funes", "Orb2_core"), ("Funes", "hCPEB3_core"),
        ("DNAJC8", "Orb2_core"), ("DNAJC8", "hCPEB3_core"),
        ("DNAJB2", "hCPEB3_core"), ("DNAJB8", "Orb2_core")]
fig, axes = plt.subplots(1, 2, figsize=(18 * CM, 7.2 * CM),
                         gridspec_kw=dict(width_ratios=[1, 1.25], wspace=0.30))

ax = axes[0]; panel(ax, "a")
k = 0
for chap, client in show:
    f = CG / f"{chap}__{client}.npz"
    if not f.exists():
        continue
    d = np.load(f)
    r, w = d["r"], d["w"]
    m = np.isfinite(w) & (r <= 6.6)
    ax.plot(r[m], w[m], color=C[k % len(C)], marker=MARKERS[k % len(MARKERS)],
            ms=0, lw=1.3, label=f"{chap} + {LAB.get(client, client)}", zorder=3)
    k += 1
ax.axhline(0, color=MUTED, lw=0.6)
ax.set_xlabel("centroid separation, $r$ (nm)")
ax.set_ylabel("potential of mean force, $W(r)$ (kJ mol$^{-1}$)")
ax.set_ylim(-2.5, 9.0); ax.set_xlim(0.2, 6.7)
tidy(ax, grid="both")
ax.legend(loc="upper right", handlelength=1.5, fontsize=6.2)

ax = axes[1]; panel(ax, "b", dx=-0.12)
order = cg.sort_values(["client", "dG_kJmol"]).reset_index(drop=True)
clients = list(dict.fromkeys(order.client))
cmap = {c: C[i % len(C)] for i, c in enumerate(clients)}
y = np.arange(len(order))
ax.barh(y, order.dG_kJmol, xerr=order.dG_sd_kJmol,
        color=[cmap[c] for c in order.client], edgecolor="white", lw=0.5,
        height=0.74, zorder=3,
        error_kw=dict(ecolor=INK2, lw=0.7, capsize=2))
ax.set_yticks(y); ax.set_yticklabels(order.chaperone, fontsize=6.6)
for i, r in order.iterrows():
    ax.text(-0.25, i, f"{r.dG_kJmol:.1f}", va="center", ha="right",
            fontsize=6.0, color=INK)
ax.set_xlabel("standard-state association free energy, "
              "$\\Delta G^{\\circ}$ (kJ mol$^{-1}$)")
ax.set_xlim(0, min(order.dG_kJmol) * 1.22)
ax.invert_xaxis()
tidy(ax, grid="x")
ax.legend(handles=[Line2D([], [], marker="s", ls="none", color=cmap[c],
                          ms=6, label=LAB.get(c, c)) for c in clients],
          loc="upper center", bbox_to_anchor=(0.5, -0.16), handlelength=0.9,
          ncol=3, fontsize=6.2, columnspacing=1.0)
save(fig, "figure5_binding_free_energies")

# ====================================================== FIGURE 6
LADDER = ["Orb2_core", "Orb2_LVLVF", "Orb2_FVLVF", "Orb2_FIMMF", "hCPEB3_core"]
lad = cg[cg.client.isin(LADDER)]
if lad.client.nunique() >= 3:
    fig, axes = plt.subplots(1, 2, figsize=(18 * CM, 7.0 * CM),
                             gridspec_kw=dict(width_ratios=[1.15, 1],
                                              wspace=0.32))
    seqs = json.load(open(RES / "designed_orb2_cores.json"))
    core = pd.read_csv(RES / "core_sequences.tsv", sep="\t")
    SEQ = {"Orb2_core": core.loc[core.pdb == "6VPS", "sequence"].iloc[0],
           "hCPEB3_core": core.loc[core.pdb == "8SPA", "sequence"].iloc[0],
           "Orb2_LVLVF": seqs.get("9PX8"), "Orb2_FVLVF": seqs.get("9YWA"),
           "Orb2_FIMMF": seqs.get("9Y1V")}
    CAL = pd.read_csv(ROOT / "data" / "residues_CALVADOS2.csv").set_index("one")
    LAMD = CAL["lambdas"].to_dict()

    LADDER_CHAPS = sorted(
        lad[lad.client.str.startswith("Orb2_") & (lad.client != "Orb2_core")]
        .chaperone.unique())
    lad = lad[lad.chaperone.isin(LADDER_CHAPS)]
    ax = axes[0]; panel(ax, "a")
    for i, chap in enumerate(LADDER_CHAPS):
        sub = lad[lad.chaperone == chap].copy()
        sub["lam"] = sub.client.map(
            lambda c: np.mean([LAMD[x] for x in SEQ[c]]) if SEQ.get(c) else np.nan)
        sub = sub.dropna(subset=["lam"]).sort_values("lam")
        ax.errorbar(sub.lam, sub.dG_kJmol, yerr=sub.dG_sd_kJmol,
                    color=C[i % len(C)], marker=MARKERS[i % len(MARKERS)],
                    ms=5, lw=1.2, capsize=2, label=chap, zorder=3)
    ax.set_xlabel("client mean CALVADOS stickiness, $\\bar{\\lambda}$")
    ax.set_ylabel("$\\Delta G^{\\circ}$ (kJ mol$^{-1}$)")
    ax.set_ylim(-12.2, -9.6)
    tidy(ax, grid="both")
    ax.legend(loc="lower left", handlelength=1.5, ncol=2)

    ax = axes[1]; panel(ax, "b", dx=-0.19)
    present = [c for c in LADDER if c in set(lad.client)]
    chaps = LADDER_CHAPS
    w = 0.8 / max(1, len(chaps))
    for i, chap in enumerate(chaps):
        sub = lad[lad.chaperone == chap].set_index("client")
        vals = [sub.dG_kJmol.get(c, np.nan) for c in present]
        errs = [sub.dG_sd_kJmol.get(c, np.nan) for c in present]
        ax.bar(np.arange(len(present)) + (i - (len(chaps) - 1) / 2) * w, vals,
               yerr=errs, width=w * 0.86, color=C[i % len(C)],
               edgecolor="white", lw=0.5, label=chap, zorder=3,
               error_kw=dict(ecolor=INK2, lw=0.7, capsize=1.8))
    ax.set_xticks(np.arange(len(present)))
    ax.set_xticklabels([LAB.get(c, c).replace(" ", "\n") for c in present],
                       fontsize=6.4)
    ax.set_ylabel("$\\Delta G^{\\circ}$ (kJ mol$^{-1}$)")
    ax.set_ylim(-12.2, 0)
    tidy(ax)
    ax.legend(loc="lower center", handlelength=0.9, ncol=len(chaps),
              fontsize=6.6, bbox_to_anchor=(0.5, 0.01))
    save(fig, "figure6_grammar_titration")
# ====================================================== FIGURE 7
hs_files = sorted(RES.glob("hotspots_*.tsv"))
if hs_files:
    pick = [f for f in hs_files if "DNAJB2__hCPEB3_core" in f.name] or hs_files
    hs = pd.read_csv(pick[0], sep="\t")
    sysname = pick[0].stem.replace("hotspots_", "")
    chap_name, client_name = sysname.split("__")
    scan = pd.read_csv(RES / "alanine_scan.tsv", sep="\t") \
        if (RES / "alanine_scan.tsv").exists() else pd.DataFrame()
    ncol = 3 if len(scan) else 2
    fig, axes = plt.subplots(1, ncol, figsize=(18 * CM, 6.6 * CM),
                             gridspec_kw=dict(wspace=0.38))
    cl = hs[hs.chain == "client"].reset_index(drop=True)
    ax = axes[0]; panel(ax, "a")
    cols = [C[4] if a in "FWY" else (C[2] if a in "AVLIM" else MUTED)
            for a in cl.aa]
    ax.bar(np.arange(len(cl)), cl.contacts_per_frame, color=cols,
           edgecolor="white", lw=0.4, width=0.82, zorder=3)
    ax.set_xticks(np.arange(len(cl))[::4])
    ax.set_xticklabels([f"{a}{n}" for a, n in zip(cl.aa, cl.resnum)][::4],
                       rotation=90, fontsize=5.6)
    ax.set_ylabel("intermolecular contacts per frame")
    ax.set_xlabel(f"{LAB.get(client_name, client_name)} residue")
    tidy(ax)
    ax.legend(handles=[Line2D([], [], marker="s", ls="none", color=C[4], ms=6,
                              label="aromatic"),
                       Line2D([], [], marker="s", ls="none", color=C[2], ms=6,
                              label="aliphatic"),
                       Line2D([], [], marker="s", ls="none", color=MUTED, ms=6,
                              label="other")], loc="upper left",
              handlelength=0.9, ncol=3, columnspacing=0.8)

    ax = axes[1]; panel(ax, "b", dx=-0.26)
    ax.bar(np.arange(len(cl)), cl.energy_kJmol, color=cols, edgecolor="white",
           lw=0.4, width=0.82, zorder=3)
    top = cl.nsmallest(4, "energy_kJmol").sort_values("idx").reset_index(drop=True)
    ylo = float(cl.energy_kJmol.min())
    ax.set_ylim(ylo * 1.55, 0)
    for k, r in top.iterrows():
        ax.annotate(f"{r.aa}{int(r.resnum)}", (r.idx - 1, r.energy_kJmol),
                    textcoords="offset points",
                    xytext=(0, -10 - 9 * (k % 2)), fontsize=6.0,
                    ha="center", color=INK, fontweight="bold")
    ax.set_xticks(np.arange(len(cl))[::4])
    ax.set_xticklabels([f"{a}{n}" for a, n in zip(cl.aa, cl.resnum)][::4],
                       rotation=90, fontsize=5.6)
    ax.set_ylabel("intermolecular interaction energy (kJ mol$^{-1}$)")
    ax.set_xlabel(f"{LAB.get(client_name, client_name)} residue")
    tidy(ax)

    if len(scan):
        ax = axes[2]; panel(ax, "c", dx=-0.2)
        s = scan[scan.variant != "wild type"].copy()
        s["lab"] = s.variant.str.replace("client ", "").str.replace(
            "chaperone ", "")
        colr = [C[4] if c == "client" else C[0] for c in s.chain]
        ax.barh(np.arange(len(s)), s.ddG_kJmol, color=colr, edgecolor="white",
                lw=0.5, height=0.7, zorder=3)
        ax.set_yticks(np.arange(len(s))); ax.set_yticklabels(s.lab, fontsize=6.4)
        ax.axvline(0, color=INK2, lw=0.6)
        ax.set_xlabel("$\\Delta\\Delta G^{\\circ}$ on alanine substitution\n"
                      "(kJ mol$^{-1}$)")
        tidy(ax, grid="x")
        ax.legend(handles=[Line2D([], [], marker="s", ls="none", color=C[4],
                                  ms=6, label="client residue"),
                           Line2D([], [], marker="s", ls="none", color=C[0],
                                  ms=6, label="chaperone residue")],
                  loc="lower right", handlelength=0.9)
    fig.suptitle(f"interface of {chap_name} with the "
                 f"{LAB.get(client_name, client_name)}", fontsize=8,
                 y=1.03, color=INK2)
    save(fig, "figure7_interface_map")

print("[ok] coarse-grained figures complete")
