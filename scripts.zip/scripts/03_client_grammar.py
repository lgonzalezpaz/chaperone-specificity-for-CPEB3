#!/usr/bin/env python3
"""
03_client_grammar.py  --  PRISM-J Layer 2a (client recognition grammar)

Derives the physicochemical "recognition grammar" of the two client amyloid
cores directly from deposited cryo-EM coordinates:

  6VPS  Orb2 amyloid core isolated from Drosophila head        (2.6 A)
  8YAC  Funes-induced Orb2 amyloid                             (3.1 A)
  8SPA  human CPEB3 prion labile amyloid (PRD1 core)           (3.0 A)

For each core we compute (i) composition, (ii) per-residue solvent-accessible
surface area (Shrake-Rupley) in the biological assembly, (iii) the chemistry of
the solvent-facing (chaperone-accessible) surface, and (iv) a 6-dimensional
grammar vector used by the complementarity functional in script 04.

Outputs (results/):
  core_sequences.tsv        structurally resolved core segments
  core_sasa.tsv             per-residue SASA and burial classification
  grammar_vectors.tsv       6-D grammar vector per client core
"""
import pathlib
import warnings
import json
import numpy as np
import pandas as pd
from Bio.PDB import MMCIFParser, ShrakeRupley
from Bio.SeqUtils import seq1
from Bio import SeqIO

warnings.filterwarnings("ignore")
ROOT = pathlib.Path(__file__).resolve().parents[1]
DATA, RES = ROOT / "data", ROOT / "results"
RES.mkdir(exist_ok=True, parents=True)

# ---------------------------------------------------------------- constants
# Kyte-Doolittle hydropathy (Kyte & Doolittle, J Mol Biol 1982, 157:105-132)
KD = dict(A=1.8, R=-4.5, N=-3.5, D=-3.5, C=2.5, Q=-3.5, E=-3.5, G=-0.4,
          H=-3.2, I=4.5, L=3.8, K=-3.9, M=1.9, F=2.8, P=-1.6, S=-0.8,
          T=-0.7, W=-0.9, Y=-1.3, V=4.2)
# Eisenberg consensus hydrophobicity (Eisenberg et al., Faraday Symp 1982)
EIS = dict(A=0.62, R=-2.53, N=-0.78, D=-0.90, C=0.29, Q=-0.85, E=-0.74,
           G=0.48, H=-0.40, I=1.38, L=1.06, K=-1.50, M=0.64, F=1.19,
           P=0.12, S=-0.18, T=-0.05, W=0.81, Y=0.26, V=1.08)
# Maximum residue SASA in Gly-X-Gly (Tien et al., PLoS One 2013, 8:e80635)
MAXASA = dict(A=129, R=274, N=195, D=193, C=167, Q=225, E=223, G=104,
              H=224, I=197, L=201, K=236, M=224, F=240, P=159, S=155,
              T=172, W=285, Y=263, V=174)
AROMATIC = set("FWY")
HYDROPHOBIC = set("AVLIMFWCY")
POLAR_AMIDE = set("QN")
CHARGED = set("DEKR")

STRUCTS = {
    "6VPS": dict(label="Orb2 core (endogenous, fly head)", offset=0,
                 client="Orb2", species="D. melanogaster"),
    "8YAC": dict(label="Orb2 core (Funes-induced)", offset=0,
                 client="Orb2", species="D. melanogaster"),
    "8SPA": dict(label="hCPEB3 PRD1 core (labile amyloid)", offset=101,
                 client="hCPEB3", species="H. sapiens"),
}

parser = MMCIFParser(QUIET=True)
sr = ShrakeRupley()

core_rows, sasa_rows, gram_rows = [], [], []

for pdb, info in STRUCTS.items():
    st = parser.get_structure(pdb, DATA / "structures" / f"{pdb}.cif")
    model = st[0]
    chains = [c for c in model]
    # Shrake-Rupley on the full deposited assembly: burial therefore reflects
    # both intra-sheet and inter-protofilament packing.
    sr.compute(model, level="R")

    # the central chain of the stack is the least edge-biased
    mid = chains[len(chains) // 2]
    res = [r for r in mid if r.id[0] == " "]
    seq = "".join(seq1(r.get_resname()) for r in res)
    nums = [r.id[1] + info["offset"] for r in res]

    core_rows.append(dict(pdb=pdb, client=info["client"], label=info["label"],
                          n_chains=len(chains), core_len=len(seq),
                          first=nums[0], last=nums[-1], sequence=seq))

    rsa = []
    for r, n in zip(res, nums):
        aa = seq1(r.get_resname())
        val = r.sasa / MAXASA[aa]
        rsa.append(val)
        sasa_rows.append(dict(pdb=pdb, client=info["client"], resnum=n, aa=aa,
                              sasa=round(r.sasa, 2), rsa=round(val, 4),
                              exposed=bool(val >= 0.25)))
    rsa = np.array(rsa)

    exp = rsa >= 0.25           # standard relative-accessibility cut-off
    n = len(seq)

    def frac(sel, mask=None):
        s = np.array([c in sel for c in seq])
        if mask is None:
            return float(s.sum() / n)
        return float((s & mask).sum() / max(1, mask.sum()))

    gram_rows.append(dict(
        pdb=pdb, client=info["client"], core_len=n,
        f_Q=frac("Q"), f_QN=frac(POLAR_AMIDE), f_H=frac("H"),
        f_aromatic=frac(AROMATIC), f_hydrophobic=frac(HYDROPHOBIC),
        f_charged=frac(CHARGED), f_G=frac("G"), f_P=frac("P"), f_ST=frac("ST"),
        mean_KD=float(np.mean([KD[c] for c in seq])),
        mean_Eisenberg=float(np.mean([EIS[c] for c in seq])),
        surf_f_QN=frac(POLAR_AMIDE, exp), surf_f_aromatic=frac(AROMATIC, exp),
        surf_f_hydrophobic=frac(HYDROPHOBIC, exp), surf_f_charged=frac(CHARGED, exp),
        mean_RSA=float(rsa.mean()), frac_exposed=float(exp.mean()),
    ))

core = pd.DataFrame(core_rows)
sasa = pd.DataFrame(sasa_rows)
gram = pd.DataFrame(gram_rows)
core.to_csv(RES / "core_sequences.tsv", sep="\t", index=False)
sasa.to_csv(RES / "core_sasa.tsv", sep="\t", index=False)
gram.to_csv(RES / "grammar_vectors.tsv", sep="\t", index=False)

print(core[["pdb", "client", "n_chains", "core_len", "first", "last"]].to_string(index=False))
print()
for _, r in core.iterrows():
    print(f"{r.pdb} {r.client:8s} {r.first}-{r.last}: {r.sequence}")
print()
cols = ["pdb", "client", "f_Q", "f_H", "f_aromatic", "f_hydrophobic",
        "f_charged", "mean_KD", "surf_f_QN", "surf_f_aromatic", "frac_exposed"]
print(gram[cols].round(3).to_string(index=False))

# -------------------------------------------- verify numbering against UniProt
up = {r.id.split("|")[1]: str(r.seq) for r in SeqIO.parse(DATA / "cpeb_human.fasta", "fasta")}
cp3 = up["Q8NE35"]
s = core.loc[core.pdb == "8SPA", "sequence"].iloc[0]
idx = cp3.find(s)
print(f"\n[check] 8SPA core found in UniProt Q8NE35 at residues "
      f"{idx+1}-{idx+len(s)} (expected L103-F151): "
      f"{'PASS' if idx + 1 == 103 else 'FAIL'}")

orb = {r.id.split("|")[1]: str(r.seq) for r in SeqIO.parse(DATA / "orb2.fasta", "fasta")}
o2 = orb["Q9VSR3"]
s6 = core.loc[core.pdb == "6VPS", "sequence"].iloc[0]
s8 = core.loc[core.pdb == "8YAC", "sequence"].iloc[0]
print(f"[check] 6VPS and 8YAC cores identical: {'PASS' if s6 == s8 else 'FAIL'}")
print(f"[check] Orb2 core position in Q9VSR3 (Orb2B numbering): "
      f"{o2.find(s6)+1}-{o2.find(s6)+len(s6)}")

json.dump({"orb2_core": s6, "cpeb3_core": s,
           "cpeb3_core_start_uniprot": idx + 1},
          open(RES / "core_definitions.json", "w"), indent=1)
