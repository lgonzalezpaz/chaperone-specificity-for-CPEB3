#!/usr/bin/env python3
"""
08_expression_context.py  --  PRISM-J Layer 3 (biological context)

Quantifies, for every human J-domain protein, (i) expression across human
brain subregions, (ii) tissue-profile co-expression with CPEB3, and
(iii) annotated subcellular localisation, using public reference resources.

Data sources
  GTEx Analysis v8/v10 median gene-level TPM by tissue, via the GTEx portal
  API v2 (https://gtexportal.org/api/v2). GTEx Consortium, Science
  2020;369:1318-1330.
  Human Protein Atlas subcellular location table (version 24),
  https://www.proteinatlas.org/about/download. Thul PJ et al.,
  Science 2017;356:eaal3321.

Outputs (results/):
  gtex_median_tpm.tsv     median TPM per gene and tissue
  layer3_scores.tsv       brain expression, CPEB3 co-expression, localisation
"""
import pathlib
import sys
import time
import numpy as np
import pandas as pd
import requests
from scipy import stats

ROOT = pathlib.Path(__file__).resolve().parents[1]
DATA, RES = ROOT / "data", ROOT / "results"
API = "https://gtexportal.org/api/v2"
S = requests.Session()
S.headers.update({"User-Agent": "PRISM-J/1.0", "Accept": "application/json"})

BRAIN = ["Brain_Cortex", "Brain_Frontal_Cortex_BA9", "Brain_Hippocampus",
         "Brain_Amygdala", "Brain_Anterior_cingulate_cortex_BA24",
         "Brain_Caudate_basal_ganglia", "Brain_Cerebellum",
         "Brain_Cerebellar_Hemisphere", "Brain_Hypothalamus",
         "Brain_Nucleus_accumbens_basal_ganglia", "Brain_Putamen_basal_ganglia",
         "Brain_Spinal_cord_cervical_c-1", "Brain_Substantia_nigra"]


def get(url, params, tries=4):
    for k in range(tries):
        try:
            r = S.get(url, params=params, timeout=90)
            if r.status_code == 200:
                return r.json()
        except Exception as exc:
            sys.stderr.write(f"retry {k} {exc}\n")
        time.sleep(2 * (k + 1))
    return None


meta = pd.read_csv(DATA / "human_jdp_meta.tsv", sep="\t")
jd = pd.read_csv(RES / "descriptors_jdp.tsv", sep="\t")
genes = sorted(set(jd.gene)) + ["CPEB3", "CPEB1", "CPEB2", "CPEB4"]

# ------------------------------------------------- resolve GENCODE ids
gc = {}
for g in genes:
    j = get(f"{API}/reference/gene", {"geneId": g, "page": 0, "itemsPerPage": 25})
    if not j:
        continue
    for rec in j.get("data", []):
        if rec.get("geneSymbolUpper") == g.upper() and rec.get("geneType") == "protein coding":
            gc[g] = rec["gencodeId"]
            break
    time.sleep(0.05)
print(f"[ok] GENCODE ids resolved for {len(gc)}/{len(genes)} genes")

# --------------------------------------------- median TPM by tissue
rows = []
ids = list(gc.values())
CH = 15
for i in range(0, len(ids), CH):
    chunk = ids[i:i + CH]
    j = get(f"{API}/expression/medianGeneExpression",
            {"gencodeId": chunk, "datasetId": "gtex_v8",
             "page": 0, "itemsPerPage": 6000})
    if not j:
        print(f"[warn] chunk {i} failed")
        continue
    for rec in j.get("data", []):
        rows.append(dict(gencodeId=rec["gencodeId"], tissue=rec["tissueSiteDetailId"],
                         tpm=float(rec["median"])))
    time.sleep(0.2)

e = pd.DataFrame(rows)
inv = {v: k for k, v in gc.items()}
e["gene"] = e.gencodeId.map(inv)
e = e.dropna(subset=["gene"])
M = e.pivot_table(index="gene", columns="tissue", values="tpm", aggfunc="median")
M.to_csv(RES / "gtex_median_tpm.tsv", sep="\t")
print(f"[ok] GTEx matrix: {M.shape[0]} genes x {M.shape[1]} tissues")

brain = [c for c in M.columns if c in BRAIN]
nonbrain = [c for c in M.columns if not c.startswith("Brain_")]
print(f"[info] brain subregions available: {len(brain)}; other tissues: {len(nonbrain)}")

# ---------------------------------------- co-expression with CPEB3
L = np.log2(M + 1.0)
ref = L.loc["CPEB3"]
rows = []
for g in L.index:
    if g == "CPEB3":
        rho, p = 1.0, 0.0
    else:
        rho, p = stats.spearmanr(L.loc[g], ref)
    rows.append(dict(gene=g,
                     brain_tpm_median=float(M.loc[g, brain].median()),
                     brain_tpm_max=float(M.loc[g, brain].max()),
                     cortex_tpm=float(M.loc[g].get("Brain_Cortex", np.nan)),
                     hippocampus_tpm=float(M.loc[g].get("Brain_Hippocampus", np.nan)),
                     nonbrain_tpm_median=float(M.loc[g, nonbrain].median()),
                     brain_enrichment_log2=float(
                         np.log2((M.loc[g, brain].median() + 1) /
                                 (M.loc[g, nonbrain].median() + 1))),
                     cpeb3_coexpr_rho=float(rho), cpeb3_coexpr_p=float(p)))
ctx = pd.DataFrame(rows)

# -------------------------------------------------- HPA localisation
loc = pd.read_csv(DATA / "hpa" / "subcellular_location.tsv", sep="\t")
loc = loc[["Gene name", "Reliability", "Main location", "Additional location"]]
loc.columns = ["gene", "hpa_reliability", "hpa_main_location", "hpa_additional_location"]
ctx = ctx.merge(loc, on="gene", how="left")

CYTO = ["Cytosol", "Cytoplasmic bodies", "Plasma membrane", "Actin filaments",
        "Microtubules", "Intermediate filaments", "Focal adhesion sites",
        "Cell Junctions", "Vesicles", "Endoplasmic reticulum", "Golgi apparatus"]


def cyto_flag(row):
    s = f"{row.hpa_main_location} {row.hpa_additional_location}"
    return any(k.lower() in str(s).lower() for k in CYTO)


ctx["cytoplasmic_pool"] = ctx.apply(cyto_flag, axis=1)
ctx = ctx.sort_values("brain_tpm_median", ascending=False)
ctx.to_csv(RES / "layer3_scores.tsv", sep="\t", index=False)

print("\n--- CPEB3 and the CPEB family ---")
print(ctx[ctx.gene.str.startswith("CPEB")][
    ["gene", "brain_tpm_median", "cortex_tpm", "hippocampus_tpm",
     "brain_enrichment_log2", "hpa_main_location"]].round(2).to_string(index=False))

print("\n--- J-domain proteins ranked by brain expression (top 15) ---")
j = ctx[~ctx.gene.str.startswith("CPEB")]
print(j.head(15)[["gene", "brain_tpm_median", "cortex_tpm", "hippocampus_tpm",
                  "brain_enrichment_log2", "cpeb3_coexpr_rho",
                  "hpa_main_location"]].round(2).to_string(index=False))

print("\n--- strongest CPEB3 tissue-profile co-expression among JDPs (top 10) ---")
print(j.nlargest(10, "cpeb3_coexpr_rho")[
    ["gene", "cpeb3_coexpr_rho", "cpeb3_coexpr_p", "brain_tpm_median",
     "brain_enrichment_log2"]].round(3).to_string(index=False))

print("\n--- DNAJC8 (the Funes sequence orthologue) in context ---")
print(ctx[ctx.gene == "DNAJC8"][
    ["gene", "brain_tpm_median", "cortex_tpm", "nonbrain_tpm_median",
     "brain_enrichment_log2", "cpeb3_coexpr_rho", "hpa_main_location",
     "hpa_additional_location", "cytoplasmic_pool"]].to_string(index=False))
