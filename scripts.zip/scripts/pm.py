import sys,json,urllib.request,os,ssl,time
ctx=ssl.create_default_context(cafile=os.path.expanduser('~/.ccr/ca-bundle.crt'))
for d in sys.argv[1:]:
    u="https://pmc.ncbi.nlm.nih.gov/tools/idconv/api/v1/articles/?format=json&ids="+d
    try:
        r=json.load(urllib.request.urlopen(u,context=ctx,timeout=30))
        print(d,[(x.get('pmid'),x.get('pmcid'),x.get('status')) for x in r.get('records',[])])
    except Exception as e: print(d,'ERR',e)
    time.sleep(0.4)
