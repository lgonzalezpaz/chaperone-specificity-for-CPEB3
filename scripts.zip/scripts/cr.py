import sys,json,urllib.request,os,ssl
ctx=ssl.create_default_context(cafile=os.path.expanduser('~/.ccr/ca-bundle.crt'))
for d in sys.argv[1:]:
    print("==",d)
    try:
        m=json.load(urllib.request.urlopen("https://api.crossref.org/works/"+d,context=ctx,timeout=30))['message']
    except Exception as e:
        print("ERR",e); continue
    au=[(a.get('family') or a.get('name','?'))+' '+''.join(x[0] for x in a.get('given','').replace('-',' ').split()) for a in m.get('author',[])]
    print("N authors",len(au)); print("AUTH:",', '.join(au))
    print("TITLE:",m['title'])
    print("JRN:",m.get('container-title'),"Y:",m.get('issued'),"V:",m.get('volume'),"I:",m.get('issue'),"P:",m.get('page'),m.get('article-number'))
