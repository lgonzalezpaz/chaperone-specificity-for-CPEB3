#!/usr/bin/env python3
"""
04_validation_dataset.py

Builds the independent experimental validation set used to test the PRISM-J
recognition-grammar hypothesis out of sample.

Source: Rozales K, Younis A, Saida N, Meller A, Goldman H, Kellerman L,
Heinrich R, Berlin S, Shalgi R. Differential roles for DNAJ isoforms in
HTT-polyQ and FUS aggregation modulation revealed by chaperone screens.
Nat Commun 2022;13:516. doi:10.1038/s41467-022-27982-w  (Source Data file,
sheets "2B" = HTT-polyQ screen, "3A" = mutant FUS screen).

The aggregation modulation score is log2[AGG+(chaperone)/AGG+(control)];
negative = aggregation alleviation, positive = aggregation aggravation.

Outputs (results/):
  rozales_scores.tsv     replicate-averaged scores per chaperone and client
"""
import pathlib
import numpy as np
import pandas as pd
import openpyxl

ROOT = pathlib.Path(__file__).resolve().parents[1]
RES = ROOT / "results"
XLSX = ROOT / "ext" / "rozales" / "41467_2022_27982_MOESM8_ESM.xlsx"
SHEETS = {"2B": "HTT_polyQ", "3A": "mutFUS"}

wb = openpyxl.load_workbook(XLSX, read_only=True, data_only=True)
frames = []
for sh, client in SHEETS.items():
    ws = wb[sh]
    rows = list(ws.iter_rows(values_only=True))
    hdr_rows = 2
    recs = []
    for r in rows[hdr_rows:]:
        name = r[0]
        if name is None or str(name).strip() == "":
            continue
        try:
            score = float(r[8])
        except (TypeError, ValueError):
            continue
        recs.append((str(name).strip(), score))
    d = pd.DataFrame(recs, columns=["chaperone", "score"])
    g = d.groupby("chaperone")["score"].agg(["mean", "std", "count"]).reset_index()
    g.columns = ["chaperone", "ams_mean", "ams_sd", "n_rep"]
    g["client"] = client
    frames.append(g)
    print(f"[ok] {sh} -> {client}: {len(g)} chaperones, "
          f"{int(d.shape[0])} replicate measurements")

sc = pd.concat(frames, ignore_index=True)
wide = sc.pivot(index="chaperone", columns="client", values="ams_mean")
wide = wide.dropna()

# control replicate dispersion defines the significance band used by the authors
ctrl = sc[sc.chaperone.str.contains("DsRed|control", case=False, na=False)]
print("\n[info] control entries:", ctrl.chaperone.unique().tolist())

sc.to_csv(RES / "rozales_scores.tsv", sep="\t", index=False)
wide.to_csv(RES / "rozales_scores_wide.tsv", sep="\t")

r = np.corrcoef(wide["HTT_polyQ"], wide["mutFUS"])[0, 1]
from scipy import stats
rho, p_rho = stats.spearmanr(wide["HTT_polyQ"], wide["mutFUS"])
print(f"\n[key] chaperones scored against both clients: n = {len(wide)}")
print(f"[key] Pearson r(HTT-polyQ, mutFUS) = {r:.3f}")
print(f"[key] Spearman rho = {rho:.3f}, P = {p_rho:.3g}")
print("\n--- strongest polyQ alleviators ---")
print(wide.sort_values("HTT_polyQ").head(8).round(3).to_string())
print("\n--- strongest mutFUS alleviators ---")
print(wide.sort_values("mutFUS").head(8).round(3).to_string())
print("\n--- DNAJ entries present ---")
print(sorted([c for c in wide.index if c.upper().startswith("DNAJ")]))
