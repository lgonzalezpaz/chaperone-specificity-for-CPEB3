#!/usr/bin/env python3
"""
13_figures.py  --  publication figures and tables for the PRISM-J manuscript

All panels use a fixed, colour-vision-deficiency-validated categorical order
(Okabe & Ito hues; validated for lightness band, chroma floor, adjacent-pair
CVD separation and normal-vision separation), carry a secondary encoding
(marker shape and direct labels) so identity is never colour-alone, and remain
legible in grayscale. Magnitude uses a single-hue sequential ramp.

Outputs: figures/*.pdf (vector) and figures/*.png (600 dpi), tables/*.tsv
"""
import json
import pathlib
import warnings
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch, Patch
from matplotlib.lines import Line2D
from scipy import stats

warnings.filterwarnings("ignore")
ROOT = pathlib.Path(__file__).resolve().parents[1]
RES, FIG, TAB = ROOT / "results", ROOT / "figures", ROOT / "tables"
FIG.mkdir(exist_ok=True, parents=True)
TAB.mkdir(exist_ok=True, parents=True)

# fixed categorical order, validated (worst adjacent CVD dE = 9.6)
C = ["#0072B2", "#D55E00", "#009E73", "#E69F00", "#CC79A7", "#56B4E9"]
MARKERS = ["o", "s", "^", "D", "v", "P"]
INK, INK2, MUTED = "#1a1a1a", "#4d4d4d", "#8c8c8c"
GRID = "#d9d9d9"

mpl.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["DejaVu Sans", "Arial", "Helvetica"],
    "font.size": 7.5, "axes.labelsize": 8, "axes.titlesize": 8.5,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 7,
    "axes.edgecolor": INK2, "axes.linewidth": 0.6,
    "xtick.color": INK2, "ytick.color": INK2,
    "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "xtick.major.size": 2.5, "ytick.major.size": 2.5,
    "text.color": INK, "axes.labelcolor": INK,
    "grid.color": GRID, "grid.linewidth": 0.5,
    "lines.linewidth": 1.4, "lines.markersize": 4,
    "legend.frameon": False, "figure.dpi": 150,
    "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
    "pdf.fonttype": 42, "ps.fonttype": 42,
})
CM = 1 / 2.54


def save(fig, name):
    fig.savefig(FIG / f"{name}.pdf")
    fig.savefig(FIG / f"{name}.png", dpi=600)
    plt.close(fig)
    print(f"[ok] {name}.pdf / .png")


def panel(ax, letter, dx=-0.16, dy=1.06):
    ax.text(dx, dy, letter, transform=ax.transAxes, fontsize=10,
            fontweight="bold", va="top", ha="left", color=INK)


def tidy(ax, grid="y"):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    if grid:
        ax.grid(axis=grid, alpha=0.8, zorder=0)
        ax.set_axisbelow(True)


# ------------------------------------------------------------------ inputs
core = pd.read_csv(RES / "core_sequences.tsv", sep="\t")
gram = pd.read_csv(RES / "grammar_vectors.tsv", sep="\t")
sasa = pd.read_csv(RES / "core_sasa.tsv", sep="\t")
L1 = pd.read_csv(RES / "layer1_scores.tsv", sep="\t")
rank = pd.read_csv(RES / "prismj_ranking.tsv", sep="\t")
roz = pd.read_csv(RES / "rozales_scores_wide.tsv", sep="\t")
roz = roz[roz.chaperone != "dsred"]
dc = pd.read_csv(RES / "descriptors_clients.tsv", sep="\t")
diag = json.load(open(RES / "diagnostics.json"))
integ = json.load(open(RES / "integration.json"))
gm = json.load(open(RES / "grammar_model.json"))
tpm = pd.read_csv(RES / "gtex_median_tpm.tsv", sep="\t", index_col=0)
designed = json.load(open(RES / "designed_orb2_cores.json")) \
    if (RES / "designed_orb2_cores.json").exists() else {}
cg = pd.read_csv(RES / "cg_summary.tsv", sep="\t") \
    if (RES / "cg_summary.tsv").exists() else pd.DataFrame()

CLIENT_LABEL = {"Orb2_core": "Orb2 core", "hCPEB3_core": "hCPEB3 core",
                "hCPEB3_core_shuffled": "hCPEB3 core, scrambled",
                "Orb2_LVLVF": "Orb2 LVLVF", "Orb2_FVLVF": "Orb2 FVLVF",
                "Orb2_FIMMF": "Orb2 FIMMF"}

# ====================================================== FIGURE 1
fig = plt.figure(figsize=(18 * CM, 18 * CM))
gs = fig.add_gridspec(3, 3, height_ratios=[0.90, 1.0, 0.82],
                      hspace=0.62, wspace=0.55)

# (a) modular architecture schematic, laid out in axes fractions so that
#     text and boxes scale together whatever the panel aspect ratio
ax = fig.add_subplot(gs[0, :]); ax.axis("off")
ax.text(-0.012, 1.17, "a", transform=ax.transAxes, fontsize=10,
        fontweight="bold", va="top", ha="left", color=INK)
T = ax.transAxes


def box(x0, w, y, h, fc, ec, label, fs=6.4):
    ax.add_patch(Rectangle((x0, y), w, h, facecolor=fc, edgecolor=ec, lw=0.8,
                           transform=T, clip_on=False))
    ax.text(x0 + w / 2, y + h / 2, label, ha="center", va="center", fontsize=fs,
            color=INK, transform=T)


def head(x0, y, s):
    ax.text(x0, y, s, fontsize=7.3, fontweight="bold", color=INK, va="top",
            transform=T)


def note(x0, y, s):
    ax.text(x0, y, s, fontsize=6.3, color=INK2, va="center", transform=T)


head(0.0, 1.00, "Funes (CG10375), $\\it{D.\\ melanogaster}$")
box(0.00, 0.115, 0.775, 0.145, "#cfe3f2", C[0], "J domain\n+ HPD")
box(0.115, 0.160, 0.775, 0.145, "#f2e0cf", C[1], "client-binding\nregion")
note(0.315, 0.848, "the C-terminal region binds oligomeric Orb2; the J domain "
                   "and its HPD\nmotif are required to convert oligomers into "
                   "translation-competent amyloid")

ax.annotate("", xy=(0.057, 0.765), xytext=(0.057, 0.575), xycoords=T,
            textcoords=T, arrowprops=dict(arrowstyle="-|>", color=C[0], lw=1.1,
                                          shrinkA=0, shrinkB=0))
ax.text(0.080, 0.670, "conserved", fontsize=6.0, color=C[0], va="center",
        rotation=90, ha="left", transform=T)
ax.annotate("", xy=(0.195, 0.765), xytext=(0.195, 0.575), xycoords=T,
            textcoords=T, arrowprops=dict(arrowstyle="-|>", color=MUTED, lw=1.1,
                                          ls=":", shrinkA=0, shrinkB=0))
ax.text(0.218, 0.670, "changed", fontsize=6.0, color=MUTED, va="center",
        rotation=90, ha="left", transform=T)

head(0.0, 0.515, "DNAJC8, $\\it{H.\\ sapiens}$ — closest sequence orthologue")
box(0.00, 0.115, 0.290, 0.145, "#cfe3f2", C[0], "J domain\n+ HPD")
box(0.115, 0.160, 0.290, 0.145, "#ececec", MUTED, "client-binding\nregion")
note(0.315, 0.363, "58.7% J-domain identity to Funes; the next closest human "
                   "J-domain\nprotein reaches only 34.7%")

head(0.0, 0.220, "the two clients, as resolved by cryo-EM")
box(0.00, 0.125, 0.015, 0.130, "#d6f0e6", C[2], "Orb2 core\n64.5% Gln")
ax.annotate("", xy=(0.168, 0.080), xytext=(0.136, 0.080), xycoords=T,
            textcoords=T, arrowprops=dict(arrowstyle="-|>", color=INK2, lw=1.1))
box(0.175, 0.140, 0.015, 0.130, "#f7dfec", C[4],
    "hCPEB3 core\n16.3% aromatic", fs=6.1)
note(0.330, 0.080, "the client's recognition surface changes chemical class; "
                   "the chaperone's\nHsp70-coupling module does not")

# (b) composition of the cryo-EM-defined cores
ax = fig.add_subplot(gs[1, 0]); panel(ax, "b", dx=-0.34)
cats = ["Gln", "His", "aromatic", "aliphatic", "charged"]
keys = ["f_Q", "f_H", "f_aromatic", "f_hydrophobic", "f_charged"]
pdbs = [("6VPS", "Orb2 (6VPS)", C[2]),
        ("8YAC", "Orb2, Funes-induced (8YAC)", C[0]),
        ("8SPA", "hCPEB3 (8SPA)", C[4])]
w = 0.26
for i, (pb, lab, col) in enumerate(pdbs):
    r = gram[gram.pdb == pb].iloc[0]
    ax.bar(np.arange(len(cats)) + (i - 1) * w, [r[k] * 100 for k in keys],
           width=w * 0.86, color=col, edgecolor="white", lw=0.6, label=lab,
           zorder=3)
ax.set_xticks(range(len(cats)))
ax.set_xticklabels(cats, rotation=40, ha="right")
ax.set_ylabel("residues in core (%)"); ax.set_ylim(0, 70)
tidy(ax)
ax.legend(loc="upper right", handlelength=0.9, labelspacing=0.26,
          fontsize=5.9, borderpad=0.1, handletextpad=0.5)

# (c) client grammar space with the engineered Orb2 ladder
ax = fig.add_subplot(gs[1, 1:]); panel(ax, "c", dx=-0.115)
cl = dc.set_index("client")


def frac(seq, sel):
    return sum(c in sel for c in seq) / len(seq)


pts = [("Orb2 core (6VPS)", core.loc[core.pdb == "6VPS", "sequence"].iloc[0],
        C[2], "^", (-6, -14)),
       ("hCPEB3 core (8SPA)", core.loc[core.pdb == "8SPA", "sequence"].iloc[0],
        C[4], "D", (9, -2)),
       ("HTT-polyQ", None, C[0], "o", (9, -2)),
       ("mutant FUS", None, C[1], "s", (9, -2))]
for lab, seq, col, mk, off in pts:
    if seq is not None:
        x, y = frac(seq, "QN") * 100, frac(seq, "FWY") * 100
    else:
        k = "HTT_polyQ_APR" if "HTT" in lab else "mutFUS_APR"
        x, y = cl.loc[k, "c_f_amide"] * 100, cl.loc[k, "c_f_aromatic"] * 100
    ax.scatter(x, y, s=62, color=col, marker=mk, edgecolor="white", lw=0.8,
               zorder=5)
    ax.annotate(lab, (x, y), textcoords="offset points", xytext=off,
                fontsize=6.6, color=col, fontweight="bold")
lx, ly = [], []
for pid in ("9PX8", "9YWA", "9Y1V"):
    if pid in designed:
        s = designed[pid]
        lx.append(frac(s, "QN") * 100); ly.append(frac(s, "FWY") * 100)
if lx:
    o = np.argsort(lx)
    ax.plot(np.array(lx)[o], np.array(ly)[o], color=C[2], lw=0.9, ls=":",
            zorder=3)
    ax.scatter(lx, ly, s=36, facecolor="white", edgecolor=C[2], lw=1.1,
               marker="^", zorder=5)
    ax.annotate("engineered Orb2 cores\n(9PX8, 9YWA, 9Y1V)",
                (float(np.max(lx)), float(np.mean(ly))),
                textcoords="offset points", xytext=(10, 2), fontsize=6.4,
                color=C[2], ha="left", va="center")
ax.annotate("", xy=(16.0, 15.2), xytext=(62.0, 1.2),
            arrowprops=dict(arrowstyle="-|>", color=MUTED, lw=0.9, ls="--",
                            alpha=0.9))
ax.text(44, 4.0, "grammar axis", fontsize=6.4, color=MUTED, rotation=-21,
        ha="center")
ax.set_xlabel("amide residues, Gln + Asn (%)")
ax.set_ylabel("aromatic residues (%)")
ax.set_xlim(0, 85); ax.set_ylim(-1.6, 19.5)
tidy(ax, grid="both")

# (d) solvent exposure along the two cores
ax = fig.add_subplot(gs[2, :]); panel(ax, "d", dx=-0.055)
for pb, lab, col, mk in [("6VPS", "Orb2 core", C[2], "^"),
                         ("8SPA", "hCPEB3 core", C[4], "D")]:
    s = sasa[sasa.pdb == pb].reset_index(drop=True)
    xs = np.arange(len(s))
    ax.plot(xs, s.rsa, color=col, marker=mk, ms=3.2, lw=1.1,
            label=f"{lab} ({pb})", zorder=3)
    for i, r in s.iterrows():
        if r.aa in "FWY":
            ax.scatter([i], [r.rsa], s=52, facecolor="none", edgecolor=col,
                       lw=1.1, zorder=5)
ax.axhline(0.25, color=MUTED, lw=0.7, ls="--", zorder=2)

ax.set_xlabel("position along the structurally ordered core")
ax.set_ylabel("relative solvent\naccessibility")
ax.set_xlim(-1, 49); ax.set_ylim(-0.03, 0.95)
tidy(ax, grid="y")
h, l = ax.get_legend_handles_labels()
h.append(Line2D([], [], marker="o", ls="none", mfc="none", mec=INK2, ms=6,
                label="aromatic residue"))
ax.legend(handles=h, loc="upper left", ncol=3, handlelength=1.2,
          columnspacing=1.2, fontsize=6.6, bbox_to_anchor=(0.14, 1.04))
save(fig, "figure1_client_grammar")

# ====================================================== FIGURE 2
fig, axes = plt.subplots(1, 2, figsize=(18 * CM, 7.2 * CM),
                         gridspec_kw=dict(width_ratios=[1.25, 1], wspace=0.34))
ax = axes[0]; panel(ax, "a")
NONHUMAN = ["Funes", "Mrj_Dmel", "JJJ2_Scer", "Sis1_Scer", "Ydj1_Scer",
            "DnaJ_Ecoli"]
h = L1[~L1.gene.isin(NONHUMAN)].nlargest(16, "sw_jdomain_norm").iloc[::-1]
cols = [C[0] if g == "DNAJC8" else (C[4] if g in ("DNAJB2", "DNAJC5", "DNAJB6")
        else MUTED) for g in h.gene]
ax.barh(np.arange(len(h)), h.sw_jdomain_norm, color=cols, edgecolor="white",
        lw=0.5, height=0.72, zorder=3)
ax.set_yticks(np.arange(len(h))); ax.set_yticklabels(h.gene)
ax.set_xlabel("J-domain similarity to Funes (normalised Smith–Waterman)")
ax.axvline(0, color=INK2, lw=0.6)
v8 = float(h.loc[h.gene == "DNAJC8", "sw_jdomain_norm"].iloc[0])
i8 = int(np.where(h.gene.values == "DNAJC8")[0][0])
ax.annotate(f"{v8:.3f}", (v8, i8), textcoords="offset points", xytext=(4, -2),
            fontsize=7, color=C[0], fontweight="bold")
nxt = h.sort_values("sw_jdomain_norm", ascending=False).iloc[1]
ax.annotate(f"{nxt.sw_jdomain_norm:.3f}",
            (nxt.sw_jdomain_norm, int(np.where(h.gene.values == nxt.gene)[0][0])),
            textcoords="offset points", xytext=(4, -2), fontsize=7, color=INK2)
tidy(ax, grid="x")
ax.legend(handles=[Patch(facecolor=C[0], label="sequence orthologue"),
                   Patch(facecolor=C[4], label="PRISM-J shortlist"),
                   Patch(facecolor=MUTED, label="other human JDPs")],
          loc="lower right", handlelength=1.0)

ax = axes[1]; panel(ax, "b")
F = rank.copy()
ax.scatter(F.L1_engine, F.PRISMJ_score, s=22, color=MUTED, marker="o",
           alpha=0.75, edgecolor="white", lw=0.4, zorder=3)
front = integ["pareto_front"]
hl = {"DNAJC8": (C[0], "o"), "DNAJB2": (C[4], "s"), "DNAJC5": (C[2], "^"),
      "DNAJB6": (C[1], "D"), "DNAJA4": (C[3], "v")}
OFF = {"DNAJC8": (-9, -14), "DNAJB2": (-34, 9), "DNAJC5": (-32, 4),
       "DNAJB6": (8, -9), "DNAJA4": (-34, -4)}
for g, (col, mk) in hl.items():
    r = F[F.gene == g]
    if len(r) == 0:
        continue
    ax.scatter(r.L1_engine, r.PRISMJ_score, s=70, color=col, marker=mk,
               edgecolor="white", lw=0.9, zorder=5)
    ax.annotate(g, (r.L1_engine.iloc[0], r.PRISMJ_score.iloc[0]),
                textcoords="offset points", xytext=OFF.get(g, (7, 3)),
                fontsize=7, color=col, fontweight="bold")
fr = F[F.gene.isin(front)].sort_values("L1_engine")
ax.plot(fr.L1_engine, fr.PRISMJ_score, color=INK2, lw=0.8, ls="--",
        zorder=2, label="Pareto front")
li = integ["layer_independence"]
ax.set_xlabel("Layer 1  Hsp70-coupling module (z)")
ax.set_ylabel("Layers 2 + 3  client chemistry and neuronal context (z)")
ax.text(0.98, 0.04, f"Spearman $\\rho$ = {li['rho_L1_prismj']:+.3f}, "
                    f"$P$ = {li['p_L1_prismj']:.2f}  ($n$ = {li['n']})",
        transform=ax.transAxes, fontsize=6.8, color=INK2, ha="right")
ax.set_xlim(F.L1_engine.min() - 0.45, F.L1_engine.max() + 0.75)
tidy(ax, grid="both")
ax.legend(loc="upper left", handlelength=1.4, fontsize=6.8)
save(fig, "figure2_layer_dissociation")

# ====================================================== FIGURE 3
fig, axes = plt.subplots(1, 3, figsize=(18 * CM, 7.0 * CM),
                         gridspec_kw=dict(width_ratios=[1.15, 1, 0.95],
                                          wspace=0.52))
ax = axes[0]; panel(ax, "a")
ax.axhline(0, color=MUTED, lw=0.6); ax.axvline(0, color=MUTED, lw=0.6)
ax.scatter(roz.HTT_polyQ, roz.mutFUS, s=20, color=MUTED, marker="o",
           alpha=0.8, edgecolor="white", lw=0.4, zorder=3)
OFF3 = {"DNAJB8": (7, 2), "DNAJC5": (9, 5), "DNAJB12-FL": (-8, 9),
        "DNAJC8": (7, 2)}
for g, col, mk in [("DNAJB8", C[2], "^"), ("DNAJC5", C[0], "o"),
                   ("DNAJB12-FL", C[1], "s"), ("DNAJC8", C[4], "D")]:
    r = roz[roz.chaperone == g]
    if len(r):
        ax.scatter(r.HTT_polyQ, r.mutFUS, s=60, color=col, marker=mk,
                   edgecolor="white", lw=0.8, zorder=5)
        ax.annotate(g, (r.HTT_polyQ.iloc[0], r.mutFUS.iloc[0]),
                    textcoords="offset points", xytext=OFF3[g], fontsize=6.6,
                    color=col, fontweight="bold", ha="left" if OFF3[g][0] > 0
                    else "right")
rr = diag["responders"]
ax.set_xlabel("aggregation modulation, HTT-polyQ")
ax.set_ylabel("aggregation modulation, mutant FUS")
ax.text(0.97, 0.05, f"$\\rho$ = {rr['spearman_rho']:.3f}, "
                    f"$P$ = {rr['spearman_p']:.2f}  ($n$ = 65)",
        transform=ax.transAxes, fontsize=6.8, color=INK2, ha="right")
ax.set_xlim(-1.35, 1.6); ax.set_ylim(-4.25, 0.72)
tidy(ax, grid="both")

ax = axes[1]; panel(ax, "b")
n = json.load(open(RES / "diagnostics.json"))["nested"]
labs = ["client\neffect\nonly", "+ chaperone\ncomposition",
        "+ bilinear\ninteraction\nterms"]
vals = [n["M0 client main effect"]["q2"], n["M1 + chaperone composition"]["q2"],
        n["M2 + bilinear interactions"]["q2"]]
ax.bar(range(3), vals, color=[MUTED, C[0], C[1]], edgecolor="white", lw=0.6,
       width=0.62, zorder=3)
for i, v in enumerate(vals):
    ax.text(i, v + 0.004, f"{v:.3f}", ha="center", fontsize=6.8, color=INK)
inc = json.load(open(RES / "diagnostics.json"))["increment"]
ax.set_xticks(range(3)); ax.set_xticklabels(labs)
ax.set_ylabel("$Q^2$, leave-one-chaperone-out")
ax.set_ylim(0, max(vals) * 1.45)
ax.text(0.03, 0.97, f"$\\Delta Q^2$ = {inc['dq2']:+.3f}\npermutation $P$ = "
                   f"{inc['permutation_p']:.3f}", transform=ax.transAxes,
        ha="left", va="top", fontsize=6.6, color=INK2)
tidy(ax)

ax = axes[2]; panel(ax, "c")
gd = diag["grammar_distance"]
pairs = [("Orb2 core /\nHTT-polyQ", gd["orb2_vs_polyQ"], C[2]),
         ("hCPEB3 core /\nmutant FUS", gd["cpeb3_vs_FUS"], C[4])]
cross = list(gd["cross"].values())
ax.bar([0, 1], [p[1] for p in pairs], color=[p[2] for p in pairs],
       edgecolor="white", lw=0.6, width=0.6, zorder=3)
ax.bar([2], [np.mean(cross)], yerr=[np.std(cross)], color=MUTED,
       edgecolor="white", lw=0.6, width=0.6, zorder=3,
       error_kw=dict(ecolor=INK2, lw=0.8, capsize=2.5))
ax.set_xticks([0, 1, 2])
ax.set_xticklabels(["Orb2 core\nvs\nHTT-polyQ", "hCPEB3 core\nvs\nmutant FUS",
                    "grammar-\nmismatched\npairs"], fontsize=6.3)
ax.set_ylabel("distance in client-grammar space")
tidy(ax)
save(fig, "figure3_client_specificity")

# ====================================================== FIGURE 4
fig, axes = plt.subplots(1, 2, figsize=(18 * CM, 7.0 * CM),
                         gridspec_kw=dict(width_ratios=[1, 1.2], wspace=0.3))
ax = axes[0]; panel(ax, "a")
F = rank.dropna(subset=["cpeb3_coexpr_rho"])
ax.scatter(np.log2(F.brain_tpm_median + 1), F.cpeb3_coexpr_rho, s=20,
           color=MUTED, alpha=0.8, edgecolor="white", lw=0.4, zorder=3)
for g, (col, mk) in hl.items():
    r = F[F.gene == g]
    if len(r):
        ax.scatter(np.log2(r.brain_tpm_median + 1), r.cpeb3_coexpr_rho, s=70,
                   color=col, marker=mk, edgecolor="white", lw=0.9, zorder=5)
        ax.annotate(g, (np.log2(r.brain_tpm_median.iloc[0] + 1),
                        r.cpeb3_coexpr_rho.iloc[0]),
                    textcoords="offset points", xytext=(6, 3), fontsize=7,
                    color=col, fontweight="bold")
ax.axhline(0, color=MUTED, lw=0.6)
ax.set_xlabel("brain expression, $\\log_2$(median TPM + 1)")
ax.set_ylabel("tissue-profile co-expression with CPEB3 ($\\rho$)")
tidy(ax, grid="both")

ax = axes[1]; panel(ax, "b", dx=-0.1)
genes = ["CPEB3", "DNAJB2", "DNAJC5", "DNAJA4", "DNAJB6", "DNAJC8"]
genes = [g for g in genes if g in tpm.index]
br = [c for c in tpm.columns if c.startswith("Brain_")]
other = ["Heart_Left_Ventricle", "Liver", "Lung", "Muscle_Skeletal",
         "Whole_Blood", "Testis", "Spleen", "Pancreas"]
other = [c for c in other if c in tpm.columns]
sub = np.log2(tpm.loc[genes, br + other] + 1)
im = ax.imshow(sub.to_numpy(), aspect="auto", cmap="Blues", vmin=0,
               vmax=float(np.nanmax(sub.to_numpy())))
ax.set_yticks(range(len(genes))); ax.set_yticklabels(genes)
lbl = [c.replace("Brain_", "").replace("_", " ") for c in br + other]
ax.set_xticks(range(len(lbl)))
ax.set_xticklabels(lbl, rotation=90, fontsize=5.6)
ax.axvline(len(br) - 0.5, color=INK, lw=1.0)
ax.text((len(br) - 1) / 2, -0.95, "brain", ha="center", fontsize=7, color=INK)
ax.text(len(br) + len(other) / 2 - 0.5, -0.95, "other tissues", ha="center",
        fontsize=7, color=INK)
cb = fig.colorbar(im, ax=ax, fraction=0.03, pad=0.015)
cb.set_label("$\\log_2$(median TPM + 1)", fontsize=7)
cb.ax.tick_params(labelsize=6)
for s in ax.spines.values():
    s.set_visible(False)
save(fig, "figure4_neuronal_context")
print("[ok] figures 1-4 complete")
