#!/usr/bin/env python3
"""
01_fetch_sequences.py
Retrieve all primary sequence data used in PRISM-J from UniProt.

Outputs (data/):
  funes.fasta            Drosophila melanogaster Funes / CG10375 (Q9VCH9)
  orb2.fasta             Drosophila melanogaster Orb2 (Q9VSR3)
  cpeb_human.fasta       Human CPEB1-4
  human_jdp.fasta        Complete human J-domain protein (JDP/DNAJ) complement
  human_jdp_meta.tsv     Metadata table for the human JDP complement
  outgroups.fasta        S. cerevisiae JJJ2/Sis1/Ydj1, E. coli DnaJ, Dmel Mrj
"""
import io
import sys
import time
import pathlib
import requests
import pandas as pd

DATA = pathlib.Path(__file__).resolve().parents[1] / "data"
DATA.mkdir(exist_ok=True, parents=True)
BASE = "https://rest.uniprot.org/uniprotkb"
S = requests.Session()
S.headers.update({"User-Agent": "PRISM-J/1.0 (academic reproducibility pipeline)"})


def get(url, params=None, tries=4):
    for k in range(tries):
        try:
            r = S.get(url, params=params, timeout=90)
            if r.status_code == 200:
                return r
        except Exception as exc:  # pragma: no cover - network resilience
            sys.stderr.write(f"retry {k}: {exc}\n")
        time.sleep(3 * (k + 1))
    raise RuntimeError(f"failed: {url} {params}")


def fasta(acc):
    return get(f"{BASE}/{acc}.fasta").text


def search_tsv(query, fields, size=500):
    r = get(
        f"{BASE}/search",
        params={"query": query, "fields": fields, "format": "tsv", "size": size},
    )
    return pd.read_csv(io.StringIO(r.text), sep="\t")


def search_fasta(query, size=500):
    r = get(f"{BASE}/search", params={"query": query, "format": "fasta", "size": size})
    return r.text


# ---------------------------------------------------------------- anchors
ANCHORS = {
    "funes.fasta": ["Q9VCH9"],                      # Funes / CG10375, D. melanogaster
    "orb2.fasta": ["Q9VSR3"],                       # Orb2, D. melanogaster
    "cpeb_human.fasta": ["Q9BZB8", "Q7Z5Q1",        # CPEB1, CPEB2
                         "Q8NE35", "Q17RY0"],       # CPEB3, CPEB4
    "outgroups.fasta": ["P39101",                   # JJJ2, S. cerevisiae
                        "P25294",                   # SIS1, S. cerevisiae
                        "P25491",                   # YDJ1, S. cerevisiae
                        "P08622",                   # DnaJ, E. coli
                        "Q9VHM3"],                  # Mrj / CG32133, D. melanogaster
}

for fn, accs in ANCHORS.items():
    txt = "".join(fasta(a) for a in accs)
    (DATA / fn).write_text(txt)
    print(f"[ok] {fn}: {txt.count('>')} records")

# ------------------------------------------------- human JDP complement
# The human J-domain protein complement is defined operationally as all
# reviewed (Swiss-Prot) human entries whose gene name begins with DNAJ.
QUERY = "(gene:DNAJ*) AND (organism_id:9606) AND (reviewed:true)"
meta = search_tsv(
    QUERY,
    "accession,id,protein_name,gene_primary,length,sequence,ft_domain,cc_subcellular_location",
)
meta = meta.sort_values("Gene Names (primary)").reset_index(drop=True)
meta.to_csv(DATA / "human_jdp_meta.tsv", sep="\t", index=False)
(DATA / "human_jdp.fasta").write_text(search_fasta(QUERY))
print(f"[ok] human_jdp.fasta: {len(meta)} reviewed human JDPs")
print(meta["Gene Names (primary)"].tolist())
