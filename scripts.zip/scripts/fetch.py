import sys,json,urllib.request,os,ssl
ctx=ssl.create_default_context(cafile=os.path.expanduser('~/.ccr/ca-bundle.crt'))
for p in sys.argv[1:]:
    r=json.load(urllib.request.urlopen("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&retmode=json&id="+p,context=ctx,timeout=30))['result'][p]
    print(p,r['title'],'|',r['fulljournalname'],r['pubdate'],r['volume'],r['issue'],r['pages'],r.get('elocationid'),'|',', '.join(a['name'] for a in r['authors']),'| pubstatus',r.get('pubstatus'),r.get('epubdate'))
