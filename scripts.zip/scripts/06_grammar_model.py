#!/usr/bin/env python3
"""
06_grammar_model.py  --  PRISM-J Layer 2b (recognition-grammar model)

Tests the recognition-grammar hypothesis on an independent published data set
and, if supported, transfers the learned mapping to the Orb2 and hCPEB3
amyloid cores.

Hypothesis. Which chaperones engage a given aggregation-prone client is set by
the chemical complementarity between the chaperone's client-facing composition
and the client's own composition, not by chaperone identity alone. The strong
prediction is therefore that the *difference* in a chaperone's response to two
clients of different composition is predictable from chaperone composition.

Training/validation data. Replicate-averaged aggregation modulation scores for
65 chaperones against HTT-polyQ and mutant FUS (Rozales et al., Nat Commun
2022;13:516), extracted in 04_validation_dataset.py. These data were never
used to parameterise the coarse-grained force field or the structural
analyses, so they constitute an external test.

Outputs (results/):
  descriptors_panel.tsv, descriptors_jdp.tsv, descriptors_clients.tsv
  grammar_model_cv.tsv, grammar_model_coefficients.tsv
  layer2_scores.tsv
"""
import json
import pathlib
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.linear_model import RidgeCV, Ridge
from sklearn.model_selection import KFold, cross_val_predict
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from Bio import SeqIO

ROOT = pathlib.Path(__file__).resolve().parents[1]
DATA, RES = ROOT / "data", ROOT / "results"
RNG = np.random.default_rng(20261102)

CAL = pd.read_csv(DATA / "residues_CALVADOS2.csv").set_index("one")
LAM = CAL["lambdas"].to_dict()
# Kyte & Doolittle, J Mol Biol 1982;157:105-132
KD = dict(A=1.8, R=-4.5, N=-3.5, D=-3.5, C=2.5, Q=-3.5, E=-3.5, G=-0.4,
          H=-3.2, I=4.5, L=3.8, K=-3.9, M=1.9, F=2.8, P=-1.6, S=-0.8,
          T=-0.7, W=-0.9, Y=-1.3, V=4.2)

CLASSES = dict(aromatic="FWY", aliphatic="AVLIM", gly="G", pro="P",
               amide="QN", hydroxyl="ST", cation="KR", anion="DE",
               his="H", cys="C")


def scd(seq):
    """Sequence charge decoration (Sawle & Ghosh, J Chem Phys 2015;143:085101)."""
    q = np.array([1.0 if c in "KR" else -1.0 if c in "DE" else 0.0 for c in seq])
    n = len(q)
    idx = np.nonzero(q)[0]
    if len(idx) < 2:
        return 0.0
    tot = 0.0
    for a in range(1, len(idx)):
        i = idx[a]
        for b in range(a):
            j = idx[b]
            tot += q[i] * q[j] * np.sqrt(i - j)
    return float(tot / n)


def kappa(seq):
    """Das-Pappu charge-patterning parameter (PNAS 2013;110:13392-13397)."""
    q = np.array([1.0 if c in "KR" else -1.0 if c in "DE" else 0.0 for c in seq])
    n = len(q)
    fp, fm = (q > 0).mean(), (q < 0).mean()
    if fp + fm == 0:
        return 0.0
    sigma = (fp - fm) ** 2 / (fp + fm)

    def delta(w):
        if n < w:
            return 0.0
        ds = []
        for s in range(n - w + 1):
            seg = q[s:s + w]
            p, m = (seg > 0).mean(), (seg < 0).mean()
            sg = 0.0 if (p + m) == 0 else (p - m) ** 2 / (p + m)
            ds.append((sg - sigma) ** 2)
        return float(np.mean(ds))

    d = 0.5 * (delta(5) + delta(6))
    # reference maxima by charge-segregated and -mixed permutations
    perm_d = []
    for _ in range(60):
        qs = q.copy()
        RNG.shuffle(qs)
        qq = q
        q_local = qs
        ds = []
        for w in (5, 6):
            if n < w:
                continue
            tmp = []
            for s in range(n - w + 1):
                seg = q_local[s:s + w]
                p, m = (seg > 0).mean(), (seg < 0).mean()
                sg = 0.0 if (p + m) == 0 else (p - m) ** 2 / (p + m)
                tmp.append((sg - sigma) ** 2)
            ds.append(np.mean(tmp))
        perm_d.append(np.mean(ds) if ds else 0.0)
    seg = np.sort(q)[::-1] if fp >= fm else np.sort(q)
    ds = []
    for w in (5, 6):
        if n < w:
            continue
        tmp = []
        for s in range(n - w + 1):
            sg_seg = seg[s:s + w]
            p, m = (sg_seg > 0).mean(), (sg_seg < 0).mean()
            sg = 0.0 if (p + m) == 0 else (p - m) ** 2 / (p + m)
            tmp.append((sg - sigma) ** 2)
        ds.append(np.mean(tmp))
    d_max = np.mean(ds) if ds else 1.0
    return float(d / d_max) if d_max > 0 else 0.0


def descriptors(seq, prefix=""):
    seq = "".join(c for c in seq.upper() if c in LAM)
    n = len(seq)
    d = {f"{prefix}len": n}
    for name, aas in CLASSES.items():
        d[f"{prefix}f_{name}"] = sum(c in aas for c in seq) / n
    d[f"{prefix}lam_mean"] = float(np.mean([LAM[c] for c in seq]))
    d[f"{prefix}kd_mean"] = float(np.mean([KD[c] for c in seq]))
    q = np.array([1.0 if c in "KR" else -1.0 if c in "DE" else 0.0 for c in seq])
    d[f"{prefix}ncpr"] = float(q.mean())
    d[f"{prefix}fcr"] = float(np.abs(q).mean())
    d[f"{prefix}scd"] = scd(seq)
    d[f"{prefix}kappa"] = kappa(seq)
    # Shannon entropy of composition (low-complexity indicator)
    _, cnt = np.unique(list(seq), return_counts=True)
    p = cnt / n
    d[f"{prefix}entropy"] = float(-(p * np.log(p)).sum())
    return d


def read_fasta(path):
    return {r.id: str(r.seq) for r in SeqIO.parse(path, "fasta")}


# ------------------------------------------------------------- descriptors
panel = read_fasta(DATA / "panel_sequences.fasta")
panel = {k.split("|")[0]: v for k, v in panel.items()}
clients = read_fasta(DATA / "clients.fasta")

dp = pd.DataFrame([dict(chaperone=k, **descriptors(v)) for k, v in panel.items()])
dc = pd.DataFrame([dict(client=k, **descriptors(v, prefix="c_")) for k, v in clients.items()])
dp.to_csv(RES / "descriptors_panel.tsv", sep="\t", index=False)
dc.to_csv(RES / "descriptors_clients.tsv", sep="\t", index=False)
print(f"[ok] descriptors: {len(dp)} chaperones, {len(dc)} clients")
print(dc[["client", "c_f_amide", "c_f_aromatic", "c_f_aliphatic", "c_f_his",
          "c_lam_mean", "c_kd_mean"]].round(3).to_string(index=False))

# ------------------------------------------------------- experimental data
sc = pd.read_csv(RES / "rozales_scores_wide.tsv", sep="\t")
sc = sc[sc.chaperone != "dsred"]
D = sc.merge(dp, on="chaperone", how="inner")
D["dAMS"] = D["mutFUS"] - D["HTT_polyQ"]
print(f"\n[ok] paired design: n = {len(D)} chaperones")

FEAT = [c for c in dp.columns if c.startswith("f_")] + \
       ["lam_mean", "kd_mean", "ncpr", "fcr", "scd", "kappa", "entropy"]
X = D[FEAT].to_numpy(float)
y = D["dAMS"].to_numpy(float)

alphas = np.logspace(-2, 4, 40)
pipe = make_pipeline(StandardScaler(), RidgeCV(alphas=alphas))
cv = KFold(n_splits=10, shuffle=True, random_state=0)
yhat = cross_val_predict(pipe, X, y, cv=cv)
r_cv, p_cv = stats.pearsonr(y, yhat)
rho_cv, p_rho = stats.spearmanr(y, yhat)
q2 = 1 - np.sum((y - yhat) ** 2) / np.sum((y - y.mean()) ** 2)

# permutation test on the cross-validated correlation
nperm = 2000
null = np.empty(nperm)
for i in range(nperm):
    yp = RNG.permutation(y)
    null[i] = stats.pearsonr(yp, cross_val_predict(pipe, X, yp, cv=cv))[0]
p_perm = (1 + np.sum(null >= r_cv)) / (nperm + 1)

print(f"[key] client-preference model, 10-fold CV: r = {r_cv:.3f} "
      f"(P = {p_cv:.3g}), rho = {rho_cv:.3f} (P = {p_rho:.3g}), Q2 = {q2:.3f}")
print(f"[key] permutation test (n = {nperm}): P = {p_perm:.4f}")

pipe.fit(X, y)
ridge = pipe[-1]
coef = pd.DataFrame(dict(feature=FEAT, coefficient=ridge.coef_))
coef["abs"] = coef.coefficient.abs()
coef = coef.sort_values("abs", ascending=False).drop(columns="abs")
coef.to_csv(RES / "grammar_model_coefficients.tsv", sep="\t", index=False)
print(f"[info] selected ridge alpha = {ridge.alpha_:.4g}")
print(coef.head(8).round(4).to_string(index=False))

pd.DataFrame(dict(chaperone=D.chaperone, dAMS_observed=y, dAMS_cv_pred=yhat)
             ).to_csv(RES / "grammar_model_cv.tsv", sep="\t", index=False)

# -------------------------------------- bilinear client-transferable model
# AMS(chaperone, client) ~ sum_cc' w_cc' f_c(chaperone) f_c'(client)
long = sc.melt(id_vars="chaperone", var_name="client", value_name="ams")
long = long.merge(dp, on="chaperone").merge(
    dc.assign(client=lambda t: t.client.str.replace("_APR", "", regex=False)),
    on="client", how="inner")
CH_CLS = [f"f_{k}" for k in CLASSES] + ["lam_mean", "ncpr"]
CL_CLS = [f"c_f_{k}" for k in CLASSES] + ["c_lam_mean", "c_ncpr"]
pairs = [(a, b) for a in CH_CLS for b in CL_CLS]
Xb = np.column_stack([long[a].to_numpy(float) * long[b].to_numpy(float)
                      for a, b in pairs])
yb = long["ams"].to_numpy(float)
groups = long["chaperone"].to_numpy()

pipe_b = make_pipeline(StandardScaler(), Ridge(alpha=100.0))
# leave-one-chaperone-out: no chaperone appears in both train and test
from sklearn.model_selection import LeaveOneGroupOut
logo = LeaveOneGroupOut()
yb_hat = cross_val_predict(pipe_b, Xb, yb, cv=logo, groups=groups)
r_b, p_b = stats.pearsonr(yb, yb_hat)
print(f"\n[key] bilinear model, leave-one-chaperone-out: r = {r_b:.3f} "
      f"(P = {p_b:.3g}), n = {len(yb)} chaperone-client pairs")

pipe_b.fit(Xb, yb)
json.dump(dict(pairs=[list(p) for p in pairs],
               coef=pipe_b[-1].coef_.tolist(),
               intercept=float(pipe_b[-1].intercept_),
               mean=pipe_b[0].mean_.tolist(), scale=pipe_b[0].scale_.tolist(),
               cv_r=float(r_b), cv_p=float(p_b),
               pref_cv_r=float(r_cv), pref_cv_p=float(p_cv),
               pref_perm_p=float(p_perm), pref_q2=float(q2),
               ridge_alpha=float(ridge.alpha_)),
          open(RES / "grammar_model.json", "w"), indent=1)

# ------------------------------- transfer to the human JDP complement
jdp = read_fasta(DATA / "human_jdp.fasta")
jdp = {k.split("|")[1]: v for k, v in jdp.items()}
meta = pd.read_csv(DATA / "human_jdp_meta.tsv", sep="\t")
gene = dict(zip(meta["Entry"], meta["Gene Names (primary)"]))
hits = pd.read_csv(RES / "jdomain_hmmsearch.domtbl", sep=r"\s+", comment="#",
                   header=None, usecols=[0, 13, 17, 18],
                   names=["target", "score", "afrom", "ato"])
hits["acc"] = hits.target.str.split("|").str[0]
best = hits.sort_values("score", ascending=False).drop_duplicates("acc")
jd_span = dict(zip(best.acc, zip(best.afrom, best.ato)))

rows = []
for acc, seq in jdp.items():
    if acc not in jd_span:
        continue
    a, b = jd_span[acc]
    cbr = seq[:max(0, a - 6)] + seq[b + 10:]      # non-J-domain region
    if len(cbr) < 20:
        cbr = seq
    rows.append(dict(acc=acc, gene=gene.get(acc, acc),
                     **descriptors(cbr), cbr_len=len(cbr),
                     jd_start=int(a), jd_end=int(b)))
dj = pd.DataFrame(rows)
dj.to_csv(RES / "descriptors_jdp.tsv", sep="\t", index=False)
print(f"\n[ok] client-binding-region descriptors for {len(dj)} human JDPs")


def bilinear_score(chap_row, client_row):
    v = np.array([[chap_row[a] * client_row[b] for a, b in pairs]], float)
    return float(pipe_b.predict(v)[0])


cl = dc.set_index("client")
orb = cl.loc["Orb2_core"]
cp3 = cl.loc["hCPEB3_core"]
out = []
for _, r in dj.iterrows():
    s_orb = bilinear_score(r, orb)
    s_cp3 = bilinear_score(r, cp3)
    out.append(dict(gene=r.gene, acc=r.acc, cbr_len=r.cbr_len,
                    score_Orb2=s_orb, score_hCPEB3=s_cp3,
                    grammar_shift=s_cp3 - s_orb,
                    f_aromatic=r.f_aromatic, f_amide=r.f_amide,
                    f_aliphatic=r.f_aliphatic, f_hydroxyl=r.f_hydroxyl,
                    lam_mean=r.lam_mean))
L2 = pd.DataFrame(out)
L2.to_csv(RES / "layer2_scores.tsv", sep="\t", index=False)
print("\n--- strongest predicted engagement of the hCPEB3 core ---")
print(L2.sort_values("score_hCPEB3", ascending=False)
      .head(12)[["gene", "score_Orb2", "score_hCPEB3", "grammar_shift",
                 "f_aromatic", "f_amide", "lam_mean"]].round(3).to_string(index=False))
