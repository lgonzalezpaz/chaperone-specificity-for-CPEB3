#!/usr/bin/env python3
"""
09_cg_binding.py  --  PRISM-J Layer 4 (association thermodynamics)

Umbrella sampling of the association of chaperone client-binding regions with
the structurally defined Orb2 and hCPEB3 amyloid-core segments in the
CALVADOS 2 residue-resolution coarse-grained model, followed by WHAM and a
standard-state binding free energy.

Reaction coordinate: the mass-weighted centroid separation r of the two
chains. A flat-bottom wall at r_wall defines the sampling volume. The
standard-state association constant follows from

    K_a = (1/V0) * int_0^{r_b} 4 pi r^2 exp(-W(r)/kT) dr ,  V0 = 1.661 nm^3
    dG0 = -kT ln K_a

Client-binding region (CBR): the longer of the two segments flanking the
Pfam PF00226 J domain, truncated to the CBR_MAX residues nearest the J
domain. For Funes this is the C-terminal domain shown experimentally to be
required for Orb2 binding (Patton et al., PNAS 2026;123:e2516310123).

Usage:
  python3 09_cg_binding.py --test            quick single-system check
  python3 09_cg_binding.py --worker 0 --nworkers 2
"""
from __future__ import annotations

import argparse
import json
import pathlib
import sys
import time
import numpy as np
import pandas as pd
from Bio import SeqIO

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from calvados_cg import load_residues
from cg_setup import (build, equilibrate_and_sample, wham, pmf_to_dg,
                      window_overlap)
from cg_engine import contact_counts, R_GAS

ROOT = pathlib.Path(__file__).resolve().parents[1]
DATA, RES = ROOT / "data", ROOT / "results"
OUT = RES / "cg"
OUT.mkdir(exist_ok=True, parents=True)

CBR_MAX = 100
TEMP = 310.0
IONIC = 0.15
K_UM = 40.0   # sigma_r = sqrt(kT/k) = 0.25 nm, about half the 0.5 nm window spacing
R_WALL = 7.0
K_WALL = 400.0
WINDOWS = np.arange(0.5, 6.51, 0.5)
N_EQ = 40_000
N_PROD = 120_000
STRIDE = 200
N_REP = 2
R_BOUND = 4.2
PLATEAU = (5.0, 6.8)
CONTACT_CUT = 0.8


def cbr_of(seq: str, a: int, b: int, cap: int = CBR_MAX) -> tuple[str, int, int]:
    """Longer J-domain-flanking segment, capped at `cap` residues nearest the J domain."""
    nterm, cterm = seq[:max(0, a - 6)], seq[b + 10:]
    if len(cterm) >= len(nterm):
        s = cterm[:cap]
        return s, b + 11, b + 10 + len(s)
    s = nterm[-cap:]
    start = max(0, a - 6) - len(s)
    return s, start + 1, start + len(s)


def load_inputs():
    jdp = {r.id.split("|")[1]: str(r.seq)
           for r in SeqIO.parse(DATA / "human_jdp.fasta", "fasta")}
    funes = {r.id.split("|")[1]: str(r.seq)
             for r in SeqIO.parse(DATA / "funes.fasta", "fasta")}
    jdp.update(funes)
    meta = pd.read_csv(DATA / "human_jdp_meta.tsv", sep="\t")
    gene = dict(zip(meta["Entry"], meta["Gene Names (primary)"]))
    gene["Q9VCH9"] = "Funes"
    hits = pd.read_csv(RES / "jdomain_hmmsearch.domtbl", sep=r"\s+",
                       comment="#", header=None, usecols=[0, 13, 17, 18],
                       names=["target", "score", "afrom", "ato"])
    hits["acc"] = hits.target.str.split("|").str[0]
    best = hits.sort_values("score", ascending=False).drop_duplicates("acc")
    span = dict(zip(best.acc, zip(best.afrom, best.ato)))
    clients = {r.id: str(r.seq) for r in SeqIO.parse(DATA / "clients.fasta", "fasta")}
    return jdp, gene, span, clients


JDP, GENE, SPAN, CLIENTS = load_inputs()
ACC = {v: k for k, v in GENE.items()}
RESIDUES = load_residues(DATA / "residues_CALVADOS2.csv")

rng_shuf = np.random.default_rng(42)
_c = list(CLIENTS["hCPEB3_core"])
rng_shuf.shuffle(_c)
CLIENTS["hCPEB3_core_shuffled"] = "".join(_c)

# chaperone, client, role
SYSTEMS = [
    ("Funes",   "Orb2_core",   "positive control: experimentally validated pair"),
    ("Funes",   "hCPEB3_core", "cross-species transfer test"),
    ("DNAJC8",  "Orb2_core",   "sequence orthologue on the fly client"),
    ("DNAJC8",  "hCPEB3_core", "naive orthology prediction"),
    ("DNAJB2",  "hCPEB3_core", "Layer 3 candidate: top brain expression and CPEB3 co-expression"),
    ("DNAJC5",  "hCPEB3_core", "Layer 3 candidate: synaptic, top aromatic-client alleviator"),
    ("DNAJB6",  "hCPEB3_core", "canonical anti-amyloid DNAJB"),
    ("DNAJB1",  "hCPEB3_core", "generic Hsp40 reference"),
    ("DNAJB8",  "hCPEB3_core", "top amide-client alleviator on the aromatic client"),
    ("DNAJB8",  "Orb2_core",   "top amide-client alleviator on its matched grammar"),
    ("DNAJB6",  "Orb2_core",   "polyQ specialist on its matched grammar"),
    ("DNAJB2",  "Orb2_core",   "candidate specificity cross-check"),
    ("DNAJC5",  "Orb2_core",   "candidate specificity cross-check"),
    ("DNAJB2",  "hCPEB3_core_shuffled", "composition-matched sequence-scrambled control"),
]


def run_system(chap: str, client: str, note: str, n_prod=N_PROD,
               windows=WINDOWS, n_rep=N_REP, tag=""):
    acc = ACC[chap]
    a, b = SPAN[acc]
    cbr, c0, c1 = cbr_of(JDP[acc], a, b)
    cseq = CLIENTS[client]
    sysd = build([cbr, cseq], RESIDUES, temp=TEMP, ionic=IONIC)
    name = f"{chap}__{client}{tag}"
    t0 = time.time()
    samples, allr, contacts_a, contacts_b, nframes = [], [], [], [], 0
    per_rep = []
    for r0 in windows:
        pooled = []
        for rep in range(n_rep):
            seed = int(abs(hash((name, float(r0), rep))) % (2 ** 31))
            rs, us, x = equilibrate_and_sample(
                sysd, r0=float(r0), kum=K_UM, rwall=R_WALL, kwall=K_WALL,
                n_eq=N_EQ, n_prod=n_prod, stride=STRIDE, seed=seed)
            pooled.append(rs)
            if r0 <= 3.0:   # bound-state windows carry the contact statistics
                ca, cb = contact_counts(np.ascontiguousarray(x),
                                        sysd["nchain"][0], sysd["n"], CONTACT_CUT)
                contacts_a.append(ca)
                contacts_b.append(cb)
        samples.append(np.concatenate(pooled))
        per_rep.append(list(pooled))
        allr.append(float(r0))
        nframes += sum(len(p) for p in pooled)

    bins = np.linspace(0.0, R_WALL, 113)
    ov, H = window_overlap(samples, bins)
    mid, pmf, f = wham(samples, allr, K_UM, TEMP, bins)
    dG, Ka, w = pmf_to_dg(mid, pmf, TEMP, R_BOUND, PLATEAU)

    # independent-replica convergence check
    dG_rep = []
    for rep in range(n_rep):
        sub = [rep_samples[rep] for rep_samples in per_rep]
        m_i, p_i, _ = wham(sub, allr, K_UM, TEMP, bins, max_iter=40000)
        try:
            d_i, _, _ = pmf_to_dg(m_i, p_i, TEMP, R_BOUND, PLATEAU)
            if np.isfinite(d_i):
                dG_rep.append(float(d_i))
        except Exception:
            pass

    # block-bootstrap uncertainty over windows
    boot = []
    rs0 = np.random.default_rng(11)
    for _ in range(80):
        sub = [s[rs0.integers(0, len(s), len(s))] for s in samples]
        m2, p2, _ = wham(sub, allr, K_UM, TEMP, bins, max_iter=20000)
        try:
            d2, _, _ = pmf_to_dg(m2, p2, TEMP, R_BOUND, PLATEAU)
            if np.isfinite(d2):
                boot.append(d2)
        except Exception:
            pass
    sd = float(np.std(boot)) if len(boot) > 10 else float("nan")

    rec = dict(system=name, chaperone=chap, client=client, note=note,
               cbr=cbr, cbr_start=int(c0), cbr_end=int(c1),
               protocol=dict(k_umbrella=K_UM, r_wall=R_WALL, k_wall=K_WALL,
                             n_windows=len(windows), n_eq=N_EQ,
                             n_prod=n_prod, n_rep=n_rep, temp=TEMP,
                             ionic=IONIC, r_bound=R_BOUND,
                             plateau=list(PLATEAU)),
               n_beads=int(sysd["n"]), n_windows=len(windows),
               n_frames=int(nframes), dG_kJmol=float(dG),
               dG_sd_kJmol=sd, Ka_nm3=float(Ka),
               overlap_min=float(ov.min()), overlap_mean=float(ov.mean()),
               dG_replicas=dG_rep,
               dG_replica_spread=float(max(dG_rep)-min(dG_rep)) if len(dG_rep)>1 else float('nan'),
               Kd_mM=float(1e3 / (Ka / 1.6606022) ) if Ka > 0 else float("nan"),
               wall_min=round((time.time() - t0) / 60, 1))
    np.savez_compressed(OUT / f"{name}.npz", r=mid, pmf=pmf, w=w,
                        overlap=ov, windows=np.array(allr), offsets=f,
                        contacts_chap=np.mean(contacts_a, axis=0) if contacts_a else np.zeros(1),
                        contacts_client=np.mean(contacts_b, axis=0) if contacts_b else np.zeros(1),
                        hist=H)
    json.dump(rec, open(OUT / f"{name}.json", "w"), indent=1)
    print(f"[done] {name:42s} dG = {dG:7.2f} +/- {sd:4.2f} kJ/mol | "
          f"replica spread {rec['dG_replica_spread']:.2f} | overlap "
          f"{ov.min():.2f}/{ov.mean():.2f} | {sysd['n']} beads, "
          f"{rec['wall_min']} min", flush=True)
    return rec


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--test", action="store_true")
    ap.add_argument("--worker", type=int, default=0)
    ap.add_argument("--nworkers", type=int, default=1)
    args = ap.parse_args()

    if args.test:
        print("quick convergence check: Funes CBR + Orb2 core")
        run_system("Funes", "Orb2_core", "test", n_prod=120_000,
                   windows=np.arange(0.5, 8.01, 1.0), n_rep=2, tag="_TEST")
        sys.exit(0)

    todo = [s for i, s in enumerate(SYSTEMS) if i % args.nworkers == args.worker]
    print(f"worker {args.worker}/{args.nworkers}: {len(todo)} systems", flush=True)
    for chap, client, note in todo:
        if (OUT / f"{chap}__{client}.json").exists():
            print(f"[skip] {chap}__{client} already done", flush=True)
            continue
        try:
            run_system(chap, client, note)
        except Exception as exc:
            print(f"[fail] {chap}__{client}: {exc}", flush=True)
