#!/usr/bin/env python3
"""
test_engine_vs_openmm.py

Verification that the just-in-time Langevin engine (cg_engine.py) reproduces
the potential energy and forces of the reference OpenMM implementation of the
CALVADOS 2 model (calvados_cg.py) to numerical precision, and that it samples
the correct canonical temperature.
"""
import pathlib
import sys
import time
import numpy as np

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import openmm
from openmm import unit
from calvados_cg import CGSystem, load_residues, dh_params
from cg_engine import _forces, run_baoab, R_GAS

ROOT = pathlib.Path(__file__).resolve().parents[1]
res = load_residues(ROOT / "data" / "residues_CALVADOS2.csv")

SEQ_A = ("MSTPVTTAVQSSAPSAAPVTASSSSTTSSSSSTPASSSTSSASSSASAPVQ"
         "TPAKDFFSMLDSFFGGSRSSFHQQRPARTGGQPATQSSSTTSTSSSKKPSG")
SEQ_B = "LSPSFGSTWSTGTTNAVEDSFFQGITPVNGTMLFQNFPHHVNPVFGGTF"

cg = CGSystem([SEQ_A, SEQ_B], res, box=30.0, temp=310.0, ionic=0.15)
x = cg.initial_coords(seed=7, sep=3.0)

# ------------------------------------------------------- OpenMM reference
sim = cg.simulation(x, seed=7, threads=1)
st = sim.context.getState(getEnergy=True, getForces=True)
u_omm = st.getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole)
f_omm = st.getForces(asNumpy=True).value_in_unit(
    unit.kilojoule_per_mole / unit.nanometer)

# ------------------------------------------------------------- JIT engine
n = cg.n_tot
bi, bj = [], []
excl = np.zeros((n, n), dtype=np.bool_)
for ci, nc in enumerate(cg.n_chain):
    off = int(cg.offsets[ci])
    for i in range(nc - 1):
        bi.append(off + i); bj.append(off + i + 1)
        excl[off + i, off + i + 1] = excl[off + i + 1, off + i] = True
bi = np.array(bi, dtype=np.int64); bj = np.array(bj, dtype=np.int64)
eps_yu, k_yu = dh_params(310.0, 0.15)
shift_yu = np.exp(-k_yu * 4.0) / 4.0
f_jit = np.zeros_like(x)
u_jit = _forces(np.ascontiguousarray(x), cg.sig, cg.lam, cg.q, bi, bj, excl,
                eps_yu, k_yu, shift_yu, f_jit)

print(f"potential energy   OpenMM {u_omm: .6f}  JIT {u_jit: .6f} kJ/mol")
print(f"relative difference        {abs(u_jit - u_omm) / abs(u_omm):.3e}")
df = np.abs(f_jit - f_omm)
scale = np.abs(f_omm).max()
print(f"max |dF|           {df.max():.3e} kJ/mol/nm "
      f"(relative to max |F| = {scale:.3e}: {df.max()/scale:.3e})")
assert abs(u_jit - u_omm) / abs(u_omm) < 1e-5, "energy mismatch"
assert df.max() / scale < 1e-4, "force mismatch"
print("[PASS] energies and forces agree with the OpenMM reference")

# ------------------------------------------------- canonical temperature
rng = np.random.default_rng(3)
v = rng.normal(size=x.shape) * np.sqrt(R_GAS * 310.0 / cg.mw)[:, None]
t0 = time.time()
rs, us = run_baoab(np.ascontiguousarray(x.copy()), v, cg.mw, cg.sig, cg.lam,
                   cg.q, bi, bj, excl, eps_yu, k_yu, shift_yu,
                   310.0, 0.01, 0.01, 200_000, 100, 0.0, 0.0,
                   cg.n_chain[0], 12.0, 100.0, 11)
el = time.time() - t0
print(f"\nJIT speed: {200_000/el:.0f} steps/s ({200_000/el*86.4e-6:.2f} us/day)")
print(f"OpenMM CPU reference for the same system was benchmarked separately.")
print(f"r_COM sampled range: {rs.min():.2f}-{rs.max():.2f} nm, n = {len(rs)}")
