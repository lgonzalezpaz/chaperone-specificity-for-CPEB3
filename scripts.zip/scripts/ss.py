import sys,json,urllib.request,urllib.parse
def get(u):
    return json.load(urllib.request.urlopen(urllib.request.Request(u,headers={"User-Agent":"refcheck/1.0"}),timeout=30))
for t in sys.argv[1:]:
    print("===",t)
    r=get("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retmode=json&term="+urllib.parse.quote(t))
    ids=r['esearchresult']['idlist']; print(ids)
    import time; time.sleep(1)
    if ids:
        s=get("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&retmode=json&id="+",".join(ids))['result']
        for i in ids:
            x=s[i]; print(i,x['title'],'|',x['source'],x['pubdate'],x['volume'],x['issue'],x['pages'],x.get('elocationid')); print('  ',', '.join(a['name'] for a in x['authors']))
            print('  ',[y['value'] for y in x['articleids'] if y['idtype']=='pmc'])
    time.sleep(1)
