#!/usr/bin/env python3
"""
19_supp_figures.py  --  supplementary figures

S1  maximum-likelihood phylogeny of the J domains
S2  sensitivity of the association free energy to modelling choices
S3  umbrella-sampling diagnostics for every simulated system
"""
import json
import pathlib
import warnings
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from Bio import Phylo

warnings.filterwarnings("ignore")
ROOT = pathlib.Path(__file__).resolve().parents[1]
RES, FIG = ROOT / "results", ROOT / "figures"
CG = RES / "cg"
FIG.mkdir(exist_ok=True, parents=True)

C = ["#0072B2", "#D55E00", "#009E73", "#E69F00", "#CC79A7", "#56B4E9"]
INK, INK2, MUTED, GRID = "#1a1a1a", "#4d4d4d", "#8c8c8c", "#d9d9d9"
mpl.rcParams.update({
    "font.family": "sans-serif", "font.sans-serif": ["DejaVu Sans", "Arial"],
    "font.size": 7, "axes.labelsize": 8, "xtick.labelsize": 7,
    "ytick.labelsize": 7, "legend.fontsize": 6.8,
    "axes.edgecolor": INK2, "axes.linewidth": 0.6,
    "xtick.color": INK2, "ytick.color": INK2,
    "text.color": INK, "axes.labelcolor": INK,
    "grid.color": GRID, "grid.linewidth": 0.5, "legend.frameon": False,
    "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
    "pdf.fonttype": 42, "ps.fonttype": 42})
CM = 1 / 2.54


def save(fig, name):
    fig.savefig(FIG / f"{name}.pdf"); fig.savefig(FIG / f"{name}.png", dpi=600)
    plt.close(fig); print(f"[ok] {name}")


def tidy(ax, grid="y"):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    if grid:
        ax.grid(axis=grid, alpha=0.8, zorder=0); ax.set_axisbelow(True)


# ====================================================== FIGURE S1
tf = RES / "jdomain_tree.treefile"
if tf.exists():
    tree = Phylo.read(tf, "newick")
    tree.ladderize()
    HL = {"Funes": C[1], "DNAJC8": C[0], "DNAJB2": C[4], "DNAJC5": C[2],
          "DNAJB6": C[3], "Mrj_Dmel": MUTED, "JJJ2_Scer": MUTED,
          "Sis1_Scer": MUTED, "Ydj1_Scer": MUTED, "DnaJ_Ecoli": MUTED}
    fig = plt.figure(figsize=(15 * CM, 24 * CM))
    ax = fig.add_subplot(111)

    def lab(c):
        if not c.is_terminal():
            return None
        return f"  {c.name}"

    Phylo.draw(tree, axes=ax, do_show=False, label_func=lab,
               show_confidence=False,
               label_colors=lambda n: HL.get(str(n).strip(), INK))
    for t in ax.texts:
        s = t.get_text().strip()
        t.set_fontsize(5.6)
        if s in ("Funes", "DNAJC8"):
            t.set_fontweight("bold"); t.set_fontsize(6.4)
    ax.set_xlabel("substitutions per site")
    ax.set_ylabel("")
    ax.set_yticks([])
    for s in ("top", "right", "left"):
        ax.spines[s].set_visible(False)
    ax.legend(handles=[Line2D([], [], color=C[1], lw=3, label="Funes"),
                       Line2D([], [], color=C[0], lw=3, label="DNAJC8"),
                       Line2D([], [], color=C[4], lw=3, label="PRISM-J shortlist"),
                       Line2D([], [], color=MUTED, lw=3,
                              label="non-human outgroups")],
              loc="lower right", handlelength=1.2)
    save(fig, "figureS1_jdomain_phylogeny")

# ====================================================== FIGURE S2
sp = RES / "sensitivity.tsv"
if sp.exists():
    s = pd.read_csv(sp, sep="\t")
    fig, ax = plt.subplots(figsize=(13 * CM, 7 * CM))
    cols = {"CBR length": C[0], "histidine charge": C[1], "force field": C[2]}
    y = np.arange(len(s))
    ax.barh(y, s.delta_vs_reference, color=[cols[a] for a in s.axis],
            edgecolor="white", lw=0.5, height=0.7, zorder=3)
    ax.set_yticks(y); ax.set_yticklabels(s.variant, fontsize=6.6)
    ax.axvline(0, color=INK2, lw=0.7)
    ref = json.load(open(RES / "sensitivity.json"))["reference_dG"]
    ax.set_xlabel("change in $\\Delta G^{\\circ}$ relative to the reference "
                  f"protocol ({ref:.2f} kJ mol$^{{-1}}$)  (kJ mol$^{{-1}}$)")
    for i, v in enumerate(s.delta_vs_reference):
        ax.text(v + (0.03 if v >= 0 else -0.03), i, f"{v:+.2f}",
                va="center", ha="left" if v >= 0 else "right", fontsize=6.2,
                color=INK)
    tidy(ax, grid="x")
    ax.legend(handles=[Line2D([], [], marker="s", ls="none", color=v, ms=6,
                              label=k) for k, v in cols.items()],
              loc="lower right", handlelength=0.9)
    save(fig, "figureS2_sensitivity")

# ====================================================== FIGURE S3
files = sorted(p for p in CG.glob("*.npz") if "TEST" not in p.name)
if files:
    n = len(files)
    ncol = 4
    nrow = int(np.ceil(n / ncol))
    fig, axes = plt.subplots(nrow, ncol, figsize=(18 * CM, 3.1 * nrow * CM),
                             sharex=True)
    axes = np.atleast_1d(axes).ravel()
    for k, f in enumerate(files):
        d = np.load(f)
        ax = axes[k]
        H, r = d["hist"], d["r"]
        for j in range(H.shape[0]):
            ax.plot(r, H[j], lw=0.7, color=C[j % len(C)], alpha=0.9)
        ov = d["overlap"] if "overlap" in d.files else np.array([np.nan])
        ax.set_title(f.stem.replace("__", " + ").replace("_core", "")
                     + f"\nmin/mean overlap {np.nanmin(ov):.2f}/{np.nanmean(ov):.2f}",
                     fontsize=6.0, color=INK2)
        ax.set_yticks([])
        tidy(ax, grid=None)
    for k in range(n, len(axes)):
        axes[k].axis("off")
    for ax in axes[-ncol:]:
        ax.set_xlabel("centroid separation (nm)", fontsize=7)
    fig.suptitle("umbrella window occupancy and adjacent-window overlap",
                 fontsize=8.5, y=1.005, color=INK)
    fig.tight_layout()
    save(fig, "figureS3_umbrella_diagnostics")
print("[ok] supplementary figures complete")
