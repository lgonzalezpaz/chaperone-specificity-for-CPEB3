#!/usr/bin/env python3
"""
15_verify.py  --  independent check of every numeric claim in the manuscript

Each claim asserted in the text is re-derived here from the result files and
compared with the value written in the manuscript. The script exits non-zero
if any claim fails, so it can gate a release.
"""
import json
import pathlib
import re
import sys
import numpy as np
import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[1]
RES = ROOT / "results"
MS = ROOT / "manuscript" / "manuscript.md"

ok, bad = [], []


def check(label, claimed, actual, tol=0.0051, rel=False):
    try:
        if rel:
            good = abs(claimed - actual) <= tol * max(1e-12, abs(actual))
        else:
            good = abs(claimed - actual) <= tol
    except TypeError:
        good = claimed == actual
    (ok if good else bad).append((label, claimed, actual))
    flag = "PASS" if good else "FAIL"
    print(f"[{flag}] {label}: manuscript {claimed}  computed {actual}")


gram = pd.read_csv(RES / "grammar_vectors.tsv", sep="\t").set_index("pdb")
core = pd.read_csv(RES / "core_sequences.tsv", sep="\t").set_index("pdb")
L1 = pd.read_csv(RES / "layer1_scores.tsv", sep="\t").set_index("gene")
L3 = pd.read_csv(RES / "layer3_scores.tsv", sep="\t").set_index("gene")
rankt = pd.read_csv(RES / "prismj_ranking.tsv", sep="\t").set_index("gene")
diag = json.load(open(RES / "diagnostics.json"))
integ = json.load(open(RES / "integration.json"))
dc = pd.read_csv(RES / "descriptors_clients.tsv", sep="\t").set_index("client")
roz = pd.read_csv(RES / "rozales_scores_wide.tsv", sep="\t")
roz = roz[roz.chaperone != "dsred"]
full = pd.read_csv(RES / "rozales_scores.tsv", sep="\t")

print("== Layer 1 ==")
check("human JDPs with a J domain", 49, int(integ["n_jdp_with_jdomain"]))
check("DNAJC8 J-domain identity to Funes (%)", 58.7,
      round(float(L1.loc["DNAJC8", "jd_identity"]) * 100, 1), tol=0.051)
check("DNAJC8 J-domain similarity (%)", 78.7,
      round(float(L1.loc["DNAJC8", "jd_similarity"]) * 100, 1), tol=0.051)
check("DNAJC8 normalised SW, J domain", 0.591,
      round(float(L1.loc["DNAJC8", "sw_jdomain_norm"]), 3))
check("DNAJC8 normalised SW, full length", 0.502,
      round(float(L1.loc["DNAJC8", "sw_fulllength_norm"]), 3))
nxt = L1.drop(index=[g for g in ["Funes", "Mrj_Dmel", "JJJ2_Scer", "Sis1_Scer",
                                 "Ydj1_Scer", "DnaJ_Ecoli", "DNAJC8"]
                     if g in L1.index]).nlargest(1, "sw_jdomain_norm")
check("next closest human JDP identity (%)", 34.7,
      round(float(nxt.jd_identity.iloc[0]) * 100, 1), tol=0.051)
check("next closest human JDP normalised SW", 0.365,
      round(float(nxt.sw_jdomain_norm.iloc[0]), 3))
check("Funes length (aa)", 254, int(L1.loc["Funes", "len_full"]))
check("DNAJC8 length (aa)", 253, int(L1.loc["DNAJC8", "len_full"]))
check("J domains with canonical HPD", 53, int(L1.HPD.sum()))
check("J domains analysed", 54, int(len(L1)))

print("\n== Layer 2, structures ==")
check("Orb2 core length (aa)", 31, int(core.loc["6VPS", "core_len"]))
check("Orb2 core first residue (6VPS)", 23, int(core.loc["6VPS", "first"]))
check("Orb2 core last residue (6VPS)", 53, int(core.loc["6VPS", "last"]))
check("Orb2 core first residue (8YAC)", 176, int(core.loc["8YAC", "first"]))
check("Orb2 and Funes-induced cores identical", True,
      core.loc["6VPS", "sequence"] == core.loc["8YAC", "sequence"])
check("hCPEB3 core length (aa)", 49, int(core.loc["8SPA", "core_len"]))
check("hCPEB3 core first residue", 103, int(core.loc["8SPA", "first"]))
check("hCPEB3 core last residue", 151, int(core.loc["8SPA", "last"]))
check("Orb2 core Gln (%)", 64.5, round(float(gram.loc["6VPS", "f_Q"]) * 100, 1),
      tol=0.051)
check("Orb2 core His (%)", 22.6, round(float(gram.loc["6VPS", "f_H"]) * 100, 1),
      tol=0.051)
check("Orb2 core aromatic (%)", 0.0,
      round(float(gram.loc["6VPS", "f_aromatic"]) * 100, 1), tol=0.051)
check("Orb2 core charged (%)", 0.0,
      round(float(gram.loc["6VPS", "f_charged"]) * 100, 1), tol=0.051)
check("Orb2 core mean hydropathy", -2.64,
      round(float(gram.loc["6VPS", "mean_KD"]), 2))
check("hCPEB3 core Gln (%)", 4.1, round(float(gram.loc["8SPA", "f_Q"]) * 100, 1),
      tol=0.051)
check("hCPEB3 core aromatic (%)", 16.3,
      round(float(gram.loc["8SPA", "f_aromatic"]) * 100, 1), tol=0.051)
check("hCPEB3 core apolar (%)", 34.7,
      round(float(gram.loc["8SPA", "f_hydrophobic"]) * 100, 1), tol=0.051)
check("hCPEB3 core mean hydropathy", -0.02,
      round(float(gram.loc["8SPA", "mean_KD"]), 2))
check("Orb2 surface amide (%)", 55.0,
      round(float(gram.loc["6VPS", "surf_f_QN"]) * 100, 1), tol=0.051)
check("hCPEB3 surface amide (%)", 11.1,
      round(float(gram.loc["8SPA", "surf_f_QN"]) * 100, 1), tol=0.051)
check("hCPEB3 surface aromatic (%)", 11.1,
      round(float(gram.loc["8SPA", "surf_f_aromatic"]) * 100, 1), tol=0.051)
check("Orb2 exposed fraction", 0.645,
      round(float(gram.loc["6VPS", "frac_exposed"]), 3))
check("hCPEB3 exposed fraction", 0.367,
      round(float(gram.loc["8SPA", "frac_exposed"]), 3))
check("Orb2-hCPEB3 grammar distance", 6.07,
      round(float(diag["grammar_distance"]["cross"]["Orb2_core|hCPEB3_core"]), 2))

print("\n== Layer 2, external screen ==")
check("HTT-polyQ amide (%)", 69.3,
      round(float(dc.loc["HTT_polyQ_APR", "c_f_amide"]) * 100, 1), tol=0.051)
check("HTT-polyQ aromatic (%)", 1.0,
      round(float(dc.loc["HTT_polyQ_APR", "c_f_aromatic"]) * 100, 1), tol=0.051)
check("mutFUS amide (%)", 23.4,
      round(float(dc.loc["mutFUS_APR", "c_f_amide"]) * 100, 1), tol=0.051)
check("mutFUS aromatic (%)", 12.6,
      round(float(dc.loc["mutFUS_APR", "c_f_aromatic"]) * 100, 1), tol=0.051)
check("Orb2 vs HTT-polyQ distance", 4.68,
      round(float(diag["grammar_distance"]["orb2_vs_polyQ"]), 2))
check("hCPEB3 vs mutFUS distance", 3.74,
      round(float(diag["grammar_distance"]["cpeb3_vs_FUS"]), 2))
check("mismatched mean distance", 5.91,
      round(float(diag["grammar_distance"]["mismatched_mean"]), 2))
cr = list(diag["grammar_distance"]["cross"].values())
check("mismatched min distance", 5.64, round(min(cr), 2))
check("mismatched max distance", 6.17, round(max(cr), 2))
rr = diag["responders"]
check("chaperones scored against both clients", 65, int(len(roz)))
check("profile Spearman rho", 0.093, round(float(rr["spearman_rho"]), 3))
check("profile Spearman P", 0.46, round(float(rr["spearman_p"]), 2))
check("profile Pearson r", -0.130, round(float(rr["pearson_r"]), 3))
check("profile Pearson P", 0.30, round(float(rr["pearson_p"]), 2))
check("polyQ control band (2 SD)", 0.142,
      round(float(diag["control_band"]["HTT_polyQ"]["thr"]), 3))
check("polyQ control replicates", 15, int(diag["control_band"]["HTT_polyQ"]["n"]))
check("mutFUS control band (2 SD)", 0.129,
      round(float(diag["control_band"]["mutFUS"]["thr"]), 3))
check("mutFUS control replicates", 30, int(diag["control_band"]["mutFUS"]["n"]))
check("polyQ responders", 35, int(rr["n_polyQ"]))
check("mutFUS responders", 27, int(rr["n_FUS"]))
check("shared responders", 15, int(rr["shared"]))
check("Fisher odds ratio", 1.12, round(float(rr["odds"]), 2)
      if "odds" in rr else round(float(rr.get("odds_ratio", np.nan)), 2))
check("top-10 overlap", 4, int(rr["topk_overlap"]))
check("top-10 hypergeometric P", 0.039, round(float(rr["topk_p"]), 3))
r8 = roz.set_index("chaperone")
check("DNAJB8 on HTT-polyQ", -1.000, round(float(r8.loc["DNAJB8", "HTT_polyQ"]), 3))
check("DNAJB8 on mutFUS", 0.155, round(float(r8.loc["DNAJB8", "mutFUS"]), 3))
check("DNAJC5 on mutFUS", -3.729, round(float(r8.loc["DNAJC5", "mutFUS"]), 3))
check("DNAJC5 on HTT-polyQ", -0.113, round(float(r8.loc["DNAJC5", "HTT_polyQ"]), 3))
f5 = full[(full.chaperone == "DNAJC5")].set_index("client")
check("DNAJC5 mutFUS SD", 1.188, round(float(f5.loc["mutFUS", "ams_sd"]), 3))
check("DNAJC5 polyQ SD", 0.071, round(float(f5.loc["HTT_polyQ", "ams_sd"]), 3))

print("\n== Layer 2b, nested models ==")
n = diag["nested"]
check("Q2, client main effect", 0.062, round(float(n["M0 client main effect"]["q2"]), 3))
check("Q2, + chaperone composition", 0.122,
      round(float(n["M1 + chaperone composition"]["q2"]), 3))
check("Q2, + bilinear interactions", 0.136,
      round(float(n["M2 + bilinear interactions"]["q2"]), 3))
check("delta Q2", 0.015, round(float(diag["increment"]["dq2"]), 3))
check("Wilcoxon P on squared errors", 0.036,
      round(float(diag["increment"]["wilcoxon_p"]), 3))
check("composition permutation P", 0.022,
      round(float(diag["increment"]["permutation_p"]), 3))
check("bilinear interaction terms", 144,
      int(n["M2' bilinear interactions only"]["n_features"]))
gm = json.load(open(RES / "grammar_model.json"))
check("preference model CV r", -0.158, round(float(gm["pref_cv_r"]), 3))
check("preference model CV P", 0.21, round(float(gm["pref_cv_p"]), 2))
check("preference model Q2", -0.064, round(float(gm["pref_q2"]), 3))
check("preference model permutation P", 0.28, round(float(gm["pref_perm_p"]), 2))

print("\n== Layer 3 ==")
check("CPEB3 brain median TPM", 6.1,
      round(float(L3.loc["CPEB3", "brain_tpm_median"]), 1), tol=0.051)
check("CPEB3 cortex TPM", 9.5, round(float(L3.loc["CPEB3", "cortex_tpm"]), 1),
      tol=0.051)
check("CPEB3 brain enrichment", 0.68,
      round(float(L3.loc["CPEB3", "brain_enrichment_log2"]), 2))
check("DNAJC8 brain median TPM", 50.8,
      round(float(L3.loc["DNAJC8", "brain_tpm_median"]), 1), tol=0.051)
check("DNAJC8 non-brain median TPM", 65.6,
      round(float(L3.loc["DNAJC8", "nonbrain_tpm_median"]), 1), tol=0.051)
check("DNAJC8 brain enrichment", -0.36,
      round(float(L3.loc["DNAJC8", "brain_enrichment_log2"]), 2))
check("DNAJC8 CPEB3 co-expression", 0.008,
      round(float(L3.loc["DNAJC8", "cpeb3_coexpr_rho"]), 3))
check("DNAJB2 brain median TPM", 124.4,
      round(float(L3.loc["DNAJB2", "brain_tpm_median"]), 1), tol=0.051)
check("DNAJB2 brain enrichment", 1.01,
      round(float(L3.loc["DNAJB2", "brain_enrichment_log2"]), 2))
check("DNAJB2 CPEB3 co-expression", 0.760,
      round(float(L3.loc["DNAJB2", "cpeb3_coexpr_rho"]), 3))
check("DNAJC5 brain median TPM", 71.0,
      round(float(L3.loc["DNAJC5", "brain_tpm_median"]), 1), tol=0.051)
check("DNAJC5 brain enrichment", 0.82,
      round(float(L3.loc["DNAJC5", "brain_enrichment_log2"]), 2))
check("DNAJC5 CPEB3 co-expression", 0.460,
      round(float(L3.loc["DNAJC5", "cpeb3_coexpr_rho"]), 3))
check("DNAJA4 brain median TPM", 48.6,
      round(float(L3.loc["DNAJA4", "brain_tpm_median"]), 1), tol=0.051)
check("DNAJA4 brain enrichment", 1.33,
      round(float(L3.loc["DNAJA4", "brain_enrichment_log2"]), 2))
check("DNAJA4 CPEB3 co-expression", 0.614,
      round(float(L3.loc["DNAJA4", "cpeb3_coexpr_rho"]), 3))
check("DNAJC6 brain enrichment", 4.05,
      round(float(L3.loc["DNAJC6", "brain_enrichment_log2"]), 2))
check("JDPs passing prefilter", 42, int(integ["n_jdp_prefiltered"]))
check("DNAJC8 Layer 1 rank", 1, int(integ["dnajc8"]["rank_L1"]))
check("DNAJC8 PRISM-J rank", 36, int(integ["dnajc8"]["rank_prismj"]))
check("DNAJB2 Layer 1 rank", 5, int(rankt.loc["DNAJB2", "rank_L1"]))
check("DNAJC5 Layer 1 rank", 9, int(rankt.loc["DNAJC5", "rank_L1"]))
li = integ["layer_independence"]
check("rho(L1, L2)", -0.069, round(float(li["rho_L1_L2"]), 3))
check("P(L1, L2)", 0.67, round(float(li["p_L1_L2"]), 2))
check("rho(L1, L3)", -0.074, round(float(li["rho_L1_L3"]), 3))
check("P(L1, L3)", 0.64, round(float(li["p_L1_L3"]), 2))
check("rho(L1, PRISM-J)", -0.051, round(float(li["rho_L1_prismj"]), 3))
check("P(L1, PRISM-J)", 0.75, round(float(li["p_L1_prismj"]), 2))

print("\n== Layer 4 ==")
if (RES / "layer4_stats.json").exists():
    s4 = json.load(open(RES / "layer4_stats.json"))
    print(json.dumps(s4.get("dynamic_range", {}), indent=1))
    if "preference" in s4:
        print(json.dumps({k: v for k, v in s4["preference"].items()
                          if k not in ("ddG", "sd")}, indent=1))
else:
    print("[skip] layer4_stats.json not yet generated")

print("\n== manuscript integrity ==")
if MS.exists():
    text = MS.read_text()
    holes = re.findall(r"\[(?:RESULTS_[A-Z0-9_]+|DISCUSSION|CONCLUSIONS|"
                       r"DATA_AVAILABILITY|REFERENCES)\]", text)
    check("unfilled manuscript placeholders", 0, len(holes))
    if holes:
        print("   remaining:", sorted(set(holes)))
    figs = sorted(set(re.findall(r"\[Figure (\d+) near here\]", text)))
    check("figure callouts present and ordered", True,
          figs == [str(i) for i in range(1, len(figs) + 1)])
    eqs = re.findall(r"\s\((\d+[ab]?)\)(?:\s|$)", text)
    eq_seq = sorted(set(eqs), key=lambda s: (int(re.sub(r"[ab]", "", s)), s))
    print(f"   equation numbers found: {eq_seq}")
    base = sorted({int(re.sub(r"[ab]", "", e)) for e in eq_seq})
    check("equation numbering contiguous from 1", True,
          base == list(range(1, len(base) + 1)))
    refs = re.findall(r"<sup>([0-9,\-\s]+)</sup>", text)
    nums = set()
    for r in refs:
        for part in r.split(","):
            part = part.strip()
            if "-" in part:
                a, b = part.split("-")
                if a.strip().isdigit() and b.strip().isdigit():
                    nums.update(range(int(a), int(b) + 1))
            elif part.isdigit():
                nums.add(int(part))
    if nums:
        print(f"   citation numbers cited in text: {min(nums)}-{max(nums)}, "
              f"{len(nums)} distinct")
        missing = sorted(set(range(1, max(nums) + 1)) - nums)
        check("no gaps in citation numbering", 0, len(missing))
        if missing:
            print("   uncited numbers:", missing)
else:
    print("[skip] manuscript not found")

print(f"\n{'='*64}\n{len(ok)} checks passed, {len(bad)} failed")
if bad:
    for lab, c, a in bad:
        print(f"  FAIL {lab}: manuscript {c} vs computed {a}")
    sys.exit(1)
print("all numeric claims in the manuscript match the computed results")
