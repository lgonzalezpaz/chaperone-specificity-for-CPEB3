#!/usr/bin/env python3
"""
calvados_cg.py

Minimal, self-contained implementation of the CALVADOS 2 residue-resolution
coarse-grained model for intrinsically disordered proteins, built directly on
OpenMM.

Model and parameters as published in:
  Tesei G, Schulze TK, Crehuet R, Lindorff-Larsen K. Accurate model of
  liquid-liquid phase behavior of intrinsically disordered proteins from
  optimization of single-chain properties. Proc Natl Acad Sci USA
  2021;118:e2111696118.
  Tesei G, Lindorff-Larsen K. Improved predictions of phase behaviour of
  intrinsically disordered proteins by tuning the interaction range.
  Open Res Europe 2022;2:94.

Functional form (reproduced from the reference implementation at
https://github.com/KULL-Centre/CALVADOS, GPL-3.0):

  Ashbaugh-Hatch:
    r <= 2^(1/6) s :  U = 4e[(s/r)^12 - (s/r)^6 - l*shift] + (1-l)e
    r >  2^(1/6) s :  U = 4el[(s/r)^12 - (s/r)^6 - shift]
    s = (s_i + s_j)/2 ,  l = (l_i + l_j)/2 ,  shift = (s/rc)^12 - (s/rc)^6
    e = 0.2 kcal/mol = 0.8368 kJ/mol , rc = 2.0 nm

  Debye-Huckel (Yukawa), shifted:
    U = q_i q_j * B * [exp(-k r)/r - exp(-k rc)/rc] ,  rc = 4.0 nm
    B  = Bjerrum length * kT ; k = sqrt(8 pi lB I NA / 10)
    relative permittivity of water from a temperature polynomial

  Bonds: harmonic, k = 8033 kJ/mol/nm^2, r0 = 0.38 nm
  Dynamics: LangevinMiddle, friction 0.01 ps^-1, timestep 10 fs
  Termini: +1 on the N-terminal and -1 on the C-terminal bead
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import openmm
from openmm import unit, app

GAS_CONSTANT = 8.3145          # J mol^-1 K^-1
ELEMENTARY_CHARGE = 1.6021766  # 1e-19 C
VACUUM_PERMITTIVITY = 8.854188  # 1e-12 F m^-1
AVOGADRO = 6.02214076          # 1e23 mol^-1

EPS_LJ_KJ = 0.2 * 4.184        # kJ/mol
CUTOFF_LJ = 2.0                # nm
CUTOFF_YU = 4.0                # nm
KB_BOND = 8033.0               # kJ/mol/nm^2
R0_BOND = 0.38                 # nm
FRICTION = 0.01                # ps^-1
DT_PS = 0.01                   # ps


def relative_permittivity(temp: float) -> float:
    return (5321 / temp + 233.76 - 0.9297 * temp
            + 0.1417e-2 * temp * temp - 0.8292e-6 * temp ** 3)


def dh_params(temp: float, ionic: float) -> tuple[float, float]:
    """Yukawa prefactor (kJ/mol nm) and inverse Debye length (nm^-1)."""
    kt = GAS_CONSTANT * temp * 1e-3
    er = relative_permittivity(temp)
    lb = (ELEMENTARY_CHARGE ** 2 / (4 * np.pi * VACUUM_PERMITTIVITY * er)
          * AVOGADRO * 1000 / kt)
    eps_yu = lb * kt
    k_yu = np.sqrt(8 * np.pi * lb * ionic * AVOGADRO / 10)
    return eps_yu, k_yu


def load_residues(path) -> pd.DataFrame:
    df = pd.read_csv(path).set_index("one")
    return df


def charges(seq: str, res: pd.DataFrame, pH: float = 7.0,
            flexhis: bool = False, charge_termini: bool = True) -> np.ndarray:
    q = np.array([1.0 / (1 + 10 ** (pH - 6.0)) if (flexhis and s == "H")
                  else float(res.loc[s, "q"]) for s in seq])
    if charge_termini:
        q = q.copy()
        q[0] += 1.0
        q[-1] -= 1.0
    return q


class CGSystem:
    """A multi-chain CALVADOS 2 system in a cubic periodic box."""

    def __init__(self, seqs: list[str], residues: pd.DataFrame,
                 box: float = 15.0, temp: float = 310.0, ionic: float = 0.15,
                 pH: float = 7.0, flexhis: bool = False,
                 charge_termini: bool = True):
        self.seqs = seqs
        self.res = residues
        self.box = box
        self.temp = temp
        self.n_chain = [len(s) for s in seqs]
        self.n_tot = sum(self.n_chain)
        self.offsets = np.cumsum([0] + self.n_chain[:-1])

        sig = np.concatenate([[residues.loc[c, "sigmas"] for c in s] for s in seqs])
        lam = np.concatenate([[residues.loc[c, "lambdas"] for c in s] for s in seqs])
        mw = np.concatenate([[residues.loc[c, "MW"] for c in s] for s in seqs])
        q = np.concatenate([charges(s, residues, pH, flexhis, charge_termini)
                            for s in seqs])
        self.sig, self.lam, self.q, self.mw = sig, lam, q, mw

        system = openmm.System()
        L = box * unit.nanometer
        system.setDefaultPeriodicBoxVectors(
            openmm.Vec3(box, 0, 0) * unit.nanometer,
            openmm.Vec3(0, box, 0) * unit.nanometer,
            openmm.Vec3(0, 0, box) * unit.nanometer)
        for m in mw:
            system.addParticle(float(m) * unit.amu)

        # ---- bonds
        hb = openmm.HarmonicBondForce()
        hb.setUsesPeriodicBoundaryConditions(True)
        exclusions = []
        for ci, n in enumerate(self.n_chain):
            off = int(self.offsets[ci])
            for i in range(n - 1):
                hb.addBond(off + i, off + i + 1,
                           R0_BOND * unit.nanometer,
                           KB_BOND * unit.kilojoule_per_mole / unit.nanometer ** 2)
                exclusions.append((off + i, off + i + 1))
        system.addForce(hb)

        # ---- Ashbaugh-Hatch
        ah_expr = (f"{EPS_LJ_KJ}*select(step(r-2^(1/6)*s),"
                   "4*l*((s/r)^12-(s/r)^6-shift),"
                   "4*((s/r)^12-(s/r)^6-l*shift)+(1-l))"
                   "; l=0.5*(l1+l2)"
                   f"; shift=(s/{CUTOFF_LJ})^12-(s/{CUTOFF_LJ})^6"
                   "; s=0.5*(s1+s2)")
        ah = openmm.CustomNonbondedForce(ah_expr)
        ah.addPerParticleParameter("s")
        ah.addPerParticleParameter("l")
        ah.setNonbondedMethod(openmm.CustomNonbondedForce.CutoffPeriodic)
        ah.setCutoffDistance(CUTOFF_LJ * unit.nanometer)
        ah.setForceGroup(0)
        for i in range(self.n_tot):
            ah.addParticle([float(sig[i]), float(lam[i])])

        # ---- Debye-Huckel
        eps_yu, k_yu = dh_params(temp, ionic)
        self.eps_yu, self.k_yu, self.debye = eps_yu, k_yu, 1.0 / k_yu
        shift = np.exp(-k_yu * CUTOFF_YU) / CUTOFF_YU
        yu = openmm.CustomNonbondedForce(
            f"qq*{eps_yu}*(exp(-{k_yu}*r)/r-{shift}); qq=q1*q2")
        yu.addPerParticleParameter("q")
        yu.setNonbondedMethod(openmm.CustomNonbondedForce.CutoffPeriodic)
        yu.setCutoffDistance(CUTOFF_YU * unit.nanometer)
        yu.setForceGroup(1)
        for i in range(self.n_tot):
            yu.addParticle([float(q[i])])

        for a, b in exclusions:
            ah.addExclusion(a, b)
            yu.addExclusion(a, b)
        system.addForce(ah)
        system.addForce(yu)
        self.system = system
        self.ah, self.yu = ah, yu

    # ------------------------------------------------------------ geometry
    def initial_coords(self, seed: int = 0, sep: float = 4.0) -> np.ndarray:
        """Self-avoiding random walks, one per chain, placed apart."""
        rng = np.random.default_rng(seed)
        xyz = np.zeros((self.n_tot, 3))
        centres = self._chain_centres(sep)
        for ci, n in enumerate(self.n_chain):
            off = int(self.offsets[ci])
            pos = np.zeros((n, 3))
            for i in range(1, n):
                for _ in range(200):
                    v = rng.normal(size=3)
                    v *= R0_BOND / np.linalg.norm(v)
                    cand = pos[i - 1] + v
                    if i < 3 or np.min(np.linalg.norm(pos[:i - 1] - cand, axis=1)) > 0.35:
                        break
                pos[i] = cand
            pos -= pos.mean(0)
            xyz[off:off + n] = pos + centres[ci]
        return xyz

    def _chain_centres(self, sep: float) -> np.ndarray:
        c = self.box / 2.0
        if len(self.n_chain) == 1:
            return np.array([[c, c, c]])
        return np.array([[c - sep / 2, c, c], [c + sep / 2, c, c]]
                        + [[c, c + sep * (k + 1), c] for k in range(len(self.n_chain) - 2)])

    # ----------------------------------------------------------- restraint
    def add_com_restraint(self, k: float = 400.0, r0: float = 3.0):
        """Harmonic restraint on the distance between chain centroids."""
        g0 = list(range(0, self.n_chain[0]))
        g1 = list(range(self.n_chain[0], self.n_chain[0] + self.n_chain[1]))
        f = openmm.CustomCentroidBondForce(2, "0.5*k*(distance(g1,g2)-r0)^2")
        f.addPerBondParameter("k")
        f.addPerBondParameter("r0")
        f.addGroup(g0, [float(m) for m in self.mw[g0]])
        f.addGroup(g1, [float(m) for m in self.mw[g1]])
        f.addBond([0, 1], [k, r0])
        f.setUsesPeriodicBoundaryConditions(True)
        f.setForceGroup(2)
        self.system.addForce(f)
        self.restraint = f
        return f

    # ------------------------------------------------------------ simulate
    def simulation(self, coords: np.ndarray, seed: int = 0,
                   platform: str = "CPU", threads: int = 1):
        integ = openmm.LangevinMiddleIntegrator(
            self.temp * unit.kelvin, FRICTION / unit.picosecond,
            DT_PS * unit.picosecond)
        integ.setRandomNumberSeed(seed)
        plat = openmm.Platform.getPlatformByName(platform)
        props = {"Threads": str(threads)} if platform == "CPU" else {}
        top = self._topology()
        sim = app.Simulation(top, self.system, integ, plat, props)
        sim.context.setPositions(coords * unit.nanometer)
        return sim

    def _topology(self):
        top = app.Topology()
        for ci, s in enumerate(self.seqs):
            ch = top.addChain()
            for aa in s:
                r = top.addResidue(aa, ch)
                top.addAtom("CA", app.Element.getBySymbol("C"), r)
        top.setPeriodicBoxVectors(
            np.eye(3) * self.box * unit.nanometer)
        return top


def com_distance(pos: np.ndarray, n1: int, mw: np.ndarray,
                 box: float) -> float:
    """Minimum-image mass-weighted centroid distance between two chains."""
    a = np.average(pos[:n1], axis=0, weights=mw[:n1])
    b = np.average(pos[n1:], axis=0, weights=mw[n1:])
    d = b - a
    d -= box * np.round(d / box)
    return float(np.linalg.norm(d))
