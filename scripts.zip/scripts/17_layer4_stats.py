#!/usr/bin/env python3
"""
17_layer4_stats.py  --  formal analysis of the association free energies

Tests whether the coarse-grained model resolves any chaperone-by-client
interaction, i.e. whether the clients are discriminated at all, and
quantifies the dynamic range of the method from the sequence-scrambled
control.

Outputs: results/layer4_stats.json
"""
import json
import pathlib
import numpy as np
import pandas as pd
from scipy import stats

ROOT = pathlib.Path(__file__).resolve().parents[1]
RES = ROOT / "results"
cg = pd.read_csv(RES / "cg_summary.tsv", sep="\t")

print(f"systems: {len(cg)}")
print(cg[["chaperone", "client", "dG_kJmol", "dG_sd_kJmol",
          "dG_replica_spread"]].round(2).to_string(index=False))

# ------------------------------------------------- overall dynamic range
main = cg[cg.client.isin(["Orb2_core", "hCPEB3_core"])]
rng = main.dG_kJmol.max() - main.dG_kJmol.min()
med_sd = main.dG_sd_kJmol.median()
med_rep = main.dG_replica_spread.median()
print(f"\nmain set: n = {len(main)}, dG from {main.dG_kJmol.min():.2f} to "
      f"{main.dG_kJmol.max():.2f} kJ/mol (range {rng:.2f})")
print(f"  median bootstrap SD {med_sd:.2f}; median replica spread {med_rep:.2f} kJ/mol")

# --------------------------------------- paired chaperone-by-client test
w = main.pivot_table(index="chaperone", columns="client", values="dG_kJmol")
wsd = main.pivot_table(index="chaperone", columns="client", values="dG_sd_kJmol")
both = w.dropna()
res = {}
if len(both) >= 3:
    d = (both["hCPEB3_core"] - both["Orb2_core"])
    sd = np.sqrt(wsd.loc[both.index, "hCPEB3_core"] ** 2
                 + wsd.loc[both.index, "Orb2_core"] ** 2)
    print(f"\nper-chaperone client preference, "
          f"ddG = dG(hCPEB3) - dG(Orb2), n = {len(both)}")
    for g in both.index:
        print(f"  {g:8s} {d[g]:+6.2f} +/- {sd[g]:.2f} kJ/mol")
    t, p_t = stats.ttest_1samp(d, 0.0)
    wst, p_w = stats.wilcoxon(d) if len(d) >= 6 else (np.nan, np.nan)
    # is the between-chaperone spread of ddG larger than its own uncertainty?
    chi2 = float(np.sum((d - d.mean()) ** 2 / sd ** 2))
    dof = len(d) - 1
    p_het = float(stats.chi2.sf(chi2, dof))
    print(f"  mean ddG = {d.mean():+.2f} kJ/mol (one-sample t = {t:.2f}, "
          f"P = {p_t:.3f})")
    print(f"  heterogeneity across chaperones: chi2 = {chi2:.2f}, "
          f"df = {dof}, P = {p_het:.3f}")
    res["preference"] = dict(
        n=int(len(both)), ddG={k: float(v) for k, v in d.items()},
        sd={k: float(v) for k, v in sd.items()}, mean=float(d.mean()),
        t=float(t), p_t=float(p_t),
        wilcoxon_p=float(p_w) if np.isfinite(p_w) else None,
        chi2=chi2, dof=int(dof), p_heterogeneity=p_het)

# ------------------- computed preference against the measured preference
roz = pd.read_csv(RES / "rozales_scores_wide.tsv", sep="\t")
roz = roz[roz.chaperone != "dsred"].copy()
roz["gene"] = (roz.chaperone.str.replace("-FL", "", regex=False)
               .str.replace("-short", "", regex=False)
               .str.replace(r"b$", "", regex=True))
exp = roz.groupby("gene")[["HTT_polyQ", "mutFUS"]].mean()
# experimental preference for the aromatic client, on the same sign
# convention as the computed quantity: more negative = prefers aromatic
exp["pref"] = exp["mutFUS"] - exp["HTT_polyQ"]
if "preference" in res:
    dd = pd.Series(res["preference"]["ddG"])
    common = [g for g in dd.index if g in exp.index]
    if len(common) >= 4:
        x = exp.loc[common, "pref"].to_numpy(float)
        y = dd.loc[common].to_numpy(float)
        r_p, p_p = stats.pearsonr(x, y)
        rho_s, p_s = stats.spearmanr(x, y)
        print(f"\ncomputed vs measured client preference, n = {len(common)} "
              f"({', '.join(common)})")
        for g in common:
            print(f"  {g:8s} measured {exp.loc[g,'pref']:+6.2f}   "
                  f"computed {dd[g]:+6.2f} kJ/mol")
        print(f"  Pearson r = {r_p:+.3f}, P = {p_p:.3f}; "
              f"Spearman rho = {rho_s:+.3f}, P = {p_s:.3f}")
        res["experiment_vs_theory"] = dict(
            n=int(len(common)), genes=common, pearson_r=float(r_p),
            pearson_p=float(p_p), spearman_rho=float(rho_s),
            spearman_p=float(p_s),
            measured={g: float(exp.loc[g, "pref"]) for g in common},
            computed={g: float(dd[g]) for g in common})

# ---------------------------------------- scrambled-sequence control
scr = cg[cg.client == "hCPEB3_core_shuffled"]
if len(scr):
    print("\nsequence-scrambled control (composition preserved, order destroyed)")
    for _, r in scr.iterrows():
        nat = cg[(cg.chaperone == r.chaperone) & (cg.client == "hCPEB3_core")]
        if len(nat):
            n0 = nat.iloc[0]
            diff = r.dG_kJmol - n0.dG_kJmol
            comb = np.sqrt(r.dG_sd_kJmol ** 2 + n0.dG_sd_kJmol ** 2)
            print(f"  {r.chaperone}: native {n0.dG_kJmol:.2f}, scrambled "
                  f"{r.dG_kJmol:.2f}, difference {diff:+.2f} +/- {comb:.2f} kJ/mol")
            res.setdefault("scramble", {})[r.chaperone] = dict(
                native=float(n0.dG_kJmol), scrambled=float(r.dG_kJmol),
                difference=float(diff), combined_sd=float(comb))

# ---------------------------------------------- grammar ladder regression
CAL = pd.read_csv(ROOT / "data" / "residues_CALVADOS2.csv").set_index("one")
LAM = CAL["lambdas"].to_dict()
seqs = json.load(open(RES / "designed_orb2_cores.json"))
core = pd.read_csv(RES / "core_sequences.tsv", sep="\t")
SEQ = {"Orb2_core": core.loc[core.pdb == "6VPS", "sequence"].iloc[0],
       "hCPEB3_core": core.loc[core.pdb == "8SPA", "sequence"].iloc[0],
       "Orb2_LVLVF": seqs.get("9PX8"), "Orb2_FVLVF": seqs.get("9YWA"),
       "Orb2_FIMMF": seqs.get("9Y1V")}
LADDER = ["Orb2_core", "Orb2_LVLVF", "Orb2_FVLVF", "Orb2_FIMMF"]
lad = cg[cg.client.isin(LADDER)].copy()
if lad.client.nunique() >= 3:
    lad["lam"] = lad.client.map(
        lambda c: float(np.mean([LAM[x] for x in SEQ[c]])))
    lad["n_sub"] = lad.client.map(
        lambda c: sum(a != b for a, b in zip(SEQ["Orb2_core"], SEQ[c])))
    print("\ngrammar titration on the invariant Orb2 scaffold")
    res["ladder"] = {}
    for chap, sub in lad.groupby("chaperone"):
        sub = sub.sort_values("lam")
        if len(sub) < 3:
            continue
        sl, ic, r_, p_, se = stats.linregress(sub.lam, sub.dG_kJmol)
        print(f"  {chap}: n = {len(sub)}, slope = {sl:.1f} kJ/mol per unit "
              f"lambda, r = {r_:.3f}, P = {p_:.3f}")
        for _, q in sub.iterrows():
            print(f"      {q.client:12s} lambda = {q.lam:.3f}  "
                  f"dG = {q.dG_kJmol:+6.2f} +/- {q.dG_sd_kJmol:.2f}")
        res["ladder"][chap] = dict(n=int(len(sub)), slope=float(sl),
                                   r=float(r_), p=float(p_), stderr=float(se),
                                   points=sub[["client", "lam", "dG_kJmol",
                                               "dG_sd_kJmol"]
                                              ].to_dict("records"))

res["dynamic_range"] = dict(n=int(len(main)), min=float(main.dG_kJmol.min()),
                            max=float(main.dG_kJmol.max()), range=float(rng),
                            median_bootstrap_sd=float(med_sd),
                            median_replica_spread=float(med_rep))
json.dump(res, open(RES / "layer4_stats.json", "w"), indent=1)
print("\n[ok] layer4_stats.json written")
