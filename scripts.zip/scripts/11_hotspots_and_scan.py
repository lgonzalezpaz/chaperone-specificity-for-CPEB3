#!/usr/bin/env python3
"""
11_hotspots_and_scan.py  --  PRISM-J Layer 4c (interface map and in-silico scan)

For the systems that matter mechanistically, samples the bound-state ensemble
under a flat-bottom restraint only (no umbrella bias), and reports

  (i)  per-residue intermolecular contact frequency on both chains,
  (ii) per-residue intermolecular interaction energy,
  (iii) a reduced-cost alanine scan of the predicted client hotspots,
       computed with matched settings for wild type and each substitution so
       that the differences are internally comparable.

Outputs (results/):
  hotspots_<system>.tsv, alanine_scan.tsv
"""
import argparse
import json
import pathlib
import sys
import time
import numpy as np
import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from calvados_cg import load_residues
from cg_setup import build, start_coords, wham, pmf_to_dg
from cg_engine import minimize, run_bound_ensemble, run_baoab, R_GAS
import importlib
mod = importlib.import_module("09_cg_binding")

ROOT = pathlib.Path(__file__).resolve().parents[1]
RES = ROOT / "results"
OUT = RES / "cg"
RESIDUES = load_residues(ROOT / "data" / "residues_CALVADOS2.csv")

LADDER = json.load(open(RES / "grammar_ladder_sequences.json")) \
    if (RES / "grammar_ladder_sequences.json").exists() else {}
mod.CLIENTS.update(LADDER)

ENSEMBLE_SYSTEMS = [
    ("Funes", "Orb2_core"),
    ("DNAJB2", "hCPEB3_core"),
    ("DNAJC8", "hCPEB3_core"),
    ("DNAJC5", "hCPEB3_core"),
]
N_STEPS = 1_500_000
STRIDE = 2_000
RWALL_B = 4.0          # keeps the pair within contact range of each other
KWALL_B = 400.0
CUTOFF = 0.8
N_REP_ENS = 2

# reduced-cost settings for the comparative scan
SCAN_WINDOWS = np.arange(0.5, 6.51, 0.6)
SCAN_PROD = 150_000
SCAN_EQ = 40_000
SCAN_REP = 1


def cbr_for(chap):
    acc = mod.ACC[chap]
    a, b = mod.SPAN[acc]
    return mod.cbr_of(mod.JDP[acc], a, b)


def bound_ensemble(chap, client):
    cbr, c0, c1 = cbr_for(chap)
    cseq = mod.CLIENTS[client]
    sysd = build([cbr, cseq], RESIDUES, temp=mod.TEMP, ionic=mod.IONIC)
    n1 = sysd["nchain"][0]
    cA = np.zeros(n1); cB = np.zeros(len(cseq))
    eA = np.zeros(n1); eB = np.zeros(len(cseq))
    nb = nf = 0
    for rep in range(N_REP_ENS):
        seed = int(abs(hash((chap, client, rep))) % (2 ** 31))
        x = start_coords(sysd, seed=seed, sep=2.0)
        minimize(x, sysd["sig"], sysd["lam"], sysd["q"], sysd["bi"], sysd["bj"],
                 sysd["excl"], sysd["eps_yu"], sysd["k_yu"], sysd["shift_yu"],
                 4000, 0.02)
        rng = np.random.default_rng(seed + 5)
        v = np.ascontiguousarray(
            rng.normal(size=x.shape) * np.sqrt(R_GAS * mod.TEMP / sysd["mw"])[:, None])
        run_baoab(x, v, sysd["mw"], sysd["sig"], sysd["lam"], sysd["q"],
                  sysd["bi"], sysd["bj"], sysd["excl"], sysd["eps_yu"],
                  sysd["k_yu"], sysd["shift_yu"], mod.TEMP, 0.01, 0.01,
                  100_000, 100_000, 0.0, 0.0, n1, RWALL_B, KWALL_B, seed + 6)
        a, b, ea, eb, nbi, nfi = run_bound_ensemble(
            x, v, sysd["mw"], sysd["sig"], sysd["lam"], sysd["q"],
            sysd["bi"], sysd["bj"], sysd["excl"], sysd["eps_yu"], sysd["k_yu"],
            sysd["shift_yu"], mod.TEMP, 0.01, 0.01, N_STEPS, STRIDE,
            n1, RWALL_B, KWALL_B, CUTOFF, seed + 7)
        cA += a; cB += b; eA += ea; eB += eb; nb += nbi; nf += nfi
    rows = []
    for i, aa in enumerate(cbr):
        rows.append(dict(chain="chaperone", protein=chap, idx=i + 1,
                         resnum=c0 + i, aa=aa,
                         contacts_per_frame=cA[i] / nf,
                         energy_kJmol=eA[i] / nf))
    off = 103 if client.startswith("hCPEB3") else 23
    for j, aa in enumerate(cseq):
        rows.append(dict(chain="client", protein=client, idx=j + 1,
                         resnum=off + j, aa=aa,
                         contacts_per_frame=cB[j] / nf,
                         energy_kJmol=eB[j] / nf))
    df = pd.DataFrame(rows)
    df.to_csv(RES / f"hotspots_{chap}__{client}.tsv", sep="\t", index=False)
    print(f"[ok] {chap}+{client}: {nf} frames, bound fraction "
          f"{nb/max(1,nf):.3f}, total interface energy "
          f"{df.energy_kJmol.sum():.1f} kJ/mol", flush=True)
    return df


def scan_dg(cbr, cseq, label, seed0=101):
    sysd = build([cbr, cseq], RESIDUES, temp=mod.TEMP, ionic=mod.IONIC)
    samples, centres = [], []
    for r0 in SCAN_WINDOWS:
        rs, us, _ = mod.equilibrate_and_sample(
            sysd, r0=float(r0), kum=mod.K_UM, rwall=mod.R_WALL, kwall=mod.K_WALL,
            n_eq=SCAN_EQ, n_prod=SCAN_PROD, stride=200,
            seed=seed0 + int(r0 * 100))
        samples.append(rs); centres.append(float(r0))
    bins = np.linspace(0.0, mod.R_WALL, 121)
    mid, pmf, _ = wham(samples, centres, mod.K_UM, mod.TEMP, bins,
                       tol=1e-8, max_iter=40_000)
    dG, Ka, _ = pmf_to_dg(mid, pmf, mod.TEMP, mod.R_BOUND, mod.PLATEAU)
    print(f"    {label:28s} dG = {dG:7.2f} kJ/mol", flush=True)
    return float(dG)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", choices=["ensemble", "scan"], default="ensemble")
    ap.add_argument("--chap", default=None)
    ap.add_argument("--client", default="hCPEB3_core")
    ap.add_argument("--worker", type=int, default=0)
    ap.add_argument("--nworkers", type=int, default=1)
    args = ap.parse_args()

    if args.stage == "ensemble":
        todo = [s for i, s in enumerate(ENSEMBLE_SYSTEMS)
                if i % args.nworkers == args.worker]
        for chap, client in todo:
            if (RES / f"hotspots_{chap}__{client}.tsv").exists():
                print(f"[skip] {chap}__{client}", flush=True)
                continue
            t = time.time()
            bound_ensemble(chap, client)
            print(f"       ({(time.time()-t)/60:.1f} min)", flush=True)
        sys.exit(0)

    # ---- comparative alanine scan on the top system
    chap = args.chap
    client = args.client
    cbr, c0, c1 = cbr_for(chap)
    cseq = mod.CLIENTS[client]
    hs = pd.read_csv(RES / f"hotspots_{chap}__{client}.tsv", sep="\t")
    cl = hs[hs.chain == "client"].nsmallest(4, "energy_kJmol")
    ch = hs[hs.chain == "chaperone"].nsmallest(3, "energy_kJmol")
    print(f"alanine scan for {chap} + {client}")
    rows = [dict(system=f"{chap}__{client}", variant="wild type", chain="-",
                 resnum=-1, aa="-", dG_kJmol=scan_dg(cbr, cseq, "wild type"))]
    wt = rows[0]["dG_kJmol"]
    for _, r in cl.iterrows():
        m = list(cseq); m[int(r.idx) - 1] = "A"
        lab = f"client {r.aa}{int(r.resnum)}A"
        rows.append(dict(system=f"{chap}__{client}", variant=lab, chain="client",
                         resnum=int(r.resnum), aa=r.aa,
                         dG_kJmol=scan_dg(cbr, "".join(m), lab)))
    for _, r in ch.iterrows():
        m = list(cbr); m[int(r.idx) - 1] = "A"
        lab = f"chaperone {r.aa}{int(r.resnum)}A"
        rows.append(dict(system=f"{chap}__{client}", variant=lab,
                         chain="chaperone", resnum=int(r.resnum), aa=r.aa,
                         dG_kJmol=scan_dg("".join(m), cseq, lab)))
    df = pd.DataFrame(rows)
    df["ddG_kJmol"] = df.dG_kJmol - wt
    df.to_csv(RES / "alanine_scan.tsv", sep="\t", index=False)
    print(df.round(2).to_string(index=False))
