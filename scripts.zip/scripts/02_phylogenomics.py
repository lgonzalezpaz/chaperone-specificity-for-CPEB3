#!/usr/bin/env python3
"""
02_phylogenomics.py  --  PRISM-J Layer 1 (Hsp70-coupling module)

Defines the J-domain of every human J-domain protein (JDP) with the Pfam
PF00226 profile HMM, aligns them with Funes (Drosophila melanogaster),
infers a maximum-likelihood phylogeny, and scores Funes-likeness of the
Hsp70-coupling module for all human JDPs.

Outputs (results/):
  jdomains.fasta           extracted J-domains
  jdomains_aln.fasta       MAFFT L-INS-i alignment
  jdomain_tree.treefile    IQ-TREE ML phylogeny (+ UFBoot)
  layer1_scores.tsv        per-JDP Funes-likeness metrics
"""
import pathlib
import subprocess
import re
import sys
import numpy as np
import pandas as pd
from Bio import SeqIO, AlignIO
from Bio.Align import PairwiseAligner, substitution_matrices

ROOT = pathlib.Path(__file__).resolve().parents[1]
DATA, RES = ROOT / "data", ROOT / "results"
RES.mkdir(exist_ok=True, parents=True)
HMM = DATA / "hmm" / "PF00226.hmm"


def run(cmd, **kw):
    print("+", " ".join(map(str, cmd)), flush=True)
    return subprocess.run(list(map(str, cmd)), check=True,
                          capture_output=True, text=True, **kw)


# ------------------------------------------------------------ 1. assemble
records = {}
for fn in ["human_jdp.fasta", "funes.fasta", "outgroups.fasta"]:
    for rec in SeqIO.parse(DATA / fn, "fasta"):
        acc = rec.id.split("|")[1] if "|" in rec.id else rec.id
        records[acc] = rec

meta = pd.read_csv(DATA / "human_jdp_meta.tsv", sep="\t")
gene_of = dict(zip(meta["Entry"], meta["Gene Names (primary)"]))
gene_of.update({"Q9VCH9": "Funes", "Q9VHM3": "Mrj_Dmel", "P39101": "JJJ2_Scer",
                "P25294": "Sis1_Scer", "P25491": "Ydj1_Scer", "P08622": "DnaJ_Ecoli"})

combined = DATA / "jdp_all.fasta"
with open(combined, "w") as fh:
    for acc, rec in records.items():
        fh.write(f">{acc}|{gene_of.get(acc, acc)}\n{str(rec.seq)}\n")
print(f"[ok] {len(records)} sequences assembled")

# ------------------------------------------- 2. J-domain definition (HMM)
dom = RES / "jdomain_hmmsearch.domtbl"
run(["hmmsearch", "--domtblout", dom, "-E", "1e-3", "--domE", "1e-3",
     HMM, combined], cwd=ROOT)

rows = []
for line in open(dom):
    if line.startswith("#"):
        continue
    f = line.split()
    rows.append(dict(acc=f[0].split("|")[0], gene=f[0].split("|")[1],
                     tlen=int(f[2]), dom_i=int(f[9]), dom_n=int(f[10]),
                     c_evalue=float(f[11]), score=float(f[13]),
                     hmm_from=int(f[15]), hmm_to=int(f[16]),
                     ali_from=int(f[17]), ali_to=int(f[18])))
hits = pd.DataFrame(rows)
# keep the single best-scoring J-domain per protein
best = hits.sort_values("score", ascending=False).drop_duplicates("acc")
print(f"[ok] J-domain detected in {len(best)} / {len(records)} sequences")

missing = set(gene_of) - set(best.acc)
print("[info] no PF00226 hit:", sorted(gene_of[a] for a in missing if a in gene_of))

# pad J-domain to the canonical helix I-IV span (HMM 1-63 -> +/- flanks)
PAD_N, PAD_C = 5, 10
jd_path = RES / "jdomains.fasta"
jd_seqs = {}
with open(jd_path, "w") as fh:
    for _, r in best.iterrows():
        s = str(records[r.acc].seq)
        a = max(0, r.ali_from - 1 - PAD_N)
        b = min(len(s), r.ali_to + PAD_C)
        jd_seqs[r.gene] = s[a:b]
        fh.write(f">{r.gene}\n{s[a:b]}\n")

# ------------------------------------------------- 3. HPD motif integrity
hpd = {}
for g, s in jd_seqs.items():
    hpd[g] = bool(re.search(r"HPD", s))
print(f"[ok] canonical HPD tripeptide present in {sum(hpd.values())}/{len(hpd)} J-domains")

# -------------------------------------------------------- 4. MSA + ML tree
aln = RES / "jdomains_aln.fasta"
r = run(["mafft", "--localpair", "--maxiterate", "1000", "--quiet", jd_path])
aln.write_text(r.stdout)

run(["iqtree2", "-s", aln, "-m", "MFP", "-B", "1000", "-alrt", "1000",
     "-T", "2", "--prefix", str(RES / "jdomain_tree"), "-quiet", "-redo"])
print("[ok] ML phylogeny written")

# ------------------------------------- 5. Funes-likeness of Hsp70 module
blosum = substitution_matrices.load("BLOSUM62")
pa = PairwiseAligner(mode="global", substitution_matrix=blosum,
                     open_gap_score=-11, extend_gap_score=-1)
pl = PairwiseAligner(mode="local", substitution_matrix=blosum,
                     open_gap_score=-11, extend_gap_score=-1)

A = AlignIO.read(aln, "fasta")
aln_d = {rec.id: str(rec.seq) for rec in A}
fun_aln = aln_d["Funes"]
fun_jd = jd_seqs["Funes"]
fun_full = str(records["Q9VCH9"].seq)

out = []
for g, s in jd_seqs.items():
    col = aln_d[g]
    pos = [(a, b) for a, b in zip(fun_aln, col) if a != "-" or b != "-"]
    ident = sum(a == b and a != "-" for a, b in pos) / max(1, sum(a != "-" for a in fun_aln))
    simil = sum(1 for a, b in pos if a != "-" and b != "-" and blosum[a, b] > 0)
    simil /= max(1, sum(a != "-" for a in fun_aln))
    # J-domain only, and full-length, normalised Smith-Waterman
    acc = [k for k, v in gene_of.items() if v == g][0]
    full = str(records[acc].seq)
    sw_jd = pl.score(fun_jd, s) / pl.score(fun_jd, fun_jd)
    sw_fl = pl.score(fun_full, full) / pl.score(fun_full, fun_full)
    out.append(dict(gene=g, acc=acc, len_full=len(full), len_jd=len(s),
                    jd_identity=ident, jd_similarity=simil,
                    sw_jdomain_norm=sw_jd, sw_fulllength_norm=sw_fl,
                    HPD=hpd[g]))

L1 = pd.DataFrame(out).sort_values("sw_jdomain_norm", ascending=False)
L1.to_csv(RES / "layer1_scores.tsv", sep="\t", index=False)
print(L1.head(15).to_string(index=False))
