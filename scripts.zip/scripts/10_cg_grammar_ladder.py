#!/usr/bin/env python3
"""
10_cg_grammar_ladder.py  --  PRISM-J Layer 4b (controlled grammar titration)

A decisive internal control for the recognition-grammar hypothesis. The
Protein Data Bank contains cryo-EM structures of the wild-type Orb2 amyloid
core and of engineered variants of the same 31-residue core in which five
glutamines of the Gln ladder are replaced by aliphatic and aromatic residues:

  6VPS  Orb2 wild type                QLHQQQHQQQHQQHQQHQQQQQLHQHQQQLS
  9PX8  designed Orb2 "LVLVF"         ...........L..V..L..V.F........
  9YWA  designed Orb2 "FVLVF"         ...........F..V..L..V.F........
  9Y1V  designed Orb2 "FIMMF"         ...........F..I..M..M.F........

These variants hold the scaffold, length and register fixed while moving the
client along the amide-to-aromatic axis that separates Orb2 from hCPEB3. If
chaperone selectivity is set by client grammar rather than by client
identity, association free energies must track the substitutions on this
invariant scaffold.

Usage: python3 10_cg_grammar_ladder.py --worker 0 --nworkers 2
"""
import argparse
import json
import pathlib
import sys
import numpy as np

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import importlib
mod = importlib.import_module("09_cg_binding")

ROOT = pathlib.Path(__file__).resolve().parents[1]
RES = ROOT / "results"

LADDER = {
    "Orb2_LVLVF": "QLHQQQHQQQHLQHVQHLQQVQFHQHQQQLS",   # PDB 9PX8/9PZD/9Q37/9Q7J
    "Orb2_FVLVF": "QLHQQQHQQQHFQHVQHLQQVQFHQHQQQLS",   # PDB 9YWA
    "Orb2_FIMMF": "QLHQQQHQQQHFQHIQHMQQMQFHQHQQQLS",   # PDB 9Y1V/9Y9X
}
mod.CLIENTS.update(LADDER)

# two chaperones that sit at opposite ends of the experimental client
# preference axis, each already measured against both ladder end points
SYSTEMS = [(c, cl, "grammar titration on an invariant Orb2 scaffold")
           for c in ["DNAJB8", "DNAJB2"]
           for cl in ["Orb2_LVLVF", "Orb2_FVLVF", "Orb2_FIMMF"]]

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--worker", type=int, default=0)
    ap.add_argument("--nworkers", type=int, default=1)
    args = ap.parse_args()
    json.dump(LADDER, open(RES / "grammar_ladder_sequences.json", "w"), indent=1)
    todo = [s for i, s in enumerate(SYSTEMS) if i % args.nworkers == args.worker]
    print(f"worker {args.worker}/{args.nworkers}: {len(todo)} ladder systems", flush=True)
    for chap, client, note in todo:
        if (mod.OUT / f"{chap}__{client}.json").exists():
            print(f"[skip] {chap}__{client}", flush=True)
            continue
        try:
            mod.run_system(chap, client, note)
        except Exception as exc:
            print(f"[fail] {chap}__{client}: {exc}", flush=True)
