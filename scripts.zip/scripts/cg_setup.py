#!/usr/bin/env python3
"""
cg_setup.py

Helpers that turn a pair of sequences into the arrays required by
cg_engine.run_baoab, and that compute association free energies from
umbrella-sampling histograms by WHAM.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from calvados_cg import load_residues, charges, dh_params, R0_BOND
from cg_engine import minimize, run_baoab, R_GAS, contact_counts

STANDARD_VOLUME_NM3 = 1.0 / 0.6022140760  # nm^3 per molecule at 1 M


def build(seqs, residues, temp=310.0, ionic=0.15, pH=7.0, flexhis=False,
          charge_termini=True):
    """Return a dict of per-bead parameters and topology for a chain set."""
    nchain = [len(s) for s in seqs]
    offs = np.cumsum([0] + nchain[:-1])
    n = sum(nchain)
    sig = np.concatenate([[residues.loc[c, "sigmas"] for c in s] for s in seqs])
    lam = np.concatenate([[residues.loc[c, "lambdas"] for c in s] for s in seqs])
    mw = np.concatenate([[residues.loc[c, "MW"] for c in s] for s in seqs])
    q = np.concatenate([charges(s, residues, pH, flexhis, charge_termini)
                        for s in seqs])
    bi, bj = [], []
    excl = np.zeros((n, n), dtype=np.bool_)
    for ci, nc in enumerate(nchain):
        o = int(offs[ci])
        for i in range(nc - 1):
            bi.append(o + i); bj.append(o + i + 1)
            excl[o + i, o + i + 1] = excl[o + i + 1, o + i] = True
    eps_yu, k_yu = dh_params(temp, ionic)
    return dict(seqs=seqs, n=n, nchain=nchain, offs=offs,
                sig=np.ascontiguousarray(sig, dtype=np.float64),
                lam=np.ascontiguousarray(lam, dtype=np.float64),
                mw=np.ascontiguousarray(mw, dtype=np.float64),
                q=np.ascontiguousarray(q, dtype=np.float64),
                bi=np.array(bi, dtype=np.int64), bj=np.array(bj, dtype=np.int64),
                excl=excl, eps_yu=eps_yu, k_yu=k_yu,
                shift_yu=float(np.exp(-k_yu * 4.0) / 4.0), temp=temp)


def start_coords(sysd, seed=0, sep=6.0):
    """Non-overlapping ideal chains placed `sep` nm apart along x."""
    rng = np.random.default_rng(seed)
    x = np.zeros((sysd["n"], 3))
    for ci, nc in enumerate(sysd["nchain"]):
        o = int(sysd["offs"][ci])
        pos = np.zeros((nc, 3))
        for i in range(1, nc):
            for _ in range(500):
                v = rng.normal(size=3)
                v *= R0_BOND / np.linalg.norm(v)
                cand = pos[i - 1] + v
                if i < 4 or np.min(np.linalg.norm(pos[:i - 2] - cand, axis=1)) > 0.45:
                    break
            pos[i] = cand
        pos -= pos.mean(0)
        x[o:o + nc] = pos + np.array([sep * (ci - 0.5 * (len(sysd["nchain"]) - 1)), 0, 0])
    return np.ascontiguousarray(x)


def equilibrate_and_sample(sysd, r0, kum, rwall, kwall, n_eq, n_prod,
                           stride, seed, max_disp=0.02):
    """Minimise, equilibrate, then sample one umbrella window."""
    x = start_coords(sysd, seed=seed, sep=max(r0, 1.0))
    minimize(x, sysd["sig"], sysd["lam"], sysd["q"], sysd["bi"], sysd["bj"],
             sysd["excl"], sysd["eps_yu"], sysd["k_yu"], sysd["shift_yu"],
             4000, max_disp)
    rng = np.random.default_rng(seed + 991)
    v = np.ascontiguousarray(
        rng.normal(size=x.shape) * np.sqrt(R_GAS * sysd["temp"] / sysd["mw"])[:, None])
    n1 = sysd["nchain"][0]
    run_baoab(x, v, sysd["mw"], sysd["sig"], sysd["lam"], sysd["q"],
              sysd["bi"], sysd["bj"], sysd["excl"], sysd["eps_yu"],
              sysd["k_yu"], sysd["shift_yu"], sysd["temp"], 0.01, 0.01,
              n_eq, max(1, n_eq), kum, r0, n1, rwall, kwall, seed + 1)
    rs, us = run_baoab(x, v, sysd["mw"], sysd["sig"], sysd["lam"], sysd["q"],
                       sysd["bi"], sysd["bj"], sysd["excl"], sysd["eps_yu"],
                       sysd["k_yu"], sysd["shift_yu"], sysd["temp"], 0.01, 0.01,
                       n_prod, stride, kum, r0, n1, rwall, kwall, seed + 2)
    return rs, us, x


# ------------------------------------------------------------------- WHAM
def wham(samples, centres, k, temp, bins, tol=1e-10, max_iter=200_000):
    """
    One-dimensional WHAM for harmonic umbrellas.

    samples : list of 1-D arrays of the reaction coordinate per window
    centres : umbrella centres r0 (nm)
    k       : force constant (kJ/mol/nm^2), common to all windows
    returns : bin centres, PMF (kJ/mol), per-window free-energy offsets
    """
    kT = R_GAS * temp
    edges = np.asarray(bins, dtype=float)
    mid = 0.5 * (edges[1:] + edges[:-1])
    H = np.array([np.histogram(s, bins=edges)[0] for s in samples], dtype=float)
    N = H.sum(axis=1)
    # bias energy of each window at each bin centre
    B = 0.5 * k * (mid[None, :] - np.asarray(centres)[:, None]) ** 2
    expB = np.exp(-B / kT)
    num = H.sum(axis=0)
    f = np.zeros(len(centres))
    for _ in range(max_iter):
        denom = (N[:, None] * np.exp(f[:, None] / kT) * expB).sum(axis=0)
        with np.errstate(divide="ignore", invalid="ignore"):
            p = np.where(denom > 0, num / denom, 0.0)
        fn = -kT * np.log(np.where((expB * p[None, :]).sum(axis=1) > 0,
                                   (expB * p[None, :]).sum(axis=1), 1e-300))
        fn -= fn[0]
        if np.max(np.abs(fn - f)) < tol:
            f = fn
            break
        f = fn
    with np.errstate(divide="ignore"):
        pmf = -kT * np.log(np.where(p > 0, p, np.nan))
    return mid, pmf, f


def pmf_to_dg(r, pmf, temp, r_bound, plateau):
    """
    Standard-state binding free energy from a centroid-distance PMF.

      K_a = (1/V0) * integral_0^{r_bound} 4 pi r^2 exp(-W(r)/kT) dr
      dG0 = -kT ln K_a ,  V0 = 1.6606 nm^3 (1 M)

    W(r) is referenced to its mean over `plateau` = (r_lo, r_hi), the
    well-sampled free-state region of the reaction coordinate.
    """
    kT = R_GAS * temp
    ok = np.isfinite(pmf)
    lo, hi = plateau
    far = ok & (r >= lo) & (r <= hi)
    if far.sum() < 3:
        far = ok & (r >= np.quantile(r[ok], 0.85))
    ref = float(np.average(pmf[far]))
    w = pmf - ref                      # same grid as r; NaNs preserved
    sel = ok & (r <= r_bound)
    integrand = 4.0 * np.pi * r[sel] ** 2 * np.exp(-w[sel] / kT)
    Ka = np.trapezoid(integrand, r[sel]) / STANDARD_VOLUME_NM3
    dG = -kT * np.log(Ka)
    return dG, Ka, w


def window_overlap(samples, bins):
    """
    Fraction of occupied bins shared by each adjacent pair of umbrella
    windows. Values below about 0.3 indicate that the windows are too
    narrowly restrained for the weighted histogram analysis to stitch them
    reliably.
    """
    H = np.array([np.histogram(s, bins=bins)[0] for s in samples], dtype=float)
    ov = []
    for i in range(len(H) - 1):
        a, b = H[i] > 0, H[i + 1] > 0
        ov.append(float((a & b).sum() / max(1, (a | b).sum())))
    return np.array(ov), H
