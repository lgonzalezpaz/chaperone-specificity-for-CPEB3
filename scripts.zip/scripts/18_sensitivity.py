#!/usr/bin/env python3
"""
18_sensitivity.py  --  sensitivity of the association free energy to the
                       three modelling choices that could plausibly change it

  1. the length cap on the client-binding region (60, 100, 150 residues)
  2. the treatment of histidine: neutral, the published CALVADOS default, or
     partially protonated at pH 7.0 with q = 1/(1 + 10^(pH-6)) = 0.0909.
     This matters because the Orb2 core is 22.6% histidine.
  3. the parameter set: CALVADOS 2 against CALVADOS 3

Each variant is run with the production umbrella protocol so that the values
are directly comparable with Table 3.

Outputs: results/sensitivity.tsv, results/sensitivity.json
"""
import json
import pathlib
import sys
import time
import numpy as np
import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from calvados_cg import load_residues
from cg_setup import build, wham, pmf_to_dg, window_overlap
import importlib
mod = importlib.import_module("09_cg_binding")

ROOT = pathlib.Path(__file__).resolve().parents[1]
RES = ROOT / "results"
CHAP, CLIENT = "DNAJB2", "hCPEB3_core"


def dg_for(cbr, cseq, residues, flexhis, label, seed0=7001):
    sysd = build([cbr, cseq], residues, temp=mod.TEMP, ionic=mod.IONIC,
                 flexhis=flexhis)
    samples, centres = [], []
    for r0 in mod.WINDOWS:
        pooled = []
        for rep in range(2):
            rs, _, _ = mod.equilibrate_and_sample(
                sysd, r0=float(r0), kum=mod.K_UM, rwall=mod.R_WALL,
                kwall=mod.K_WALL, n_eq=mod.N_EQ, n_prod=mod.N_PROD,
                stride=mod.STRIDE, seed=seed0 + int(r0 * 100) + rep * 17)
            pooled.append(rs)
        samples.append(np.concatenate(pooled)); centres.append(float(r0))
    bins = np.linspace(0.0, mod.R_WALL, 113)
    ov, _ = window_overlap(samples, bins)
    mid, pmf, _ = wham(samples, centres, mod.K_UM, mod.TEMP, bins)
    dG, _, _ = pmf_to_dg(mid, pmf, mod.TEMP, mod.R_BOUND, mod.PLATEAU)
    print(f"  {label:34s} dG = {dG:7.2f} kJ/mol  (overlap "
          f"{ov.min():.2f}/{ov.mean():.2f}, {sysd['n']} beads)", flush=True)
    return float(dG), float(ov.mean()), int(sysd["n"])


acc = mod.ACC[CHAP]
a, b = mod.SPAN[acc]
full = mod.JDP[acc]
cseq = mod.CLIENTS[CLIENT]
C2 = load_residues(ROOT / "data" / "residues_CALVADOS2.csv")
C3 = load_residues(ROOT / "data" / "residues_CALVADOS3.csv")

rows = []
print(f"sensitivity analysis for {CHAP} + {CLIENT}")
t0 = time.time()

for cap in (60, 100):
    cbr, c0, c1 = mod.cbr_of(full, a, b, cap=cap)
    dG, ov, n = dg_for(cbr, cseq, C2, False,
                       f"CBR cap {cap} aa (CALVADOS 2)")
    rows.append(dict(variant=f"CBR length cap {cap} aa", axis="CBR length",
                     cbr_len=len(cbr), dG_kJmol=dG, overlap_mean=ov,
                     n_beads=n, parameters="CALVADOS 2", flexhis=False))

cbr, _, _ = mod.cbr_of(full, a, b, cap=100)
dG, ov, n = dg_for(cbr, cseq, C2, True,
                   "His partially protonated, pH 7")
rows.append(dict(variant="histidine partially protonated (pH 7)",
                 axis="histidine charge", cbr_len=len(cbr), dG_kJmol=dG,
                 overlap_mean=ov, n_beads=n, parameters="CALVADOS 2",
                 flexhis=True))

dG, ov, n = dg_for(cbr, cseq, C3, False, "CALVADOS 3 parameters")
rows.append(dict(variant="CALVADOS 3 parameter set", axis="force field",
                 cbr_len=len(cbr), dG_kJmol=dG, overlap_mean=ov, n_beads=n,
                 parameters="CALVADOS 3", flexhis=False))

df = pd.DataFrame(rows)
ref = float(df.loc[df.variant == "CBR length cap 100 aa", "dG_kJmol"].iloc[0])
df["delta_vs_reference"] = df.dG_kJmol - ref
df.to_csv(RES / "sensitivity.tsv", sep="\t", index=False)
print(f"\nreference (CBR cap 100 aa, CALVADOS 2, neutral His): "
      f"{ref:.2f} kJ/mol")
print(df[["variant", "dG_kJmol", "delta_vs_reference"]].round(2).to_string(index=False))
print(f"maximum deviation across all variants: "
      f"{df.delta_vs_reference.abs().max():.2f} kJ/mol")
json.dump(dict(system=f"{CHAP}+{CLIENT}", reference_dG=ref,
               max_abs_deviation=float(df.delta_vs_reference.abs().max()),
               variants=df.to_dict("records"),
               wall_min=round((time.time() - t0) / 60, 1)),
          open(RES / "sensitivity.json", "w"), indent=1)
print(f"[ok] sensitivity.json written ({(time.time()-t0)/60:.1f} min)")
