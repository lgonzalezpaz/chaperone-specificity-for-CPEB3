#!/usr/bin/env python3
"""
12_integrate.py  --  PRISM-J integration and ranking

Assembles the screening layers into the final ranking and tests the central
dissociation claim: the human J-domain protein that best conserves the Funes
Hsp70-coupling module is not the one best matched to the hCPEB3 client and its
neuronal context.

Layer definitions (all reported separately; no layer is used to justify
another).
  L1  conservation of the Hsp70-coupling module: normalised Smith-Waterman
      score of the Pfam PF00226 J domain against Funes.
  L2  mean-field association propensity of the client-binding region: the
      mean CALVADOS 2 stickiness lambda of the CBR. Because the CALVADOS
      cross term is additive, lambda_ij = (lambda_i + lambda_j)/2, the
      mean-field score cannot by construction encode client selectivity;
      selectivity is therefore obtained only from the explicit simulations
      (Layer 4). The aromatic, aliphatic and amide fractions of the CBR are
      reported alongside as the interpretable chemistry.
  L3  neuronal context: brain expression, brain enrichment and
      tissue-profile co-expression with CPEB3.
  L4  explicit association free energies from umbrella sampling.

Prefilter. A chaperone that is not expressed in human brain cannot perform
this function in neurons, so the ranking is restricted to JDPs with a median
brain expression of at least 1 TPM and a client-binding region of at least
40 residues (shorter regions make composition estimates unstable).

Outputs (results/):
  prismj_ranking.tsv, cg_summary.tsv, integration.json
"""
import json
import pathlib
import numpy as np
import pandas as pd
from scipy import stats

ROOT = pathlib.Path(__file__).resolve().parents[1]
RES = ROOT / "results"
CG = RES / "cg"
MIN_TPM = 1.0
MIN_CBR = 40

L1 = pd.read_csv(RES / "layer1_scores.tsv", sep="\t")
L2 = pd.read_csv(RES / "layer2_scores.tsv", sep="\t")
L3 = pd.read_csv(RES / "layer3_scores.tsv", sep="\t")
dj = pd.read_csv(RES / "descriptors_jdp.tsv", sep="\t")
roz = pd.read_csv(RES / "rozales_scores_wide.tsv", sep="\t")

# ------------------------------------------------------------ CG results
recs = [json.load(open(p)) for p in sorted(CG.glob("*.json"))
        if "worker" not in p.name and "TEST" not in p.name]
cg = pd.DataFrame(recs)
if len(cg):
    keep = [c for c in ["system", "chaperone", "client", "note", "n_beads",
                        "n_frames", "dG_kJmol", "dG_sd_kJmol",
                        "dG_replica_spread", "Kd_mM", "cbr_start", "cbr_end",
                        "wall_min"] if c in cg.columns]
    cg = cg[keep].sort_values(["client", "dG_kJmol"])
    cg.to_csv(RES / "cg_summary.tsv", sep="\t", index=False)
    print(f"[ok] coarse-grained systems completed: {len(cg)}")
    print(cg[[c for c in ["chaperone", "client", "dG_kJmol", "dG_sd_kJmol",
                          "dG_replica_spread"] if c in cg.columns]]
          .round(2).to_string(index=False))
else:
    print("[warn] no coarse-grained results yet")

# -------------------------------------------------------- integrate layers
T = (L1[["gene", "acc", "len_full", "jd_identity", "jd_similarity",
         "sw_jdomain_norm", "sw_fulllength_norm", "HPD"]]
     .merge(dj[["gene", "cbr_len", "lam_mean", "f_aromatic", "f_aliphatic",
                "f_amide", "f_hydroxyl", "f_pro", "f_gly", "ncpr", "kappa"]],
            on="gene", how="inner")
     .merge(L3[["gene", "brain_tpm_median", "cortex_tpm", "hippocampus_tpm",
                "brain_enrichment_log2", "cpeb3_coexpr_rho",
                "hpa_main_location", "hpa_additional_location",
                "cytoplasmic_pool"]], on="gene", how="left"))

roz_l = roz.copy()
roz_l["gene"] = (roz_l.chaperone.str.replace("-FL", "", regex=False)
                 .str.replace("-short", "", regex=False)
                 .str.replace(r"b$", "", regex=True))
agg = roz_l.groupby("gene")[["HTT_polyQ", "mutFUS"]].mean().reset_index()
agg.columns = ["gene", "ams_polyQ", "ams_mutFUS"]
T = T.merge(agg, on="gene", how="left")
T["ams_aromatic_preference"] = T.ams_polyQ - T.ams_mutFUS

T["n_jdp_total"] = len(T)
T["passes_prefilter"] = ((T.brain_tpm_median >= MIN_TPM) & (T.cbr_len >= MIN_CBR))
print(f"\n[info] {len(T)} human JDPs with a J domain; "
      f"{int(T.passes_prefilter.sum())} pass the brain-expression "
      f"(>= {MIN_TPM} TPM) and CBR-length (>= {MIN_CBR} aa) prefilter")

F = T[T.passes_prefilter].copy()


def z(s, clip=3.0):
    s = pd.to_numeric(s, errors="coerce")
    v = (s - s.mean()) / s.std(ddof=0)
    return v.clip(-clip, clip)


F["L1_engine"] = z(F.sw_jdomain_norm)
F["L2_stickiness"] = z(F.lam_mean)
F["L3_context"] = (z(np.log2(F.brain_tpm_median + 1))
                   + z(F.brain_enrichment_log2)
                   + z(F.cpeb3_coexpr_rho)) / 3.0
F["PRISMJ_score"] = (F.L2_stickiness + F.L3_context) / 2.0
F = F.sort_values("PRISMJ_score", ascending=False).reset_index(drop=True)
F["rank_prismj"] = np.arange(1, len(F) + 1)
F["rank_L1"] = F.L1_engine.rank(ascending=False, method="min").astype(int)
F["rank_L3"] = F.L3_context.rank(ascending=False, method="min").astype(int)
F.to_csv(RES / "prismj_ranking.tsv", sep="\t", index=False)

print("\n--- PRISM-J ranking, brain-expressed human JDPs (top 12) ---")
cols = ["gene", "rank_L1", "sw_jdomain_norm", "lam_mean", "f_aromatic",
        "brain_tpm_median", "cpeb3_coexpr_rho", "PRISMJ_score",
        "hpa_main_location"]
print(F.head(12)[cols].round(3).to_string(index=False))

print("\n--- the Funes sequence orthologue ---")
print(F[F.gene == "DNAJC8"][["gene", "rank_L1", "rank_prismj", "rank_L3",
                             "jd_identity", "sw_jdomain_norm", "lam_mean",
                             "L3_context", "cpeb3_coexpr_rho",
                             "brain_enrichment_log2", "hpa_main_location"]
                            ].round(3).to_string(index=False))

# ------------------------------------------------ dissociation statistics
def srho(a, b):
    m = np.isfinite(a) & np.isfinite(b)
    r, p = stats.spearmanr(a[m], b[m])
    return float(r), float(p), int(m.sum())


r12, p12, n12 = srho(F.L1_engine.to_numpy(float), F.L2_stickiness.to_numpy(float))
r13, p13, n13 = srho(F.L1_engine.to_numpy(float), F.L3_context.to_numpy(float))
r1p, p1p, n1p = srho(F.L1_engine.to_numpy(float), F.PRISMJ_score.to_numpy(float))
print(f"\nlayer independence (n = {n12} brain-expressed JDPs)")
print(f"  rho(L1, L2 stickiness) = {r12:+.3f}  P = {p12:.3g}")
print(f"  rho(L1, L3 context)    = {r13:+.3f}  P = {p13:.3g}")
print(f"  rho(L1, PRISM-J)       = {r1p:+.3f}  P = {p1p:.3g}")

pts = F[["L1_engine", "PRISMJ_score"]].to_numpy(float)
front = [F.gene.iloc[i] for i in range(len(pts))
         if not np.any((pts[:, 0] >= pts[i, 0]) & (pts[:, 1] >= pts[i, 1]) &
                       ((pts[:, 0] > pts[i, 0]) | (pts[:, 1] > pts[i, 1])))]
print(f"\nPareto front on (Hsp70-coupling conservation, client-plus-context): "
      f"{', '.join(front)}")

d8 = F[F.gene == "DNAJC8"].iloc[0]
l1_sorted = F.nlargest(3, "sw_jdomain_norm")
out = dict(
    n_jdp_with_jdomain=int(len(T)),
    n_jdp_prefiltered=int(len(F)),
    prefilter=dict(min_brain_tpm=MIN_TPM, min_cbr_len=MIN_CBR),
    dnajc8=dict(rank_L1=int(d8.rank_L1), rank_prismj=int(d8.rank_prismj),
                rank_L3=int(d8.rank_L3), jd_identity=float(d8.jd_identity),
                jd_similarity=float(d8.jd_similarity),
                sw_jdomain=float(d8.sw_jdomain_norm),
                sw_fulllength=float(d8.sw_fulllength_norm),
                lam_mean=float(d8.lam_mean),
                cpeb3_coexpr=float(d8.cpeb3_coexpr_rho),
                brain_enrichment=float(d8.brain_enrichment_log2),
                hpa_main=str(d8.hpa_main_location)),
    l1_top3=l1_sorted[["gene", "sw_jdomain_norm", "jd_identity"]].to_dict("records"),
    top_prismj=F.head(6)[["gene", "PRISMJ_score", "L2_stickiness",
                          "L3_context", "brain_tpm_median",
                          "cpeb3_coexpr_rho"]].to_dict("records"),
    layer_independence=dict(n=n12, rho_L1_L2=r12, p_L1_L2=p12,
                            rho_L1_L3=r13, p_L1_L3=p13,
                            rho_L1_prismj=r1p, p_L1_prismj=p1p),
    pareto_front=front)
json.dump(out, open(RES / "integration.json", "w"), indent=1)
print("\n[ok] integration.json written")
