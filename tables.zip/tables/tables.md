### table1

| PDB | Client | Resolved core | Length (aa) | Gln (%) | His (%) | Aromatic (%) | Apolar (%) | Charged (%) | Mean hydropathy | Exposed fraction | Surface amide (%) | Surface aromatic (%) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 6VPS | Orb2 | 23-53 | 31 | 64.5 | 22.6 | 0.0 | 9.7 | 0.0 | -2.6 | 0.6 | 55.0 | 0.0 |
| 8YAC | Orb2 | 176-206 | 31 | 64.5 | 22.6 | 0.0 | 9.7 | 0.0 | -2.6 | 0.6 | 50.0 | 0.0 |
| 8SPA | hCPEB3 | 103-151 | 49 | 4.1 | 4.1 | 16.3 | 34.7 | 4.1 | -0.0 | 0.4 | 11.1 | 11.1 |

### table2

| Gene | UniProt | Length (aa) | J-domain identity to Funes (%) | J-domain similarity (%) | Normalised SW, J domain | Normalised SW, full length | HPD motif |
|---|---|---|---|---|---|---|---|
| DNAJC8 | O75937 | 253 | 58.667 | 78.667 | 0.591 | 0.502 | yes |
| DNAJB8 | Q8NHS0 | 232 | 34.667 | 54.667 | 0.365 | 0.107 | yes |
| DNAJC14 | Q6Y2X3 | 702 | 36.000 | 50.667 | 0.350 | 0.115 | yes |
| DNAJB6 | O75190 | 326 | 32.000 | 56.000 | 0.319 | 0.094 | yes |
| SEC63 | Q9UGP8 | 760 | 34.667 | 56.000 | 0.311 | 0.092 | yes |
| DNAJB2 | P25686 | 324 | 30.667 | 52.000 | 0.308 | 0.091 | yes |
| DNAJB7 | Q7Z6W7 | 309 | 30.667 | 54.667 | 0.306 | 0.090 | yes |
| DNAJB3 | Q8WWF6 | 145 | 30.667 | 52.000 | 0.301 | 0.090 | yes |
| DNAJA4 | Q8WW22 | 397 | 28.000 | 52.000 | 0.293 | 0.086 | yes |
| DNAJC1 | Q96KC8 | 554 | 30.667 | 56.000 | 0.280 | 0.085 | yes |

### table3

| Chaperone | Client | CBR residues | Beads | dG (kJ/mol) | Bootstrap SD | Replica spread | Kd (mM) | Role |
|---|---|---|---|---|---|---|---|---|
| DNAJB8 | Orb2 FIMMF (9Y1V) | 77-176 | 131 | -11.41 | 0.28 | 1.14 | 19.88 | grammar titration on an invariant Orb2 scaffold |
| DNAJB2 | Orb2 FIMMF (9Y1V) | 77-176 | 131 | -10.65 | 0.31 | 0.26 | 26.66 | grammar titration on an invariant Orb2 scaffold |
| DNAJB2 | Orb2 FVLVF (9YWA) | 77-176 | 131 | -10.87 | 0.29 | 0.14 | 24.51 | grammar titration on an invariant Orb2 scaffold |
| DNAJB8 | Orb2 FVLVF (9YWA) | 77-176 | 131 | -10.63 | 0.26 | 1.28 | 26.88 | grammar titration on an invariant Orb2 scaffold |
| DNAJB2 | Orb2 LVLVF (9PX8) | 77-176 | 131 | -11.26 | 0.28 | 0.36 | 21.07 | grammar titration on an invariant Orb2 scaffold |
| DNAJB8 | Orb2 LVLVF (9PX8) | 77-176 | 131 | -10.67 | 0.23 | 0.34 | 26.50 | grammar titration on an invariant Orb2 scaffold |
| DNAJB8 | Orb2 core (6VPS) | 77-176 | 131 | -10.86 | 0.26 | 0.29 | 24.56 | top amide-client alleviator on its matched grammar |
| DNAJB2 | Orb2 core (6VPS) | 77-176 | 131 | -10.54 | 0.27 | 1.07 | 27.86 | candidate specificity cross-check |
| DNAJC5 | Orb2 core (6VPS) | 88-187 | 131 | -10.34 | 0.27 | 0.17 | 30.11 | candidate specificity cross-check |
| DNAJC8 | Orb2 core (6VPS) | 128-227 | 131 | -10.05 | 0.28 | 2.84 | 33.70 | sequence orthologue on the fly client |
| DNAJB6 | Orb2 core (6VPS) | 77-176 | 131 | -9.97 | 0.28 | 0.03 | 34.64 | polyQ specialist on its matched grammar |
| Funes | Orb2 core (6VPS) | 125-224 | 131 | -9.91 | 0.28 | 1.50 | 35.45 | positive control: experimentally validated pair |
| DNAJB6 | hCPEB3 core (8SPA) | 77-176 | 149 | -11.59 | 0.38 | 0.18 | 18.48 | canonical anti-amyloid DNAJB |
| DNAJB1 | hCPEB3 core (8SPA) | 76-175 | 149 | -11.45 | 0.28 | 1.00 | 19.56 | generic Hsp40 reference |
| DNAJB8 | hCPEB3 core (8SPA) | 77-176 | 149 | -11.45 | 0.26 | 0.25 | 19.57 | top amide-client alleviator on the aromatic client |
| Funes | hCPEB3 core (8SPA) | 125-224 | 149 | -11.16 | 0.37 | 0.63 | 21.85 | cross-species transfer test |
| DNAJB2 | hCPEB3 core (8SPA) | 77-176 | 149 | -10.71 | 0.30 | 0.62 | 26.07 | Layer 3 candidate: top brain expression and CPEB3 co-expression |
| DNAJC8 | hCPEB3 core (8SPA) | 128-227 | 149 | -10.65 | 0.30 | 0.06 | 26.63 | naive orthology prediction |
| DNAJC5 | hCPEB3 core (8SPA) | 88-187 | 149 | -10.47 | 0.25 | 0.87 | 28.53 | Layer 3 candidate: synaptic, top aromatic-client alleviator |
| DNAJB2 | hCPEB3 core, scrambled | 77-176 | 149 | -9.84 | 0.30 | 0.15 | 36.54 | composition-matched sequence-scrambled control |

### table4

| Gene | PRISM-J rank | Layer 1 rank | J-domain similarity to Funes | CBR mean stickiness | CBR aromatic (%) | Brain TPM (median) | Brain enrichment (log2) | CPEB3 co-expression | Main localisation |
|---|---|---|---|---|---|---|---|---|---|
| DNAJC30 | 1 | 31 | 0.175 | 0.523 | 12.081 | 10.617 | 0.176 | 0.239 | nan |
| DNAJB2 | 2 | 5 | 0.308 | 0.453 | 7.661 | 124.393 | 1.011 | 0.760 | Nuclear membrane |
| DNAJC6 | 3 | 31 | 0.175 | 0.447 | 8.197 | 40.362 | 4.050 | 0.337 | Cytosol |
| DNAJB9 | 4 | 33 | 0.170 | 0.495 | 15.068 | 19.785 | -0.564 | -0.110 | Cytosol;Endoplasmic reticulum |
| DNAJC4 | 5 | 24 | 0.193 | 0.485 | 6.748 | 38.655 | -0.827 | -0.048 | nan |
| DNAJC5 | 6 | 9 | 0.265 | 0.437 | 10.744 | 70.989 | 0.822 | 0.460 | Vesicles |
| DNAJC8 | 36 | 1 | 0.591 | 0.376 | 6.742 | 50.844 | -0.360 | 0.008 | Nucleoplasm |